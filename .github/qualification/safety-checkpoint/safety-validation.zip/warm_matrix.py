import argparse
import json
import math
import os
from pathlib import Path
import statistics
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--pairs', type=int, default=3)
p.add_argument('--tier', choices=['all', 'int', 'c1-l1', 'c1-l3', 'c2'], default='all')
p.add_argument('--controls', action='store_true')
a = p.parse_args()
root = Path('/workspace/pr9-validation')
out = root / ('warm-controls' if a.controls else 'warm-matrix')
out.mkdir(exist_ok=True)
images = json.loads((root / 'images.json').read_text())
variants = {'master': ('master', []), 'before-on': ('before', ['-XX:+UseCommonIntrinsics']),
            'final-off': ('final', ['-XX:-UseCommonIntrinsics']),
            'final-on': ('final', ['-XX:+UseCommonIntrinsics'])}
cpus = sorted(os.sched_getaffinity(0))
worker = cpus[0]
os.sched_setaffinity(0, {cpus[1]})
cp = ':'.join(str(root / 'jmh' / n) for n in
              ['benchmarks.jar', 'jmh-core.jar', 'jopt-simple.jar', 'commons-math3.jar'])
flags = ['-XX:ActiveProcessorCount=1', '-XX:CICompilerCount=2', '-XX:+UseSerialGC',
         '-Xms128m', '-Xmx256m', '-XX:-UsePerfData', '-XX:+DisableAttachMechanism', '-Xrs']
tiers = [('int', ['-Xint']), ('c1-l1', ['-Xbatch', '-XX:TieredStopAtLevel=1']),
         ('c1-l3', ['-Xbatch', '-XX:TieredStopAtLevel=3']), ('c2', ['-Xbatch', '-XX:-TieredCompilation'])]
cases = [('hash', 'CommonSmallIntrinsics.hashBytes', ['-p', 'length=1,32,65537']),
         ('scalar', 'CommonSmallIntrinsics.bitCount', ['-p', 'length=1']),
         ('multiply', 'CommonBigIntegerCalls.multiply', ['-p', 'bits=512,4096']),
         ('modpow', 'CommonBigIntegerCalls.modPow', ['-p', 'bits=512,4096']),
         ('aes', 'CommonIntrinsics.aesCtr', ['-p', 'length=4096']),
         ('sha256', 'CommonIntrinsics.sha256', ['-p', 'length=4096']),
         ('sha3', 'CommonIntrinsics.sha3', ['-p', 'length=4096']),
         ('chacha', 'CommonIntrinsics.chacha20', ['-p', 'length=4096'])]
if a.controls:
    cases = [('multiply', 'CommonBigIntegerCalls.multiply', ['-p', 'bits=4096']),
             ('sha256', 'CommonIntrinsics.sha256', ['-p', 'length=4096'])]
records = []
def save():
    (out / 'manifest.json').write_text(json.dumps({'images': images, 'worker': worker,
        'flags': flags, 'classpath': cp, 'pairs': a.pairs, 'records': records}, indent=2) + '\n')
for tier, mode in tiers:
    if a.tier != 'all' and a.tier != tier:
        continue
    for pair in range(a.pairs):
        labels = list(variants)
        # Rotate rank across pairs; reverse the second half of the sequence.
        labels = labels[pair % len(labels):] + labels[:pair % len(labels)]
        if pair % 2:
            labels.reverse()
        for case, pattern, parameters in cases:
            for label in labels:
                image, extra = variants[label]
                java = images[image]['path'] + '/bin/java'
                name = f'{tier}-{case}-{label}-{pair}'
                result_path = out / (name + '.json')
                vmflags = flags + mode + extra
                command = ['taskset', '-c', str(worker), java, *flags, '-XX:TieredStopAtLevel=1',
                    '-cp', cp, 'org.openjdk.jmh.Main', pattern, *parameters,
                    '-f', '1', '-wi', '3', '-i', '5', '-w', '1s', '-r', '1s', '-t', '1',
                    '-foe', 'true', '-rf', 'json', '-rff', str(result_path),
                    '-jvm', java, '-jvmArgs', ' '.join(vmflags)]
                with (out / (name + '.log')).open('w') as log:
                    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
                record = {'name': name, 'tier': tier, 'case': case, 'label': label, 'pair': pair,
                          'command': command, 'exit_code': code}
                if code == 0:
                    record['results'] = json.loads(result_path.read_text())
                records.append(record)
                save()
                print(name, 'exit', code, flush=True)
                if code:
                    raise SystemExit(code)
