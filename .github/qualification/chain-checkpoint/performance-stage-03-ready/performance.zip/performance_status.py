"""Read completed measurement records without treating partial work as final."""
import json
import pathlib

r = pathlib.Path('/workspace/pr9-validation')
for name in ['local-continuation.json', 'final-performance.json']:
    p = r / name
    if p.exists():
        d = json.loads(p.read_text())
        print(json.dumps({'file': name, 'status': d['status'],
                          'steps': [x['name'] for x in d.get('steps', [])],
                          'phases': [x['name'] for x in d.get('phases', [])],
                          'error': d.get('error')}))
for p in [r / name for name in ['final-first-legacy.json', 'final-first-exact.json',
                                'final-first-boundaries.json', 'final-first-other.json',
                                'final-startup.json']]:
    if not p.exists():
        continue
    d = json.loads(p.read_text())
    complete = [k for k, v in d['results'].items() if v['status'] == 'passed']
    active = [{'case': k, 'status': v['status'], 'raw_observations': len(v['raw'])}
              for k, v in d['results'].items() if v['status'] != 'passed']
    print(json.dumps({'file': p.name, 'completed_cases': len(complete),
                      'last_completed': complete[-1] if complete else None,
                      'active': active}))
for name in ['final-warm', 'final-warm-controls']:
    p = r / name / 'manifest.json'
    if p.exists():
        d = json.loads(p.read_text())
        print(json.dumps({'file': str(p.relative_to(r)), 'recorded_jmh_invocations': len(d['records']),
                          'recorded_parameter_forks': sum(len(x.get('results', [])) for x in d['records']),
                          'failed_invocations': sum(x['exit_code'] != 0 for x in d['records']),
                          'last': d['records'][-1]['name'] if d['records'] else None}))
