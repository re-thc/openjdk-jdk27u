"""Clean, source-aligned builds while preserving the earlier qualified images."""
import argparse
import hashlib
import json
import os
import pathlib
import shlex
import shutil
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('kind', choices=['release', 'fastdebug'])
p.add_argument('--prepare-only', action='store_true')
p.add_argument('--build-only', action='store_true')
a = p.parse_args()
assert a.prepare_only != a.build_only
repo = pathlib.Path('/workspace/openjdk-jdk27u')
r = pathlib.Path('/workspace/pr9-validation')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
conf = 'pr9-' + a.kind
path = r / ('layout-' + a.kind + '.json')

def fingerprint(image):
    return {name: {'bytes': (image / name).stat().st_size,
                   'sha256': hashlib.sha256((image / name).read_bytes()).hexdigest()}
            for name in ['lib/server/libjvm.so', 'lib/modules', 'lib/server/classes.jsa']}

def save():
    path.write_text(json.dumps(state, indent=2) + '\n')

def run(command):
    print(json.dumps({'command': command}), flush=True)
    start = time.time()
    code = subprocess.run(command, cwd=repo).returncode
    state['commands'].append({'command': command, 'exit_code': code, 'seconds': time.time() - start})
    save()
    if code:
        state['status'] = 'failed'
        save()
        raise SystemExit(code)

if a.prepare_only:
    assert not path.exists(), 'Preserve existing build receipt'
    old = json.loads((r / ('clean-' + a.kind + '.json')).read_text())
    golden = pathlib.Path(old['path'])
    assert not golden.is_symlink() and golden.is_dir()
    assert fingerprint(golden) == old['fingerprints']
    spec = (repo / 'build' / conf / 'spec.gmk').read_text()
    line = next(x.split(':=', 1)[1].strip() for x in spec.splitlines()
                if x.startswith('CONFIGURE_COMMAND_LINE :='))
    arguments = shlex.split(line)
    arguments = ['--with-jobs=2' if x.startswith('--with-jobs=') else x for x in arguments]
    state = {'source': source, 'configuration': conf, 'clean': True, 'status': 'preparing',
             'commands': [], 'preserved_source': old['source'], 'preserved_image': str(golden),
             'preserved_fingerprints': old['fingerprints']}
    save()
    run(['bash', 'configure', *arguments])
    run(['make', 'CONF=' + conf, 'JOBS=2', 'clean'])
    assert fingerprint(golden) == old['fingerprints'], 'Clean must leave old golden images unchanged'
    state['status'] = 'prepared'
    save()
else:
    state = json.loads(path.read_text())
    assert state['source'] == source and state['status'] == 'prepared'
    state['status'] = 'building'
    save()
    run(['make', 'CONF=' + conf, 'JOBS=2', 'GTEST_FRAMEWORK_SRC=' + str(r / 'googletest'),
         'images', 'test-image-hotspot-jtreg-native', 'test-image-jdk-jtreg-native',
         'test-image-libtest-jtreg-native', 'test-image-lib-native', 'test-image-hotspot-gtest'])
    image = repo / 'build' / conf / 'images/jdk'
    dest = r / 'images' / ('layout-' + a.kind)
    assert not dest.exists()
    shutil.copytree(image, dest, copy_function=os.link)
    fixture = repo / 'build' / conf / 'images/test/lib/native/libVThreadPinner.so'
    assert fixture.exists()
    copies = []
    for suite in ['jdk', 'hotspot']:
        target = repo / 'build' / conf / ('images/test/' + suite + '/jtreg/native/libVThreadPinner.so')
        if target.exists(): assert target.read_bytes() == fixture.read_bytes()
        else: shutil.copy2(fixture, target)
        copies.append(str(target))
    assert fingerprint(pathlib.Path(state['preserved_image'])) == state['preserved_fingerprints']
    state.update(status='passed', path=str(dest), fingerprints=fingerprint(dest),
                 release=(dest / 'release').read_text(), shared_native_fixture_copies=copies)
    save()
