"""Freeze the completed first tier; retain every result and uncertainty interval."""
import datetime
import argparse
import hashlib
import json
import pathlib
import subprocess
import zipfile

p=argparse.ArgumentParser()
p.add_argument('--partial',action='store_true')
p.add_argument('--label',default='layout-stage-03-interpreter-warm')
a=p.parse_args()
assert '/' not in a.label and a.label.startswith('layout-')

r=pathlib.Path('/workspace/pr9-layout-validation')
repo=pathlib.Path('/workspace/openjdk-jdk27u')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
state=json.loads((r/'early-warm-state.json').read_text())
assert state['source']==source
assert state['status'] in (['early-int-warm','first-interpreter-tier-complete-awaiting-review'] if a.partial
                           else ['first-interpreter-tier-complete-awaiting-review'])
core=json.loads((r/'core-evidence.json').read_text());assert core['source']==source
manifest_bytes=(r/'final-warm/manifest.json').read_bytes()
manifest=json.loads(manifest_bytes)
assert manifest['images']['final']['source']==source
invocations=len(manifest['records']);forks=sum(len(x['results']) for x in manifest['records'])
assert (0<invocations<=144 and forks<=240) if a.partial else (invocations==144 and forks==240)
assert all(x['tier']=='int' and x['exit_code']==0 for x in manifest['records'])
out=pathlib.Path('/workspace/pr9-recovery')/a.label;out.mkdir()
files={}
for pattern in ['*.py','*.json','*.log','warm-tier-int/*.json','gtest-retained-files/*']:
    for p in r.glob(pattern):
        if p.is_file():files[str(p.relative_to(r))]=p
for row in manifest['records']:
    for suffix in ['.json','.log']:
        p=r/'final-warm'/(row['name']+suffix)
        if suffix=='.json':assert hashlib.sha256(p.read_bytes()).hexdigest()==row['result_sha256']
        files[str(p.relative_to(r))]=p
files['final-warm/manifest.json']=r/'final-warm/manifest.json'
frozen={'final-warm/manifest.json':manifest_bytes}
followup=None
confirmation=r/'confirm-layout-hash/manifest.json'
if confirmation.exists():
    body=confirmation.read_bytes();extra=json.loads(body)
    assert extra['source']==source
    frozen['confirm-layout-hash/manifest.json']=body
    files['confirm-layout-hash/manifest.json']=confirmation
    for row in extra['records']:
        for suffix in ['.json','.log']:
            p=r/'confirm-layout-hash'/(row['name']+suffix)
            if suffix=='.json':assert hashlib.sha256(p.read_bytes()).hexdigest()==row['result_sha256']
            files[str(p.relative_to(r))]=p
    followup={'completed_invocations':len(extra['records']),'planned_invocations':50,
              'complete':len(extra['records'])==50 and all(x['exit_code']==0 for x in extra['records']),
              'scope':'Separate fixed10round5variant hash follow-up; previous0fb is a control, not current-source qualification.'}
for p in (r/'jmh').glob('*.jar'):files['jmh/'+p.name]=p
for p in (r/'jmh/classes').glob('First*.class'):files['jmh/classes/'+p.name]=p
for name in ['FirstBigInteger.java','FirstBigIntegerExact.java','CommonBigIntegerSquares.java']:
    files['fixture-sources/'+name]=r/name
for name in ['FirstUse.java','CommonBigIntegerCalls.java','CommonSmallIntrinsics.java']:
    files['fixture-sources/'+name]=pathlib.Path('/workspace/pr9-evidence/replacement-x64')/name
files['fixture-sources/CommonIntrinsics.java']=repo/'test/micro/org/openjdk/bench/vm/compiler/CommonIntrinsics.java'
files['ACTIVE_STATE.json']=pathlib.Path('/workspace/pr9-recovery/ACTIVE_STATE.json')
entries=[]
with zipfile.ZipFile(out/'interpreter-warm.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):
        data=frozen[name] if name in frozen else p.read_bytes();z.writestr(name,data)
        entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json',json.dumps(entries,indent=2)+'\n')
with zipfile.ZipFile(out/'interpreter-warm.zip') as z:assert z.testzip() is None
packet=out/'interpreter-warm.zip'
patch=subprocess.check_output(['git','-C',str(repo),'diff','c04d1ba1e96b2176ce8a8e56eacae73c2d356d2b',source])
(out/'candidate.patch').write_bytes(patch)
record={'source':source,'status':('partial-performance-interpreter-tier-in-progress' if a.partial
                                else 'partial-performance-interpreter-tier-complete'),
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'jmh_invocations':invocations,'parameter_forks':forks,'planned_fresh_pairs':4,'planned_workloads':15,
        'hash_followup':followup,
        'core_evidence':core,'archive':{'name':packet.name,'bytes':packet.stat().st_size,
                                      'sha256':hashlib.sha256(packet.read_bytes()).hexdigest()},
        'candidate_patch':{'base':'c04d1ba1e96b2176ce8a8e56eacae73c2d356d2b',
                           'path':'candidate.patch','sha256':hashlib.sha256(patch).hexdigest()},
        'scope':'Only completed forks from the first, prospectively selected interpreter warm tier. '
                'An in-progress snapshot does not qualify that tier. This does not qualify remaining warm tiers, cold/startup, '
                'C2 controls, full tier2, native ARM/Windows, or PR readiness.'}
exact=r/'early-exact-performance.json'
if exact.exists():
    state=json.loads(exact.read_text())
    record['exact_cold_phase']={k:state.get(k) for k in ['source','status','cases','raw_observations','output_sha256']}
confirmation=r/'exact-square-confirmation-analysis.json'
if confirmation.exists():
    state=json.loads(confirmation.read_text())
    record['exact_square_confirmation']={'source':state['source'],
        'published_on_comparison':state['summary']['call_ms']['comparisons']['before-on_final-on'],
        'feature_off_control_comparison':state['summary']['call_ms']['comparisons']['before-off_final-off'],
        'scope':state['scope']}
(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
