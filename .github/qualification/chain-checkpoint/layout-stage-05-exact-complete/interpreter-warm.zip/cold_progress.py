"""Inspect completed cold-case log records without racing the large JSON writer."""
import datetime
import json
import pathlib
import re

r=pathlib.Path('/workspace/pr9-layout-validation')
path=r/'early-exact-matrix.log';rows=[]
if path.exists():
    for line in path.read_text().splitlines():
        match=re.match(r'^((?:int|c1-l1|c1-l3|c2)-(?:multiply|product|modpow)-\d+) (\{.*\})$',line)
        if not match:continue
        try:summary=json.loads(match[2])
        except json.JSONDecodeError:continue
        rows.append({'case':match[1],'summary':summary})
signals=[]
for row in rows:
    for metric,data in row['summary'].items():
        comparison=data['comparisons']['before-on_final-on']
        if comparison['paired_95_ci_ms'][0]>0:
            signals.append({'case':row['case'],'metric':metric,'comparison':comparison})
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'completed_cases':len(rows),'planned_cases':24,'last':rows[-1]['case'] if rows else None,
    'positive_95_beforeon_finalon':signals}))
