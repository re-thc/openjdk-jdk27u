"""Measure the original exact-size cold phase once, before the broad tier2 run."""
import hashlib
import json
import os
import pathlib
import subprocess
import time
from performance_environment import snapshot

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
decision=json.loads((r/'hash-review-decision.json').read_text())
assert decision['source']==source and decision['continue_qualification']
assert not subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True).stdout.strip()
assert subprocess.check_output(['git','-C','/workspace/openjdk-jdk27u','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','-C','/workspace/openjdk-jdk27u','status','--porcelain'],text=True).strip()
path=r/'early-exact-performance.json';assert not path.exists()
state={'source':source,'status':'preparing','scope':'The prospectively defined exact-size phase of the final matrix, '
       'measured before full tier2. Final phase reuse must match images, fixture bytecode, VM flags and commands. '
       'This is not complete performance, tier2 or native qualification.'}
def save():path.write_text(json.dumps(state,indent=2)+'\n')
save();state['environment_before']=snapshot('early-exact-before');save()
images=json.loads((r/'images.json').read_text());assert images['final']['source']==source
original=os.sched_getaffinity(0);os.sched_setaffinity(0,{min(original)});prep=[]
for role,image in images.items():
    base=pathlib.Path(image['path'])
    for file,fp in image['fingerprints'].items():
        h=hashlib.sha256()
        with (base/file).open('rb') as stream:
            for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
        assert h.hexdigest()==fp['sha256'],(role,file)
    library=base/'lib/server/libjvm.so';data=library.read_bytes()
    with library.open('r+b') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    assert hashlib.sha256(library.read_bytes()).hexdigest()==image['fingerprints']['lib/server/libjvm.so']['sha256']
    prep.append({'image':role,'sha256':hashlib.sha256(data).hexdigest(),'rewritten_unchanged':True})
os.sched_setaffinity(0,original)
(r/'early-exact-library-preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
arguments=['python3',str(r/'cold_matrix.py'),'first','--blocks','120','--sizes','512,4096',
           '--operations','multiply,product,modpow','--fixture','FirstBigIntegerExact',
           '--output','final-first-exact.json']
command=['python3',str(r/'run_reaped.py'),str(r/'early-exact-matrix.log'),*arguments]
state.update(status='measuring',command=command);save();start=time.time()
code=subprocess.run(command,cwd='/workspace/openjdk-jdk27u').returncode
state.update(exit_code=code,seconds=time.time()-start)
if code:state['status']='blocked-for-review';save();raise SystemExit(code)
data=json.loads((r/'final-first-exact.json').read_text())
assert data['images']==images and data['blocks']==120 and len(data['results'])==24
assert all(x['status']=='passed' and len(x['raw'])==700 for x in data['results'].values())
state.update(status='measurements-complete-awaiting-review',cases=24,raw_observations=16800,
             output_sha256=hashlib.sha256((r/'final-first-exact.json').read_bytes()).hexdigest(),
             environment_after=snapshot('early-exact-after'))
save()
