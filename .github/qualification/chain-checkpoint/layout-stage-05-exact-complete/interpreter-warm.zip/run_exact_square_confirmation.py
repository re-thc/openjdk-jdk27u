"""A single fixed prospective follow-up of the only exact-phase positive signal."""
import hashlib
import json
import os
import pathlib
import subprocess
import time
from performance_environment import snapshot

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
plan=json.loads((r/'exact-square-confirmation-plan.json').read_text())
assert plan['source']==source and plan['blocks']==360
assert json.loads((r/'early-exact-performance.json').read_text())['status']=='measurements-complete-awaiting-review'
assert not subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True).stdout.strip()
images=json.loads((r/'images.json').read_text());assert images['final']['source']==source
state={'source':source,'status':'preparing','plan':plan};path=r/'exact-square-confirmation.json';assert not path.exists()
def save():path.write_text(json.dumps(state,indent=2)+'\n')
save();state['environment_before']=snapshot('exact-square-confirmation-before');save()
affinity=os.sched_getaffinity(0);os.sched_setaffinity(0,{min(affinity)});prep=[]
for role,image in images.items():
    base=pathlib.Path(image['path'])
    for name,fp in image['fingerprints'].items():
        h=hashlib.sha256()
        with (base/name).open('rb') as stream:
            for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
        assert h.hexdigest()==fp['sha256'],(role,name)
    lib=base/'lib/server/libjvm.so';data=lib.read_bytes()
    with lib.open('r+b') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    assert hashlib.sha256(lib.read_bytes()).hexdigest()==image['fingerprints']['lib/server/libjvm.so']['sha256']
    prep.append({'image':role,'sha256':hashlib.sha256(data).hexdigest(),'rewritten_unchanged':True})
os.sched_setaffinity(0,affinity)
(r/'exact-square-confirmation-library-preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
command=['python3',str(r/'run_reaped.py'),str(r/'exact-square-confirmation-matrix.log'),
         'python3',str(r/'cold_matrix.py'),'first','--blocks','360','--tiers','c1-l1',
         '--sizes','4096','--operations','multiply','--fixture','FirstBigIntegerExact',
         '--output','confirm-exact-c1l1-square.json']
state.update(status='measuring',command=command);save();start=time.time()
code=subprocess.run(command,cwd='/workspace/openjdk-jdk27u').returncode
state.update(exit_code=code,seconds=time.time()-start)
if code:state['status']='blocked-for-review';save();raise SystemExit(code)
data=json.loads((r/'confirm-exact-c1l1-square.json').read_text())
assert data['images']==images and len(data['results'])==1
case=data['results']['c1-l1-multiply-4096'];assert case['status']=='passed' and len(case['raw'])==1900
review={'source':source,'summary':case['summary'],
        'original_signal':plan['original_signal'],'raw_sha256':hashlib.sha256((r/'confirm-exact-c1l1-square.json').read_bytes()).hexdigest(),
        'scope':'The fixed360block follow-up; all original120block observations remain intact. No repeated-until-pass sampling.'}
(r/'exact-square-confirmation-analysis.json').write_text(json.dumps(review,indent=2)+'\n')
state.update(status='measurements-complete-awaiting-review',environment_after=snapshot('exact-square-confirmation-after'))
save();print(json.dumps(review,indent=2),flush=True)
