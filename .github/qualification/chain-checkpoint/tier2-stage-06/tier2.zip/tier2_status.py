import json
import os
import pathlib

r = pathlib.Path('/workspace/pr9-validation')
for kind in ['release', 'fastdebug']:
    d = json.loads((r / f'tier2-{kind}.json').read_text())
    print(kind, d['status'], 'main groups complete', len(d['cohorts']))
active = []
for p in sorted(r.glob('clean-*-tier2-*.log')):
    if (r / (p.stem + '.result.json')).exists():
        continue
    lines = p.read_text(errors='replace').splitlines()
    if not lines:
        continue
    row = {'name': p.stem, 'passed': sum(x.startswith('Passed:') for x in lines),
           'failed': sum(x.startswith('FAILED:') for x in lines),
           'last': lines[-1]}
    counts = {'executed_passed': 0, 'skipped': 0, 'failed': 0, 'error': 0}
    for jtr in (r / (p.stem + '-work')).rglob('*.jtr'):
        with jtr.open(errors='replace') as stream:
            status = next((line.strip() for line in stream if line.startswith('execStatus=')), '')
        if status.startswith('execStatus=Passed. Skipped'):
            counts['skipped'] += 1
        elif status.startswith('execStatus=Passed.'):
            counts['executed_passed'] += 1
        elif status.startswith('execStatus=Failed.'):
            counts['failed'] += 1
        elif status.startswith('execStatus=Error.'):
            counts['error'] += 1
    row['reported_passed'] = row.pop('passed')
    row.update(counts)
    active.append(row)
    print(json.dumps(row))
states = []
for p in pathlib.Path('/proc').iterdir():
    if p.name.isdigit():
        try:
            text = (p / 'stat').read_text()
            states.append(text[text.rfind(')') + 2])
        except OSError:
            pass
s = os.statvfs('/workspace')
print(json.dumps({'active_batches': len(active),
                  'tasks': int(pathlib.Path('/sys/fs/cgroup/pids.current').read_text()),
                  'zombies': states.count('Z'),
                  'free_GiB': round(s.f_bavail * s.f_frsize / 2**30, 2)}))
