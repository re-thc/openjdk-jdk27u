import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys

def progress(message):
    try:
        print(message, flush=True)
    except BrokenPipeError:
        null_fd = os.open(os.devnull, os.O_WRONLY)
        os.dup2(null_fd, sys.stdout.fileno())
        os.close(null_fd)

p = argparse.ArgumentParser()
p.add_argument('name')
p.add_argument('jdk')
p.add_argument('tests', nargs='+')
p.add_argument('--vmoptions', default='-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx512m -Dseed=42')
p.add_argument('--concurrency', type=int, default=1)
p.add_argument('--exclude', default='/workspace/openjdk-jdk27u/test/hotspot/jtreg/ProblemList.txt')
p.add_argument('--nativepath', default='/workspace/openjdk-jdk27u/build/pr9-release/images/test/hotspot/jtreg/native')
p.add_argument('--environment', action='append', default=[])
a = p.parse_args()
root = Path('/workspace/pr9-validation')
source_checkout = subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                          cwd='/workspace/openjdk-jdk27u', text=True).strip()
# A bounded independent batch may reach this group before the main sequence.
# Serialize identical names and preserve the original result and JTRs.
batch_lock = (root / (a.name + '.lock')).open('a')
fcntl.flock(batch_lock, fcntl.LOCK_EX)
result_path = root / (a.name + '.result.json')
log_path = root / (a.name + '.log')
previous_command = None
if result_path.exists():
    previous_command = json.loads(result_path.read_text())['command']
elif log_path.exists():
    previous_command = json.loads(log_path.read_text().splitlines()[0])['command']
# Match make/RunTests.gmk:914-919 for new batches. Active/complete batches
# keep their original selection, allowing exact-command reuse without reruns.
selection = ('automatic' if previous_command is None or '-automatic' in previous_command
             else 'legacy-all-tests')
selection_flags = ['-automatic', '-ignore:quiet'] if selection == 'automatic' else []
retention_flags = (['-retain:fail,error'] if previous_command is None or
                   '-retain:fail,error' in previous_command else [])
previous_vmoptions = (next((x for x in previous_command if x.startswith('-vmoptions:')), '')
                      if previous_command is not None else '')
if ('-Dtest.boot.jdk=' not in a.vmoptions and
        (previous_command is None or '-Dtest.boot.jdk=' in previous_vmoptions)):
    a.vmoptions += ' -Dtest.boot.jdk=/workspace/toolchains/jdk27'
command = ['/workspace/toolchains/jdk27/bin/java', '-XX:TieredStopAtLevel=1', '-XX:ActiveProcessorCount=1',
           '-XX:+UseSerialGC', '-Xmx512m', '-jar', '/workspace/toolchains/jtreg83/lib/jtreg.jar',
           '-jdk:' + a.jdk, '-othervm', '-conc:' + str(a.concurrency), '-timeoutFactor:4',
           '-v:summary', *selection_flags, *retention_flags,
           *['-e:' + value for value in a.environment], '-exclude:' + a.exclude,
           '-nativepath:' + a.nativepath, '-vmoptions:' + a.vmoptions,
           '-w:' + str(root / (a.name + '-work')), '-r:' + str(root / (a.name + '-report')), *a.tests]
if result_path.exists():
    previous = json.loads(result_path.read_text())
    if previous['command'] != command or previous['source_checkout_at_start'] != source_checkout:
        raise RuntimeError('Refusing to overwrite a batch with a different command or source: ' + a.name)
    (root / (a.name + '.reuse.json')).write_text(json.dumps({
        'original_result': str(result_path), 'command_and_source_match': True,
        'exit_code': previous['exit_code'], 'selection': selection}, indent=2) + '\n')
    progress('Reusing unchanged completed batch: ' + a.name)
    raise SystemExit(previous['exit_code'])
progress(a.name)
result = subprocess.run(['python3', str(root / 'run_reaped.py'), str(root / (a.name + '.log')), *command],
                        cwd='/workspace/openjdk-jdk27u', pass_fds=(batch_lock.fileno(),))
summary = root / (a.name + '-report/text/summary.txt')
record = {'name': a.name, 'command': command, 'exit_code': result.returncode,
          'summary': summary.read_text() if summary.exists() else '',
          'source_checkout_at_start': source_checkout, 'selection': selection}
(root / (a.name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n')
progress(record['summary'])
raise SystemExit(result.returncode)
