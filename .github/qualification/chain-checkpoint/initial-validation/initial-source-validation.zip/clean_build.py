import argparse, fcntl, hashlib, json, pathlib, shlex, shutil, subprocess, time
p=argparse.ArgumentParser();p.add_argument('kind',choices=['release','fastdebug']);p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
r=pathlib.Path('/workspace/openjdk-jdk27u');v=pathlib.Path('/workspace/pr9-validation');conf='pr9-'+a.kind
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
subprocess.run(['git','diff','--exit-code'],cwd=r,check=True,stdout=subprocess.DEVNULL)
spec=(r/'build'/conf/'spec.gmk').read_text();line=next(x.split(':=',1)[1].strip() for x in spec.splitlines() if x.startswith('CONFIGURE_COMMAND_LINE :='));args=shlex.split(line)
args=[f'--with-jobs={a.jobs}' if x.startswith('--with-jobs=') else ('--with-native-debug-symbols=internal' if a.kind=='fastdebug' and x.startswith('--with-native-debug-symbols=') else x) for x in args]
commands=[['bash','configure',*args],['make','CONF='+conf,'JOBS='+str(a.jobs),'clean'],['make','CONF='+conf,'JOBS='+str(a.jobs),'GTEST_FRAMEWORK_SRC='+str(v/'googletest'),'images','test-image-hotspot-jtreg-native','test-image-jdk-jtreg-native','test-image-libtest-jtreg-native','test-image-hotspot-gtest']]
record={'source':source,'configuration':conf,'clean':True,'commands':[],'status':'running'}
def save(): (v/('clean-'+a.kind+'.json')).write_text(json.dumps(record,indent=2)+'\n')
for command in commands:
 start=time.time();print(json.dumps({'command':command}),flush=True)
 if command[:2]==['bash','configure']:
  with (v/'configure.lock').open('w') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX);code=subprocess.run(command,cwd=r).returncode
 else:code=subprocess.run(command,cwd=r).returncode
 record['commands'].append({'command':command,'exit_code':code,'seconds':time.time()-start});save()
 if code:record['status']='failed';save();raise SystemExit(code)
subprocess.run(['git','diff','--exit-code'],cwd=r,check=True,stdout=subprocess.DEVNULL)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
image=r/'build'/conf/'images/jdk';dest=v/'images'/('clean-'+a.kind)
shutil.copytree(image,dest,dirs_exist_ok=True)
record.update(status='passed',path=str(dest),release=(dest/'release').read_text(),fingerprints={n:{'bytes':(dest/n).stat().st_size,'sha256':hashlib.sha256((dest/n).read_bytes()).hexdigest()} for n in ['lib/server/libjvm.so','lib/modules','lib/server/classes.jsa']})
save();print(json.dumps({'status':'passed','source':source,'path':str(dest)}),flush=True)
