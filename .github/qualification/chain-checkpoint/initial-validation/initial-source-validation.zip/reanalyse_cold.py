import json,math,pathlib,statistics
from scipy.stats import t
r=pathlib.Path('/workspace/pr9-validation');out={}
for name in ['first-matrix','quadratic-first','workload-first','workload-product','product-crossover','product-c1l3-crossover','chain-product']:
 d=json.loads((r/(name+'.json')).read_text());cases={}
 for k,v in d['results'].items():
  if v['status']!='passed':continue
  samples={label:[x['call_ms'] for x in v['raw'] if x['block']>=d['discarded_blocks'] and x['label']==label] for label in ['master','before-off','before-on','final-off','final-on']}
  comparisons={}
  for left,right in [('master','final-on'),('before-on','final-on'),('before-off','final-off'),('final-off','final-on')]:
   values=[y-x for x,y in zip(samples[left],samples[right])];mean=statistics.mean(values);critical=float(t.ppf(.975,len(values)-1));half=critical*statistics.stdev(values)/math.sqrt(len(values));comparisons[left+'_'+right]={'difference_ms':mean,'paired_95_ci_ms':[mean-half,mean+half],'samples':len(values),'t_critical':critical}
  cases[k]={'means':{label:statistics.mean(values) for label,values in samples.items()},'comparisons':comparisons}
 out[name]={'images':d['images'],'results':cases}
(r/'cold-statistical-reanalysis.json').write_text(json.dumps({'method':'Paired Student t 95%, fresh JVM block as unit. Original exploratory files used 1.98 as an approximate critical value; retain original samples and summaries.','runs':out},indent=2)+'\n')
