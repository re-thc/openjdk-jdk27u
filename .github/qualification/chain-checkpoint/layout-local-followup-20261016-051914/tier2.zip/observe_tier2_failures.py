"""Match new failures only to precise, retained baseline control evidence."""
import collections
import hashlib
import json
import pathlib
import re
from harness_trace_records import trace_records

r=pathlib.Path('/workspace/pr9-layout-validation')
old=pathlib.Path('/workspace/pr9-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
control_path=old/'tier2-failure-analysis.json'
known={x['test_jtr']:x for x in json.loads(control_path.read_text())['failures']}
rows=[]
trace_only=[]
for work in sorted(r.glob('clean-*-tier2-*-work')):
    recorded_tests=set()
    for jtr in sorted(work.rglob('*.jtr')):
        data=jtr.read_bytes();text=data.decode(errors='replace')
        test=re.search(r'^test=(.*)$',text,re.M)
        if test:recorded_tests.add(test[1].replace('\\#','#'))
        status=re.search(r'^execStatus=(Failed|Error)\.(.*)$',text,re.M)
        if status is None:continue
        rel=str(jtr.relative_to(work));classification='unclassified';proof=None;followup=None
        if (work.name=='clean-fastdebug-tier2-jdk-io-tools-time-work' and status[1]=='Error' and
            ('Cannot create directories for ' in status[2] or "Can't create " in status[2])):
            classification='harness-scratch-directory-setup-error'
        isolated_path=r/'readxbytes-isolated.json'
        if (work.name=='clean-release-tier2-jdk-io-tools-time-work' and
            rel=='java/nio/channels/Channels/ReadXBytes.jtr' and '137' in status[2] and isolated_path.exists()):
            isolated=json.loads(isolated_path.read_text())
            if isolated['status']=='passed-one-isolated-release-case':
                passed_jtr=r/isolated['jtr'];passed_data=passed_jtr.read_bytes()
                assert isolated['source']==source and isolated['original_jtr_sha256']==hashlib.sha256(data).hexdigest()
                assert isolated['oom_kill_delta']==0 and not isolated['concurrent_java_at_launch']
                assert hashlib.sha256(passed_data).hexdigest()==isolated['jtr_sha256']
                assert 'execStatus=Passed. Execution successful' in passed_data.decode()
                assert '-Xmx12g' in passed_data.decode()
                classification='resource-suspected-exit137-with-isolated-pass'
                followup={'path':isolated['jtr'],'sha256':isolated['jtr_sha256'],
                          'receipt':'readxbytes-isolated.json',
                          'receipt_sha256':hashlib.sha256(isolated_path.read_bytes()).hexdigest(),
                          'scope':'Original failure retained. Same-image isolated case passed; historical kernel victim remains unidentified.'}
        if rel in known and known[rel]['message'] in text:
            detail=known[rel]
            baseline=old/detail['reproduced']['master-default']
            if baseline.exists() and detail['message'] in baseline.read_text(errors='replace'):
                matched=True
                if rel.endswith('/Cleaners.jtr'):
                    current_child=work/'sun/security/krb5/auto/Cleaners/server.stderr'
                    baseline_child=old/detail['native_server_stderr']['master']['path']
                    matched=(current_child.exists() and baseline_child.exists() and
                             detail['native_cause_message'] in current_child.read_text(errors='replace') and
                             detail['native_cause_message'] in baseline_child.read_text(errors='replace'))
                if matched:
                    classification=detail['category']
                    proof={'source':'87edd79d3104ff502f7befec034716b081436f49',
                           'path':str(baseline),'sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),
                           'scope':'Retained historical baseline control, not a new-source test pass.'}
                    if rel.endswith('/Cleaners.jtr'):
                        proof['baseline_child_stderr']={'path':str(baseline_child),
                            'sha256':hashlib.sha256(baseline_child.read_bytes()).hexdigest()}
                        proof['current_child_stderr']={'path':str(current_child),
                            'sha256':hashlib.sha256(current_child.read_bytes()).hexdigest()}
        rows.append({'cohort':work.name.removesuffix('-work'),'test_jtr':rel,
                     'path':str(jtr.relative_to(r)),'sha256':hashlib.sha256(data).hexdigest(),
                     'status':status[1],'detail':status[2],'classification':classification,
                     'baseline_control':proof,'followup_control':followup})
    for item in trace_records(work):
        if item['outcome'] not in ['Failed','Error'] or item['test'] in recorded_tests:continue
        classification='unclassified'
        if (work.name=='clean-fastdebug-tier2-jdk-io-tools-time-work' and item['outcome']=='Error' and
            ('Cannot create directories for ' in item['status'] or "Can't create " in item['status'])):
            classification='harness-scratch-directory-setup-error'
        trace_only.append(dict(item,cohort=work.name.removesuffix('-work'),classification=classification,
                               jtr_available=False))
counts=dict(collections.Counter(x['classification'] for x in rows+trace_only))
record={'source':source,'status':'investigation-required' if counts.get('unclassified') else 'observed-failures-classified',
        'counts':counts,'failed_jtrs':rows,'trace_only_failures':trace_only,
        'historical_control_index':{'source':json.loads(control_path.read_text())['source'],
             'path':str(control_path),'sha256':hashlib.sha256(control_path.read_bytes()).hexdigest()},
        'scope':'Current-source failures stay failures. Matching named baseline causes does not certify clean tier2.'}
(r/'tier2-observed-failures.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'counts':counts,'trace_only_failures':len(trace_only),
                  'unknown':[x for x in rows+trace_only if x['classification']=='unclassified']},indent=2))
