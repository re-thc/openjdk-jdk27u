"""Observe existing follow-up workers without restarting them."""
import datetime
import json
from pathlib import Path
import shutil
import time

r = Path('/workspace/pr9-layout-validation')
path = r / 'setup-followups-active-resources.jsonl'
assert not path.exists(), 'Do not duplicate the observer'
repair = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'reason': 'The resumed controller monitor used exclusive creation against the preserved preflight resource file. Its monitor thread failed before recording active samples; batch readiness checks still ran. Start this observer for the existing worker, without restarting a test. Earlier per-second active coverage is absent.',
          'samples': str(path), 'no_test_restart': True}
(r / 'setup-resource-monitor-repair.json').write_text(json.dumps(repair, indent=2) + '\n')
with path.open('x') as log:
    while True:
        try:
            state = json.loads((r / 'setup-followups.json').read_text())
        except json.JSONDecodeError:
            time.sleep(.1); continue
        c = Path('/sys/fs/cgroup')
        stats = dict(line.split() for line in (c / 'memory.stat').read_text().splitlines())
        record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'state': state['status'], 'free_bytes': shutil.disk_usage('/workspace').free,
                  'memory_current': int((c / 'memory.current').read_text()),
                  'memory_anon': int(stats['anon']), 'memory_events': (c / 'memory.events').read_text(),
                  'tasks': int((c / 'pids.current').read_text())}
        log.write(json.dumps(record) + '\n'); log.flush()
        if state['status'] in ['completed-unmet-setup-cases', 'blocked-for-review']:
            break
        time.sleep(1)
