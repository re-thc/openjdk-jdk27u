"""Read explicit harness outcomes without inventing missing JTR files."""
import hashlib
from pathlib import Path
import re

def trace_records(work):
    path = Path(work) / 'jtData/harness.trace'
    if not path.exists():
        return []
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    records = {}
    for line in data.decode(errors='replace').splitlines():
        match = re.match(r'^(\S+) Finished: \([^)]*\) (.+?): (Passed|Failed|Error|Not run)\. ?(.*)$', line)
        if match:
            assert match[2] not in records, ('Repeated harness outcome requires review', str(path), match[2])
            records[match[2]] = {'test': match[2], 'utc': match[1], 'outcome': match[3],
                                 'status': match[3] + '. ' + match[4], 'trace_line': line,
                                 'trace_path': str(path), 'trace_sha256': digest}
    return list(records.values())
