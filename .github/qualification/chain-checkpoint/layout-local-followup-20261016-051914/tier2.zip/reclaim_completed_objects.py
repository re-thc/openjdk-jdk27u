"""Reserve qualification space by discarding only completed link inputs."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess

r = Path('/workspace/pr9-layout-validation')
repo = Path('/workspace/openjdk-jdk27u')
record_path = r / 'completed-object-reclaim.json'
assert not record_path.exists(), 'Do not repeat completed reclamation'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == 'e41d7823bf6de77c4bfba52e896bf325221488cb'
processes = subprocess.run(['ps', '-C', 'make,gmake,cc1,cc1plus,gcc,g++', '-o', 'pid='], capture_output=True, text=True, check=False)
assert not processes.stdout.strip(), 'A build is active'
files = []
for conf in ['cloud', 'cloud-gcc16', 'pr9-release']:
    directory = repo / 'build' / conf / 'hotspot/variant-server/libjvm/objs'
    assert directory.is_dir() and directory.resolve() == directory
    objects = sorted(directory.glob('*.o'))
    assert objects and all(stat.S_ISREG(f.lstat().st_mode) for f in objects)
    files.extend(objects)

def image_hashes():
    rows = []
    for conf in ['cloud', 'cloud-gcc16', 'pr9-release', 'pr9-fastdebug']:
        image = repo / 'build' / conf / 'images/jdk'
        for name in ['lib/server/libjvm.so', 'lib/modules', 'lib/server/classes.jsa', 'release']:
            file = image / name
            if file.exists():
                with file.open('rb') as handle:
                    digest = hashlib.file_digest(handle, 'sha256').hexdigest()
                rows.append({'file': str(file), 'bytes': file.stat().st_size, 'sha256': digest})
    return rows

record = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'prepared', 'reason': 'Reserve disk headroom for unmet ordinary qualification; no active builds. Only disposable native link inputs are removed; images, exploded modules, tests, logs, archives and evidence remain.',
          'free_before': shutil.disk_usage('/workspace').free,
          'image_hashes_before': image_hashes(),
          'objects': [{'path': str(f.relative_to(repo)), 'bytes': f.stat().st_size} for f in files]}
record_path.write_text(json.dumps(record, indent=2) + '\n')
for file in files:
    file.unlink()
record.update(status='completed', deleted_count=len(files),
              deleted_bytes=sum(x['bytes'] for x in record['objects']),
              free_after=shutil.disk_usage('/workspace').free,
              image_hashes_after=image_hashes())
assert record['image_hashes_before'] == record['image_hashes_after']
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['status', 'deleted_count', 'deleted_bytes', 'free_before', 'free_after']}))
