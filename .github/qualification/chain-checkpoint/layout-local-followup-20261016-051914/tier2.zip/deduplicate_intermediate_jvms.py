"""Retain intermediate paths while sharing identical immutable JVM payloads."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

r = Path('/workspace/pr9-layout-validation')
base = Path('/workspace/openjdk-jdk27u/build/pr9-fastdebug')
record_path = r / 'intermediate-jvm-deduplication.json'
assert not record_path.exists()
assert not subprocess.run(['ps', '-C', 'make,gmake,cc1,cc1plus,gcc,g++', '-o', 'pid='], capture_output=True, text=True).stdout.strip()
groups = [(base / 'images/jdk/lib/server/libjvm.so', [
    base / 'support/interim-image/lib/server/libjvm.so']),
    (base / 'jdk/lib/server/libjvm.so', [base / 'support/modules_libs/java.base/server/libjvm.so']),
    (base / 'images/test/hotspot/gtest/server/libjvm.so', [base / 'hotspot/variant-server/libjvm/gtest/libjvm.so'])]

def digest(file):
    with file.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

rows = []
for original, copies in groups:
    original_hash = digest(original)
    for copy in copies:
        a, b = original.stat(), copy.lstat()
        assert stat.S_ISREG(b.st_mode) and copy.resolve() == copy
        assert a.st_dev == b.st_dev and stat.S_IMODE(a.st_mode) == stat.S_IMODE(b.st_mode)
        assert a.st_ino != b.st_ino and a.st_size == b.st_size
        assert digest(copy) == original_hash
        rows.append({'original': str(original), 'copy': str(copy), 'bytes': b.st_size,
                     'sha256': original_hash, 'old_inode': b.st_ino, 'original_inode': a.st_ino})
record = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'prepared', 'free_before': shutil.disk_usage('/workspace').free,
          'reason': 'Existing space guard stopped before any follow-up test. Byte-identical completed build intermediates can share the retained image payload. No image path/content, test, result, log or archive is removed.',
          'files': rows}
record_path.write_text(json.dumps(record, indent=2) + '\n')
for row in rows:
    original, copy = Path(row['original']), Path(row['copy'])
    temporary = copy.with_name(copy.name + '.pr9-identical-link')
    assert not temporary.exists()
    os.link(original, temporary)
    os.replace(temporary, copy)
    assert copy.stat().st_ino == original.stat().st_ino and digest(copy) == row['sha256']
record.update(status='completed', free_after=shutil.disk_usage('/workspace').free)
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'free_before', 'free_after']}))
