import json
import os
import pathlib
import re
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
def read_json(path):
    for attempt in range(5):
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError:
            if attempt == 4:
                raise
            time.sleep(.1)
for kind in ['release', 'fastdebug']:
    d = read_json(r / f'tier2-{kind}.json')
    print(kind, d['status'], 'main groups complete', len(d['cohorts']))
active = []
for p in sorted(r.glob('clean-*-tier2-*.log')):
    if (r / (p.stem + '.result.json')).exists():
        continue
    lines = p.read_text(errors='replace').splitlines()
    if not lines:
        continue
    row = {'name': p.stem, 'passed': sum(x.startswith('Passed:') for x in lines),
           'failed': sum(x.startswith('FAILED:') for x in lines),
           'last': lines[-1]}
    counts = {'executed_passed': 0, 'skipped': 0, 'failed': 0, 'error': 0}
    for jtr in (r / (p.stem + '-work')).rglob('*.jtr'):
        with jtr.open(errors='replace') as stream:
            status = next((line.strip() for line in stream if line.startswith('execStatus=')), '')
        if status.startswith('execStatus=Passed. Skipped'):
            counts['skipped'] += 1
        elif status.startswith('execStatus=Passed.'):
            counts['executed_passed'] += 1
        elif status.startswith('execStatus=Failed.'):
            counts['failed'] += 1
        elif status.startswith('execStatus=Error.'):
            counts['error'] += 1
    row['persisted_jtr_errors'] = counts['error']
    log_errors = sum(line.startswith('Error:') for line in lines)
    row['error_outcomes_without_jtr'] = max(0, log_errors - counts['error'])
    counts['error'] = max(counts['error'], log_errors)
    row['reported_passed'] = row.pop('passed')
    row.update(counts)
    active.append(row)
    print(json.dumps(row))
totals = {'executed_passed': 0, 'skipped': 0, 'failed': 0, 'error': 0}
for row in active:
    for key in totals:
        totals[key] += row[key]
completed_batches = 0
for path in r.glob('clean-*-tier2-*.result.json'):
    if path.name.endswith('.log.result.json'):
        continue
    data = read_json(path)
    completed_batches += 1
    for line in data['summary'].splitlines():
        match = re.search(r'\s(Passed|Failed|Error)\.(.*)$', line)
        if match:
            key = ('skipped' if match[1] == 'Passed' and match[2].startswith(' Skipped') else
                   {'Passed': 'executed_passed', 'Failed': 'failed', 'Error': 'error'}[match[1]])
            totals[key] += 1
states = []
pid1_zombies = 0
for p in pathlib.Path('/proc').iterdir():
    if p.name.isdigit():
        try:
            text = (p / 'stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            states.append(fields[0])
            if fields[0] == 'Z' and fields[1] == '1':
                pid1_zombies += 1
        except OSError:
            pass
s = os.statvfs('/workspace')
print(json.dumps({'active_batches': len(active),
                  'completed_batches': completed_batches, 'total_observed_counts': totals,
                  'tasks': int(pathlib.Path('/sys/fs/cgroup/pids.current').read_text()),
                  'zombies': states.count('Z'),
                  'pid1_zombies': pid1_zombies,
                  'free_GiB': round(s.f_bavail * s.f_frsize / 2**30, 2)}))
