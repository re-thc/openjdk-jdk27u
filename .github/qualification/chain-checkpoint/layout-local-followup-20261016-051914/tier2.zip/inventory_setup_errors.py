"""Reconcile every original harness error, including records without a JTR."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re

r = Path('/workspace/pr9-layout-validation')
name = 'clean-fastdebug-tier2-jdk-io-tools-time'
work = r / (name + '-work')
trace_path = work / 'jtData/harness.trace'
trace_data = trace_path.read_bytes()
log_data = (r / (name + '.log')).read_bytes()
snapshot = r / 'original-setup-error-trace.txt'
if not snapshot.exists():
    snapshot.write_bytes(trace_data)
trace_rows = []
for line in trace_data.decode(errors='replace').splitlines():
    m = re.match(r'^(\S+) Finished: \([^)]*\) (.+?): Error\. (.*)$', line)
    if m:
        trace_rows.append({'utc': m[1], 'test': m[2], 'status': 'Error. ' + m[3], 'trace_line': line})
log_tests = [line.removeprefix('Error:').strip() for line in log_data.decode(errors='replace').splitlines() if line.startswith('Error:')]
assert len(trace_rows) == len(log_tests) == 558
assert [x['test'] for x in trace_rows] == log_tests
assert len(set(log_tests)) == len(log_tests)
saved = {}
for file in work.rglob('*.jtr'):
    data = file.read_bytes()
    text = data.decode(errors='replace')
    test = re.search(r'^test=(.*)$', text, re.M)
    status = re.search(r'^execStatus=(.*)$', text, re.M)
    if test and status:
        saved[test[1].replace('\\#', '#')] = (file, data, status[1])
for row in trace_rows:
    test = row['test']
    assert test.startswith(('sun/nio/cs/', 'com/sun/jndi/', 'java/io/', 'java/nio/'))
    assert not any(word in test.lower() for word in ['cds', 'archive', 'aot', 'header'])
    if test in saved:
        file, data, status = saved[test]
        assert status.startswith('Error.'), (test, status)
        row['jtr'] = {'path': str(file.relative_to(r)), 'sha256': hashlib.sha256(data).hexdigest()}
    else:
        row['jtr'] = None
    source = Path('/workspace/openjdk-jdk27u/test/jdk') / test.split('#', 1)[0]
    assert source.is_file(), source
    row['source_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
inventory = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
             'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'original_cohort': name, 'errors': len(trace_rows),
             'saved_jtrs': sum(x['jtr'] is not None for x in trace_rows),
             'missing_jtrs': sum(x['jtr'] is None for x in trace_rows),
             'trace_snapshot': str(snapshot.relative_to(r)),
             'trace_snapshot_sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest(),
             'log_snapshot_sha256': hashlib.sha256(log_data).hexdigest(),
             'diagnosis': 'All 558 scratch-directory errors occur at 04:06:45-46. At that time release ZipFSOutputStreamTest runs its STORED case with a 2147483648-byte entry and 25 MiB second entry, including temporary-file/archive overlap. This establishes a concrete competing disk demand and a storage-contention explanation; no historical errno/free-space sample survives, so ENOSPC is not proven. Test bodies did not execute for these setup-error outcomes.',
             'readxbytes': 'Release exit137 coincides with an observed cgroup OOM-kill count increase; exact victim attribution is unavailable. Annotation -Xmx12g overrides batch1g on a16GiB cgroup. FD completed the same original case, so do not repeat FD. Release needs one isolated follow-up.',
             'errors_by_prefix': dict(collections.Counter('/'.join(x['test'].split('/')[:3]) for x in trace_rows)),
             'tests': trace_rows,
             'scope': 'Original errors remain errors. Execute only these unmet ordinary cases in fresh bounded workdirs; no stopped stress or native run is selected.'}
(r / 'setup-error-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
(r / 'setup-unmet-tests.txt').write_text('\n'.join(x['test'] for x in trace_rows) + '\n')
hold_path = r / 'qualification-hold.json'
hold = json.loads(hold_path.read_text())
hold['reason'] = '558 original harness directory-creation errors (37 saved JTRs and521 trace-only outcomes) plus release ReadXBytes exit137 require exact unmet-case follow-up. Final performance remains held.'
hold['ordinary_followup_authorization'] = 'Parent requested collection, diagnosis, demonstrated harness readiness repair and only unmet bounded ordinary tests. No native build or hosted run is approved.'
hold_path.write_text(json.dumps(hold, indent=2) + '\n')
print(json.dumps({key: inventory[key] for key in ['errors', 'saved_jtrs', 'missing_jtrs', 'errors_by_prefix']}))
