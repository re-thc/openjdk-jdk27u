"""Run the one failed release case after all other qualification VMs stop."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import threading
import time

r = Path('/workspace/pr9-layout-validation')
repo = Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
path = r / 'readxbytes-isolated.json'
assert not path.exists(), 'Do not duplicate the isolated case'
state = {'source': source, 'status': 'waiting-for-surviving-workers',
         'test': 'test/jdk/java/nio/channels/Channels/ReadXBytes.java',
         'scope': 'One unmet release case; keep its original -Xmx12g, source, flags and seed. FD already passed and is not selected. No native/hosted or stopped-stress execution.',
         'original_jtr': 'clean-release-tier2-jdk-io-tools-time-work/java/nio/channels/Channels/ReadXBytes.jtr'}
original = r / state['original_jtr']
state['original_jtr_sha256'] = hashlib.sha256(original.read_bytes()).hexdigest()
assert 'execStatus=Failed. Unexpected exit from test [exit code\\: 137]' in original.read_text()

def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tmp = path.with_suffix('.tmp'); tmp.write_text(json.dumps(state, indent=2) + '\n'); tmp.replace(path)

def read_json(file):
    for attempt in range(5):
        try: return json.loads(file.read_text())
        except json.JSONDecodeError:
            if attempt == 4: raise
            time.sleep(.1)

def resources():
    cgroup = Path('/sys/fs/cgroup')
    values = dict(line.split() for line in (cgroup / 'memory.stat').read_text().splitlines())
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'memory_current': int((cgroup / 'memory.current').read_text()),
            'memory_anon': int(values['anon']), 'memory_file': int(values['file']),
            'memory_max': int((cgroup / 'memory.max').read_text()),
            'memory_events': dict((name, int(value)) for name, value in (line.split() for line in (cgroup / 'memory.events').read_text().splitlines())),
            'disk_free': shutil.disk_usage('/workspace').free,
            'tasks': int((cgroup / 'pids.current').read_text())}

def live_java():
    rows = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit(): continue
        try:
            if (directory / 'comm').read_text().strip() not in ['java', 'javac', 'jlink', 'javadoc', 'jcmd']:
                continue
            fields = (directory / 'stat').read_text().rsplit(')', 1)[1].split()
            if fields[0] == 'Z': continue
            rows.append({'pid': int(directory.name), 'command': (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')})
        except OSError: pass
    return rows

save()
try:
    while True:
        setup = read_json(r / 'setup-followups.json')
        assert setup['status'] != 'blocked-for-review', setup.get('error')
        mains = [read_json(r / ('tier2-' + kind + '.json')) for kind in ['release', 'fastdebug']]
        complete = all(item['source'] == source and item['status'] in ['passed', 'has-failures'] and len(item['cohorts']) == 11 for item in mains)
        if complete and setup['status'] == 'completed-unmet-setup-cases' and not live_java(): break
        time.sleep(5)
    ready = resources()
    assert ready['memory_max'] - ready['memory_anon'] >= 14 * 1024**3, ready
    assert ready['disk_free'] >= 3 * 1024**3, ready
    assert not (r / 'final-performance.json').exists(), 'Final performance remains held'
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
    image = repo / 'build/pr9-release/images/jdk'
    build = read_json(r / 'clean-release.json')
    assert build['source'] == source and build['status'] == 'passed'
    for name, expected in build['fingerprints'].items():
        with (image / name).open('rb') as handle:
            assert hashlib.file_digest(handle, 'sha256').hexdigest() == expected['sha256']
    state.update(status='running-one-isolated-release-case', readiness=ready,
                 image_fingerprints=build['fingerprints'], concurrent_java_at_launch=live_java())
    assert not state['concurrent_java_at_launch']
    save()
    stop = threading.Event()
    def monitor():
        with (r / 'readxbytes-isolated-resources.jsonl').open('x') as log:
            while not stop.is_set():
                log.write(json.dumps(resources()) + '\n'); log.flush(); stop.wait(.5)
    thread = threading.Thread(target=monitor, daemon=True); thread.start()
    name = 'clean-release-tier2-readxbytes-isolated'
    command = ['python3', str(r / 'jtreg_batch.py'), name, str(image), '--concurrency=1',
               '--exclude=' + str(repo / 'test/jdk/ProblemList.txt'),
               '--nativepath=' + str(repo / 'build/pr9-release/images/test/jdk/jtreg/native'),
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g -Djdk.test.lib.random.seed=42 -Dseed=42',
               state['test']]
    try: code = subprocess.run(command, cwd=repo).returncode
    finally: stop.set(); thread.join()
    result = read_json(r / (name + '.result.json'))
    after = resources()
    state.update(exit_code=code, command=command, resources_after=after,
                 oom_kill_delta=after['memory_events']['oom_kill'] - ready['memory_events']['oom_kill'],
                 result_sha256=hashlib.sha256((r / (name + '.result.json')).read_bytes()).hexdigest(),
                 result=name + '.result.json')
    assert result['source_checkout_at_start'] == source and code == 0
    assert state['oom_kill_delta'] == 0
    jtr = r / (name + '-work/java/nio/channels/Channels/ReadXBytes.jtr')
    text = jtr.read_text()
    assert 'execStatus=Passed. Execution successful' in text and '-Xmx12g' in text
    state.update(status='passed-one-isolated-release-case', jtr=str(jtr.relative_to(r)),
                 jtr_sha256=hashlib.sha256(jtr.read_bytes()).hexdigest(),
                 conclusion='Original exit137 remains a failed resource-suspect outcome; one isolated same-image case passed with the original12g heap and no new OOM kill. The historical kernel victim is still unidentified.')
    save()
except BaseException as error:
    state.update(status='blocked-for-review', error=repr(error)); save(); raise
