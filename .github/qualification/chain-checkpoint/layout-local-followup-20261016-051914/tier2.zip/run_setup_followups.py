"""Finish exactly the ordinary cases left unmet by the original setup burst."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import threading
import time

r = Path('/workspace/pr9-layout-validation')
repo = Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
state_path = r / 'setup-followups.json'
if state_path.exists():
    previous = json.loads(state_path.read_text())
    assert previous['status'] == 'blocked-for-review' and not previous['batches']
    assert 'free_bytes' in previous['error'], 'Only a pre-test space guard may resume'
    backup = r / 'setup-followups.pre-space-readiness.json'
    assert not backup.exists()
    backup.write_bytes(state_path.read_bytes())
inventory = json.loads((r / 'setup-error-inventory.json').read_text())
assert inventory['source'] == source and inventory['errors'] == 558
build = json.loads((r / 'clean-fastdebug.json').read_text())
image = repo / 'build/pr9-fastdebug/images/jdk'
assert build['source'] == source and build['status'] == 'passed'
for name, expected in build['fingerprints'].items():
    with (image / name).open('rb') as handle:
        assert hashlib.file_digest(handle, 'sha256').hexdigest() == expected['sha256']
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
tests = [x['test'] for x in inventory['tests']]
assert len(tests) == len(set(tests)) == 558
charsets = [x for x in tests if x.startswith('sun/nio/cs/')]
others = [x for x in tests if x not in charsets]
blocks = [charsets] + [others[i:i + 32] for i in range(0, len(others), 32)]
assert len(charsets) == 37 and sum(map(len, blocks)) == 558
state = {'source': source, 'status': 'preflight', 'original_inventory': 'setup-error-inventory.json',
         'original_inventory_sha256': hashlib.sha256((r / 'setup-error-inventory.json').read_bytes()).hexdigest(),
         'total_cases': 558, 'max_batch_cases': 37, 'batches': [],
         'scope': 'Only original scratch-setup errors, no previously passed case or whole group. Original errors remain preserved. No native/hosted execution, source change, or stopped stress selection.'}

def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = state_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(state_path)

def resources():
    cgroup = Path('/sys/fs/cgroup')
    stat = dict(line.split() for line in (cgroup / 'memory.stat').read_text().splitlines())
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'free_bytes': shutil.disk_usage('/workspace').free,
            'memory_current': int((cgroup / 'memory.current').read_text()),
            'memory_anon': int(stat['anon']),
            'memory_events': (cgroup / 'memory.events').read_text(),
            'tasks': int((cgroup / 'pids.current').read_text())}

stop = threading.Event()
def monitor():
    with (r / 'setup-followups-resources.jsonl').open('a') as log:
        while not stop.is_set():
            log.write(json.dumps(resources()) + '\n'); log.flush()
            stop.wait(1)

save()
thread = threading.Thread(target=monitor, daemon=True)
thread.start()
try:
    for index, block in enumerate(blocks, 1):
        ready = resources()
        deadline = time.monotonic() + 900
        while ready['free_bytes'] < 4.5 * 1024**3:
            state.update(status='waiting-for-disk-headroom', readiness=ready)
            save()
            assert time.monotonic() < deadline, ready
            time.sleep(5)
            ready = resources()
        assert ready['memory_anon'] < 9 * 1024**3 and ready['tasks'] < 500, ready
        name = f'clean-fastdebug-tier2-setup-fill-{index:02d}'
        state['status'] = 'running-' + name
        state['active_tests'] = block
        state['readiness'] = ready
        save()
        command = ['python3', str(r / 'jtreg_batch.py'), name, str(image),
                   '--concurrency=1', '--exclude=' + str(repo / 'test/jdk/ProblemList.txt'),
                   '--nativepath=' + str(repo / 'build/pr9-fastdebug/images/test/jdk/jtreg/native'),
                   '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g -Djdk.test.lib.random.seed=42 -Dseed=42',
                   *['test/jdk/' + x for x in block]]
        code = subprocess.run(command, cwd=repo).returncode
        result_path = r / (name + '.result.json')
        result = json.loads(result_path.read_text())
        assert result['source_checkout_at_start'] == source
        state['batches'].append({'name': name, 'tests': block, 'command': command,
                                 'exit_code': code, 'result_sha256': hashlib.sha256(result_path.read_bytes()).hexdigest()})
        state['completed_cases'] = sum(len(x['tests']) for x in state['batches'])
        save()
        assert code == 0, 'Stop at the first failed bounded batch; preserve and inspect it'
    state['status'] = 'completed-unmet-setup-cases'
    state.pop('active_tests', None)
    save()
except BaseException as error:
    state.update(status='blocked-for-review', error=repr(error))
    save()
    raise
finally:
    stop.set(); thread.join()
