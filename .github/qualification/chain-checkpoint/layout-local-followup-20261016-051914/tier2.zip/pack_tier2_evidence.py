import argparse
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import zipfile

p = argparse.ArgumentParser()
p.add_argument('label')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
out = pathlib.Path('/workspace/pr9-recovery') / a.label
out.mkdir(parents=True, exist_ok=False)
source = subprocess.check_output(['git', '-C', '/workspace/openjdk-jdk27u',
                                  'rev-parse', 'HEAD'], text=True).strip()
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert source == 'e41d7823bf6de77c4bfba52e896bf325221488cb'
cohorts = []
files = set()
snapshots = {}
active = []
for result in sorted(r.glob('clean-*-tier2-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    d = json.loads(result.read_text())
    assert d['source_checkout_at_start'] == source
    name = result.name.removesuffix('.result.json')
    lines = d['summary'].splitlines()
    counts = {status: sum((' ' + status + '.') in line for line in lines)
              for status in ['Passed', 'Failed', 'Error', 'Not run']}
    counts['ReportedPassed'] = counts['Passed']
    counts['Skipped'] = sum(' Passed. Skipped' in line for line in lines)
    counts['Passed'] -= counts['Skipped']
    cohorts.append({'name': name, 'exit_code': d['exit_code'], 'counts': counts})
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-work')).rglob('*.stderr'))
    files.update((r / (name + '-report/text')).glob('*'))
    for trace_name in ['harness.trace', 'ResultCache2.jtw', 'logfile.log']:
        trace = r / (name + '-work/jtData') / trace_name
        if trace.is_file(): files.add(trace)
for log in sorted(r.glob('clean-*-tier2-*.log')):
    if (r / (log.stem + '.result.json')).exists():
        continue
    data = log.read_bytes()
    snapshots[log] = data
    lines = data.decode(errors='replace').splitlines()
    active.append({'name': log.stem, 'status': 'incomplete',
                   'passed_log_records': sum(x.startswith('Passed:') for x in lines),
                   'failed_log_records': sum(x.startswith('FAILED:') for x in lines)})
    for jtr in (r / (log.stem + '-work')).rglob('*.jtr'):
        data = jtr.read_bytes()
        lines = data.decode(errors='replace').splitlines()
        if lines and lines[-1].startswith('test result: '):
            snapshots[jtr] = data
    for stderr in (r / (log.stem + '-work')).rglob('*.stderr'):
        snapshots[stderr] = stderr.read_bytes()
    for trace_name in ['harness.trace', 'ResultCache2.jtw', 'logfile.log']:
        trace = r / (log.stem + '-work/jtData') / trace_name
        if trace.is_file(): snapshots[trace] = trace.read_bytes()
for name in ['tier2-release.json', 'tier2-fastdebug.json', 'run_tier2.py',
             'tier2-release.log', 'tier2-release.log.result.json',
             'tier2-fastdebug.log', 'tier2-fastdebug.log.result.json',
             'tier2-fastdebug-prefetch-jaxp.json', 'tier2-fastdebug-prefetch-jdk-net.json',
             'tier2-fastdebug-jaxp-prefetch.log', 'tier2-fastdebug-jaxp-prefetch.log.result.json',
             'tier2-fastdebug-net-prefetch.log', 'tier2-fastdebug-net-prefetch.log.result.json',
             'tier2-fastdebug-prefetch-langtools.json',
             'tier2-fastdebug-langtools-prefetch.log', 'tier2-fastdebug-langtools-prefetch.log.result.json',
             'tier2-fastdebug-nss-fill.log', 'tier2-fastdebug-nss-fill.log.result.json',
             'tier2-fastdebug-security-data-fill.log', 'tier2-fastdebug-security-data-fill.log.result.json',
             'jtreg_batch.py', 'run_reaped.py', 'pack_tier2_evidence.py',
             'tier2-runtime-selection.txt', 'tier2-classification.json',
             'reaper-prevention-before.json', 'reaper-prevention-after.json',
             'reaper_orphan_selftest.py', 'reaper-orphan-selftest.log',
             'reaper-orphan-selftest.log.result.json', 'classify_tier2.py',
             'analyze_tier2_failures.py', 'tier2-failure-analysis.json',
             'pr9-current-metadata.json', 'tier2-selection-correction.json',
             'tier2-reuse-preflight.json', 'observe_tier2_failures.py',
             'tier2-observed-failures.json', 'tier2-ldap-classification.json',
             'classify_ldap_dns.py', 'tier2-resource-check.json', 'tier2_status.py',
             'live_status.py', 'live-status.json',
             'qualification-hold.json', 'RECONCILIATION.md',
             'native-terminal-reconciliation.json',
             'old-archive-diagnostic-reconciliation.json',
             'unfinished-work-reconciliation.json',
             'local-unmet-cases-plan.json',
             'reconciliation-resource-evidence.json',
             'directory-creation-probe.json',
             'reconciliation-checkpoint.json',
             'native-identity-diagnostic-repair/qualification.json',
             'native-identity-diagnostic-repair/synthetic-checks.json',
             'harness_trace_records.py', 'inventory_setup_errors.py',
             'setup-error-inventory.json', 'original-setup-error-trace.txt',
             'setup-unmet-tests.txt', 'run_setup_followups.py',
             'setup-followups.json', 'setup-followups-resources.jsonl',
             'setup-followups.pre-space-readiness.json',
             'reclaim_completed_objects.py', 'completed-object-reclaim.json',
             'deduplicate_intermediate_jvms.py', 'intermediate-jvm-deduplication.json',
             'fill_readxbytes_isolated.py', 'readxbytes-isolated.json',
             'readxbytes-isolated-resources.jsonl',
             'remaining-jaxp-preflight.json', 'remaining-fastdebug-jaxp.log',
             'remaining-fastdebug-jaxp.log.result.json', 'LOCAL_FOLLOWUP.md',
             'monitor_setup_followups.py', 'setup-followups-active-resources.jsonl',
             'setup-resource-monitor-repair.json']:
    f = r / name
    if f.exists(): files.add(f)
for name in ['classify_cleaners.py', 'tier2-cleaners-classification.json']:
    f = r / name
    if f.exists(): files.add(f)
for name in ['qualification-count-correction.json', 'tier2-autoarchive-fill.json',
             'fill_autoarchive.py', 'test-lib-native-correction.json',
             'test-lib-native-release.log', 'test-lib-native-release.log.result.json',
             'test-lib-native-fastdebug.log', 'test-lib-native-fastdebug.log.result.json',
             'classify_filestore.py', 'tier2-filestore-classification.json',
             'system-nss.json', 'preflight_pinned_nss.py',
             'nss-3.117/source-provenance.json', 'nss-3.117/qualification-provenance.json',
             'nss-source-fetch.log', 'nss-source-fetch.log.result.json',
             'nss-3.117-build.log', 'nss-3.117-build.log.result.json',
             'prepare_nss_source.py', 'prepare_external_data.py',
             'external-data/source-provenance.json', 'fill_nss.py',
             'tier2-release-nss-fill.json', 'fill_security_data.py',
             'tier2-release-security-data-fill.json', 'openssl-layout-correction.json',
             'tier2-fastdebug-nss-fill.json', 'tier2-fastdebug-security-data-fill.json',
             'assess_tier2.py', 'tier2-assessment.json', 'final_performance.py',
             'finish_local_qualification.py', 'local-continuation.json',
             'checkpoint_tier2_periodically.py', 'periodic-tier2-checkpoints.json',
             'after_security_prefetch.py', 'after-security-prefetch.json',
             'after-security-prefetch.log', 'after-security-prefetch.log.result.json',
             'native-activation.json', 'native-launch.json',
             'native-run.json', 'native-jobs.json',
             'native-launch-confirmed-publish.log', 'native-launch-confirmed-publish.log.result.json',
             'activate_approved_native_builds.py', 'launch_approved_native_builds.py',
             'native-activation.log', 'native-activation.log.result.json',
             'native-dispatch.request.json', 'native-dispatch.log', 'native-dispatch.log.result.json',
             'native-launch.log', 'native-launch.log.result.json',
             'performance_status.py',
             'performance_environment.py',
             'disconnect-verification.json',
             'cold_matrix.py', 'warm_matrix.py', 'summarize_warm.py',
             'analyze_final_performance.py',
             'CommonBigIntegerSquares.java', 'build_square_benchmark.py',
             'square-benchmark-provenance.json', 'square-benchmark-build.log',
             'square-benchmark-build.log.result.json',
             'square-benchmark-list.log', 'square-benchmark-list.log.result.json',
             'pack_final_performance.py', 'source0fb-review-notes.md',
             'run383852-status-current.json',
             'reclaim_fastdebug_objects.py', 'fastdebug-object-reclaim.json',
             'fastdebug-object-reclaim.log', 'fastdebug-object-reclaim.log.result.json',
             'tier2-fastdebug-cleaners-cause.json',
             'build_pinned_openssl.py', 'openssl-3.5.4-build.log',
             'openssl-3.5.4-build.log.result.json',
             'external-data/openssl/build-provenance.json',
             'external-data/openssl/qualification-provenance.json',
             'fill_noldap.py', 'tier2-noldap-fill.json',
             'fill_header_controls.py', 'tier2-header-control-fill.json',
             'after_net_prefetch.py', 'after-net-prefetch.json',
             'after-net-prefetch.log', 'after-net-prefetch.log.result.json',
             'queued-noldap.log', 'queued-noldap.log.result.json',
             'queued-matching-header-controls.log', 'queued-matching-header-controls.log.result.json',
             'queued-fastdebug-net-prefetch.log', 'queued-fastdebug-net-prefetch.log.result.json',
             'fill_jimage.py', 'tier2-jimage-fill.json']:
    f = r / name
    if f.exists(): files.add(f)
for name in ['tier2-nss-preflight-release', 'tier2-nss-pinned-preflight-release']:
    for suffix in ['.log', '.log.result.json', '.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
for result in sorted(r.glob('tier2-classify-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    name = result.name.removesuffix('.result.json')
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-work')).rglob('*.stderr'))
    files.update((r / (name + '-report/text')).glob('*'))
files.update((r / 'reaper-orphan-selftest').glob('*'))
analysis = r / 'tier2-failure-analysis.json'
if analysis.exists():
    for failure in json.loads(analysis.read_text())['failures']:
        for rel in [*failure['reproduced'].values(),
                    *failure['passing_same_source_fourbyte_headers_off'].values()]:
            files.add(r / rel)
observed = r / 'tier2-observed-failures.json'
if observed.exists():
    observed_data = json.loads(observed.read_text())
    files.update(r / x['path'] for x in observed_data['failed_jtrs'])
    historical = []
    for failure in observed_data['failed_jtrs']:
        proof = failure.get('baseline_control')
        if not proof:
            continue
        for item in [proof, *([proof['baseline_child_stderr']] if 'baseline_child_stderr' in proof else [])]:
            original = pathlib.Path(item['path'])
            data = original.read_bytes()
            assert hashlib.sha256(data).hexdigest() == item['sha256']
            relative = original.relative_to('/workspace/pr9-validation')
            local = r / 'historical-controls' / relative
            local.parent.mkdir(parents=True, exist_ok=True)
            if local.exists():
                assert local.read_bytes() == data
            else:
                local.write_bytes(data)
            files.add(local)
            historical.append({'original_path': str(original), 'packet_path': str(local.relative_to(r)),
                               'source': proof['source'], 'sha256': item['sha256'],
                               'scope': 'Retained baseline control, never counted as a current-source pass.'})
    index = r / 'historical-control-manifest.json'
    index.write_text(json.dumps(historical, indent=2) + '\n')
    files.add(index)
for name in ['tier2_layout.py', 'core-assessment.json', 'core-evidence.json',
             'clean-release.json', 'clean-fastdebug.json', 'images.json',
             'pr9-metadata.json', 'pr9-metadata-return.json', 'integration-preview.json', 'process-correction.json',
             'native-qualification-proposal.json', 'native-approval-request.json',
             'native-build-review-receipt.json', 'run_flagless_redefine.py',
             'flagless-redefinition-fill.json', 'environment-reconnect-1957.json',
             'BENCHMARKS_PENDING.md', 'PR_DESCRIPTION_PENDING.md', 'LIVE_HANDOFF.md',
             'ARM_CDS_SOURCE_TRACE.md', 'original-arm-transfer-blockers.json',
             'hash-review-decision.json', 'exact-cold-review-decision.json',
             'early-exact-performance.json', 'exact-square-confirmation-analysis.json',
             'complete-int-evidence.json', 'packaging-correction.json',
             'publisher-guard-verification.json', 'publish_evidence.py']:
    f = r / name
    if f.is_file():
        files.add(f)
manifest = []
with zipfile.ZipFile(out / 'tier2.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files | snapshots.keys()):
        if not f.is_file(): continue
        data = snapshots[f] if f in snapshots else f.read_bytes()
        name = str(f.relative_to(r))
        z.writestr(name, data)
        manifest.append({'path': name, 'size': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'tier2.zip') as z:
    assert z.testzip() is None
packet = out / 'tier2.zip'
record = {'source': source, 'status': 'partial-tier2-with-retained-failures',
          'snapshot_started_utc': started_at,
          'snapshot_finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts': cohorts, 'active_snapshots': active, 'files': len(manifest),
          'archive': {'name': packet.name, 'size': packet.stat().st_size,
                      'sha256': hashlib.sha256(packet.read_bytes()).hexdigest()}}
assessment_path = r / 'tier2-assessment.json'
assessment = json.loads(assessment_path.read_text()) if assessment_path.exists() else {}
if assessment.get('local_timing_eligible') and not active:
    record['status'] = 'completed-tier2-with-explicit-local-limitations'
record['tier2_clean'] = False
record['assessment_status'] = assessment.get('status', 'not-yet-assessed')
(out / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
observed_record = json.loads(observed.read_text()) if observed.exists() else {}
(out / 'README.md').write_text(
    f'Source {source} clean-image tier2 checkpoint.\n\n' +
    ('Local tier2 selections are complete with explicit limitations. ' if
     record['status'] == 'completed-tier2-with-explicit-local-limitations' else
     'Tier2 remains incomplete. ') +
    f'The {len(cohorts)} completed groups report '
    f'{sum(x["counts"]["Passed"] for x in cohorts)} executed passing records, '
    f'{sum(x["counts"]["Skipped"] for x in cohorts)} explicit skipped records, and '
    f'{sum(x["counts"]["Failed"] for x in cohorts)} failures. Original statuses, '
    'commands, image fingerprints and failed JTRs remain intact. Finished JTRs and '
    'logs from active groups are snapshots only and do not certify those groups complete.\n\n'
    'The observed failure inventory is ' + json.dumps(observed_record.get('counts', {})) +
    '. Named failures are checked against their exact messages and control-image '
    'evidence. Cleaners native GSS controls additionally retain child stderr; the '
    'original parent-only JTR limitation is explicit in its analysis. This does '
    'not certify tier2 clean or classify later failures automatically.\n\n'
    'New batches use Make\'s automatic/ignore-quiet/failure-retention options. '
    'Preexisting commands/results remain intact; locks and exact-command/source '
    'checks prevent duplicate groups. Current executions use the owned subreaper; '
    'PID1 was untouched. Historical baseline controls are retained separately with '
    'their original source identity and hashes, and never counted as current passes.\n\n'
    'Final performance, original native ARM ZGC reproduction, and current-source '
    'native ARM/Windows builds/tests remain pending. No approval, source-readiness '
    'or speedup conclusion is made.\n')
print(json.dumps(record, indent=2))
