import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--pairs', type=int, default=4)
p.add_argument('--output')
p.add_argument('--tier', choices=['all', 'int', 'c1-l1', 'c1-l3', 'c2'], default='all')
p.add_argument('--controls', action='store_true')
a = p.parse_args()
root = Path('/workspace/pr9-layout-validation')
out = root / (a.output or ('warm-controls' if a.controls else 'warm-matrix'))
out.mkdir(exist_ok=True)
images = json.loads((root / 'images.json').read_text())
variants = {'master': ('master', []), 'before-on': ('before', ['-XX:+UseCommonIntrinsics']),
            'final-off': ('final', ['-XX:-UseCommonIntrinsics']),
            'final-on': ('final', ['-XX:+UseCommonIntrinsics'])}
cpus = sorted(os.sched_getaffinity(0))
worker = cpus[0]
os.sched_setaffinity(0, {cpus[1]})
cp = ':'.join(str(root / 'jmh' / n) for n in
              ['benchmarks.jar', 'square-benchmarks.jar', 'jmh-core.jar', 'jopt-simple.jar', 'commons-math3.jar'])
classpath_hashes = {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in cp.split(':')}
flags = ['-XX:ActiveProcessorCount=1', '-XX:CICompilerCount=2', '-XX:+UseSerialGC',
         '-Xms128m', '-Xmx256m', '-XX:-UsePerfData', '-XX:+DisableAttachMechanism', '-Xrs']
tiers = [('int', ['-Xint']), ('c1-l1', ['-Xbatch', '-XX:TieredStopAtLevel=1']),
         ('c1-l3', ['-Xbatch', '-XX:TieredStopAtLevel=3']), ('c2', ['-Xbatch', '-XX:-TieredCompilation'])]
cases = [('hash', 'CommonSmallIntrinsics.hashBytes', ['-p', 'length=1,32,65537']),
         ('scalar', 'CommonSmallIntrinsics.bitCount', ['-p', 'length=1']),
         ('multiply', 'CommonBigIntegerCalls.multiply', ['-p', 'bits=512,4096']),
         ('square', 'CommonBigIntegerSquares.selfSquare', ['-p', 'bits=512,2048,4096']),
         ('modpow', 'CommonBigIntegerCalls.modPow', ['-p', 'bits=512,4096']),
         ('aes', 'CommonIntrinsics.aesCtr', ['-p', 'length=4096']),
         ('sha256', 'CommonIntrinsics.sha256', ['-p', 'length=4096']),
         ('sha3', 'CommonIntrinsics.sha3', ['-p', 'length=4096']),
         ('chacha', 'CommonIntrinsics.chacha20', ['-p', 'length=4096'])]
if a.controls:
    cases = [('multiply', 'CommonBigIntegerCalls.multiply', ['-p', 'bits=4096']),
             ('sha256', 'CommonIntrinsics.sha256', ['-p', 'length=4096'])]
manifest_path = out / 'manifest.json'
records = []
if manifest_path.exists():
    previous = json.loads(manifest_path.read_text())
    assert previous['images'] == images and previous['flags'] == flags
    assert previous['pairs'] == a.pairs and previous['worker'] == worker
    assert previous['classpath'] == cp
    assert previous['classpath_sha256'] == classpath_hashes
    records = previous['records']
completed = {record['name']: record for record in records}
def progress(message):
    try:
        print(message, flush=True)
    except BrokenPipeError:
        fd = os.open(os.devnull, os.O_WRONLY)
        os.dup2(fd, sys.stdout.fileno())
        os.close(fd)
def save():
    manifest_path.write_text(json.dumps({'images': images, 'worker': worker,
        'flags': flags, 'classpath': cp, 'classpath_sha256': classpath_hashes,
        'pairs': a.pairs, 'records': records}, indent=2) + '\n')
for tier, mode in tiers:
    if a.tier != 'all' and a.tier != tier:
        continue
    for pair in range(a.pairs):
        labels = list(variants)
        # Four successive rotations place every variant at every rank once.
        labels = labels[pair % len(labels):] + labels[:pair % len(labels)]
        for case, pattern, parameters in cases:
            for label in labels:
                image, extra = variants[label]
                java = images[image]['path'] + '/bin/java'
                name = f'{tier}-{case}-{label}-{pair}'
                result_path = out / (name + '.json')
                vmflags = flags + mode + extra
                command = ['taskset', '-c', str(worker), java, *flags, '-XX:TieredStopAtLevel=1',
                    '-cp', cp, 'org.openjdk.jmh.Main', pattern, *parameters,
                    '-f', '1', '-wi', '3', '-i', '5', '-w', '1s', '-r', '1s', '-t', '1',
                    '-foe', 'true', '-rf', 'json', '-rff', str(result_path),
                    '-jvm', java, '-jvmArgs', ' '.join(vmflags)]
                if name in completed:
                    previous = completed[name]
                    assert previous['command'] == command and previous['exit_code'] == 0
                    assert hashlib.sha256(result_path.read_bytes()).hexdigest() == previous['result_sha256']
                    progress('Reuse verified completed fork: ' + name)
                    continue
                assert not result_path.exists(), 'Unrecorded output requires investigation: ' + str(result_path)
                with (out / (name + '.log')).open('w') as log:
                    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
                record = {'name': name, 'tier': tier, 'case': case, 'label': label, 'pair': pair,
                          'command': command, 'exit_code': code}
                if code == 0:
                    record['results'] = json.loads(result_path.read_text())
                    record['result_sha256'] = hashlib.sha256(result_path.read_bytes()).hexdigest()
                records.append(record)
                save()
                progress(name + ' exit ' + str(code))
                if code:
                    raise SystemExit(code)
