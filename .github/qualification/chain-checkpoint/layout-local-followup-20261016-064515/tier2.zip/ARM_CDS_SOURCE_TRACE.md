# Common entries and archived resolution state

Source inspected: `e41d7823bf6de77c4bfba52e896bf325221488cb`.
This is a source trace and a bounded mechanism explanation. It is not a new
analysis of the unavailable original ARM archive/map bytes.

The parent handoff reports method-pointer/null differences for
`ArraysSupport.unsignedHashCode(int, byte[], int, int)` and resolved/unresolved
`[B` entries in blocks 01/02/03. Block 14 reports the corresponding
`Long` cache entry for `Integer.numberOfLeadingZeros` and the `Integer` class.
The supplied original tested JVM identity is `d8fc74ba01f7e6ed0a77e94f89b1a0922a79a776`,
separate from test source `8bf01e9e`. Those byte/map findings are inherited
evidence, not independently reverified in this executor: Library materialization
and the permitted bounded retries did not produce readable local packets.

## Source path

1. Both architecture generators poll before a common entry. A pending safepoint
   selects `slow_path`, which jumps to the ordinary `zerolocals` Java entry.
   A successful leaf/scalar path returns directly instead.
   See `src/hotspot/cpu/aarch64/templateInterpreterGenerator_aarch64.cpp:986`
   and `src/hotspot/cpu/x86/templateInterpreterGenerator_x86_64.cpp:507`.
2. `ArraysSupport.vectorizedHashCode` has Java casts to `byte[]` and calls
   `unsignedHashCode` in its boolean/unsigned-byte case. Its intrinsic entry can
   compute the result without those Java bytecodes. See
   `src/java.base/share/classes/jdk/internal/util/ArraysSupport.java:363`.
   Similarly, Java `Long.numberOfLeadingZeros` calls
   `Integer.numberOfLeadingZeros`, while the scalar common entry emits a direct
   instruction. See `src/java.base/share/classes/java/lang/Long.java:1548`.
3. Ordinary Java invocation resolution publishes resolved methods in the
   constant-pool cache via `InterpreterRuntime::update_invoke_cp_cache_entry`.
   Java class checks can resolve the referenced class entries as well.
4. Archive cleanup retains an already-resolved method entry when its resolution
   is eligible for archiving; it does not necessarily normalize every such
   entry to an unresolved state. See
   `src/hotspot/share/oops/cpCache.cpp:468` and `:557`.
   Class cleanup likewise retains eligible resolved classes. The preimage path
   explicitly clears them. See `src/hotspot/share/oops/constantPool.cpp:537`.
   Here, `AOTConstantPoolResolver::is_resolution_deterministic` checks whether a
   resolved reference has the same meaning at dump time and runtime. It does
   not mean that every execution must have resolved the reference already.
   See `src/hotspot/share/cds/aotConstantPoolResolver.cpp:44`.

This provides a concrete mechanism by which choosing a common result versus
its Java body during archive assembly can leave different archived resolution
states. Safepoint-dependent fallback is consistent with the reported entries.
The exact original ARM trigger remains unproved without native reproduction and
the actual offset/map evidence; a later passing retry would not resolve it.

## Narrow change and actual evidence

Commit `7454b15f85f20d7ed6688256b52c126603e3ff06` selects ordinary Java entries
while assembling static archives. Common entries remain enabled for ordinary
execution, dynamic CDS, and AOT training/preimages, whose resolution entries are
cleared. The change does not alter Java semantics or globally disable the
feature. The later layout fix places optional entries after ordinary handlers.

New `CommonIntrinsicArchiveDeterminism` compares off/on/forced-safepoint archives
under Serial, G1 and ZGC, each with both compressed-oop settings. Current e41d
clean Linux x64 release and fastdebug images passed it and the existing
`FourByteHeaderArchiveDeterminism` selections. Current AOT selections and eight
release dynamic-CDS record/replay checks also passed. All 239 ordinary handler
offsets match with common entries off/on.

These x64 results do not qualify native ARM behavior. Required ARM work remains
the fixed baseline/off/on repetitions, raw failed archive/map retention and
actual-offset ownership analysis, plus current-source release/fastdebug tests
and public-API performance. The unrelated tier2 cross-GC object-header flag
mismatches retain their original failed status and exact baseline controls.
