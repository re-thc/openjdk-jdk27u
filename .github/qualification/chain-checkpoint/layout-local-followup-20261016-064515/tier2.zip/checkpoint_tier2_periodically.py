"""Preserve bounded hourly progress on the authorized evidence branch."""
import datetime
import json
import pathlib
import subprocess
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
state_path = r / 'periodic-tier2-checkpoints.json'
assert not state_path.exists(), 'Do not duplicate the checkpoint worker'
state = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
         'status': 'waiting', 'interval_seconds': 2700, 'checkpoints': []}
def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')
def remaining():
    try:
        groups = [json.loads((r / ('tier2-' + k + '.json')).read_text())
                  for k in ['release', 'fastdebug']]
    except json.JSONDecodeError:
        return True
    return not all(d['status'] in ['passed', 'has-failures'] and len(d['cohorts']) == 11
                   for d in groups)
save()
try:
    next_checkpoint = time.monotonic() + state['interval_seconds']
    while remaining():
        if time.monotonic() < next_checkpoint:
            time.sleep(15)
            continue
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
        label = 'layout-tier2-progress-' + stamp
        folder = pathlib.Path('/workspace/pr9-recovery') / label
        row = {'label': label, 'commands': []}
        state['status'] = 'checkpointing'
        save()
        for name, args in [
            ('observe', ['python3', str(r / 'observe_tier2_failures.py')]),
            ('pack', ['python3', str(r / 'pack_tier2_evidence.py'), label]),
            ('publish', ['python3', str(r / 'publish_evidence.py'), str(folder),
                         '.github/qualification/chain-checkpoint/' + label,
                         'Checkpoint source-aligned tier2 progress with retained outcomes']),
        ]:
            log = r / (label + '-' + name + '.log')
            command = ['python3', str(r / 'run_reaped.py'), str(log), *args]
            code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
            row['commands'].append({'name': name, 'command': command, 'exit_code': code})
            if code:
                state['checkpoints'].append(row)
                raise RuntimeError(name + ' failed; inspect retained log and do not publish incomplete packet')
        row['commit'] = log.read_text().strip().splitlines()[-1]
        row['qualification'] = json.loads((folder / 'qualification.json').read_text())
        state['checkpoints'].append(row)
        state['status'] = 'waiting'
        save()
        next_checkpoint = time.monotonic() + state['interval_seconds']
    state['status'] = 'stopped-main-groups-complete'
    save()
except BaseException as error:
    state['status'] = 'blocked-for-review'
    state['error'] = repr(error)
    save()
    raise
