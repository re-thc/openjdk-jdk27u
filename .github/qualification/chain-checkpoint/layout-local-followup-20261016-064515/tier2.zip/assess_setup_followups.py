"""Verify exact one-to-one follow-up coverage, retaining every original outcome."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

r = Path('/workspace/pr9-layout-validation')
repo = Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
inventory = json.loads((r / 'setup-error-inventory.json').read_text())
state = json.loads((r / 'setup-followups.json').read_text())
assert state['status'] == 'completed-unmet-setup-cases' and state['completed_cases'] == 558
assert state['source'] == inventory['source'] == source
expected = {row['test']: row for row in inventory['tests']}
assert len(expected) == 558
actual = {}
for batch in state['batches']:
    result_path = r / (batch['name'] + '.result.json')
    result_data = result_path.read_bytes()
    assert hashlib.sha256(result_data).hexdigest() == batch['result_sha256']
    result = json.loads(result_data)
    assert result['source_checkout_at_start'] == source and result['exit_code'] == batch['exit_code']
    batch_tests = set()
    for file in (r / (batch['name'] + '-work')).rglob('*.jtr'):
        data = file.read_bytes(); text = data.decode(errors='replace')
        fields = dict(re.findall(r'^(test|execStatus)=(.*)$', text, re.M))
        if 'execStatus' not in fields: continue
        test = fields['test'].replace('\\#', '#')
        assert test in expected and test not in actual, (test, str(file))
        source_file = repo / 'test/jdk' / test.split('#', 1)[0]
        assert hashlib.sha256(source_file.read_bytes()).hexdigest() == expected[test]['source_sha256']
        status = fields['execStatus'].replace('\\:', ':')
        outcome = 'Skipped' if status.startswith('Passed. Skipped') else status.split('.')[0]
        assert outcome in ['Passed', 'Skipped', 'Failed'], (test, status)
        actual[test] = {'test': test, 'original_outcome': 'Error',
                        'original_jtr': expected[test]['jtr'], 'original_trace_line': expected[test]['trace_line'],
                        'followup_outcome': outcome, 'followup_status': status,
                        'followup_jtr': str(file.relative_to(r)),
                        'followup_jtr_sha256': hashlib.sha256(data).hexdigest(), 'batch': batch['name']}
        batch_tests.add(test)
    assert batch_tests == set(batch['tests']), (batch['name'], batch_tests ^ set(batch['tests']))
assert set(actual) == set(expected)
counts = dict(collections.Counter(row['followup_outcome'] for row in actual.values()))
assert counts == {'Passed': 556, 'Skipped': 1, 'Failed': 1}, counts
review = json.loads((r / 'setup-followup-failure-review.json').read_text())
failed = [row for row in actual.values() if row['followup_outcome'] == 'Failed']
assert len(failed) == 1 and failed[0]['followup_jtr_sha256'] == review['failures'][0]['sha256']
console = json.loads((r / 'setup-followup-console-gap.json').read_text())
skipped = [row for row in actual.values() if row['followup_outcome'] == 'Skipped']
assert len(skipped) == 1 and skipped[0]['followup_jtr_sha256'] == console['jtr_sha256']
record = {'source': source, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'completed-exact-unmet-cases-with-explicit-environment-gaps',
          'original_error_outcomes': 558, 'original_saved_jtrs': 37, 'original_trace_only_outcomes': 521,
          'unique_followup_cases': len(actual), 'counts': counts, 'missing_cases': [], 'duplicate_cases': [],
          'source_files_unchanged': True, 'source_checkout_clean': True,
          'dns_failure_review': 'setup-followup-failure-review.json',
          'console_skip_review': 'setup-followup-console-gap.json',
          'rows': list(actual.values()),
          'scope': 'Original558 errors stay errors. Fresh same-source follow-ups include556 actual passes,1 failed DNS case matching the retained baseline cause, and1 skipped hardcoded-expect case. This does not certify clean tier2, native ARM or performance.'}
(r / 'setup-followup-final-assessment.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'unique_followup_cases', 'counts', 'missing_cases', 'duplicate_cases']}))
