"""Reuse the fourth batch slot after release networking finishes."""
import datetime
import json
import pathlib
import subprocess
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
state_path = r / 'after-net-prefetch.json'
assert not state_path.exists(), 'Do not duplicate this queue'
state = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
         'status': 'waiting-for-release-net-prefetch', 'steps': []}
def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')
save()
while not (r / 'clean-release-tier2-jdk-net.result.json').exists():
    time.sleep(10)
for label, arguments in [
    ('noldap', ['python3', str(r / 'fill_noldap.py')]),
    ('matching-header-controls', ['python3', str(r / 'fill_header_controls.py')]),
    ('fastdebug-net-prefetch', ['python3', str(r / 'tier2_layout.py'),
                               'fastdebug', '--only', 'jdk-net']),
]:
    state['status'] = label
    save()
    command = ['python3', str(r / 'run_reaped.py'),
               str(r / ('queued-' + label + '.log')), *arguments]
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    state['steps'].append({'name': label, 'command': command, 'exit_code': code})
    save()
    if code:
        state['status'] = 'blocked-for-review'
        save()
        raise SystemExit(code)
state['status'] = 'completed'
save()
