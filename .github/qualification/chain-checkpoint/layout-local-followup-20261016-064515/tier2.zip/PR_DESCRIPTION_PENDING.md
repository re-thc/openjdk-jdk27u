DRAFT — apply only after final local qualification and parent approval for source publication.

Share guarded numeric, hashing and crypto kernels and integer operations with the interpreter and C1 on x64 and AArch64, preserving intrinsic flags, Java fallbacks and existing C2 routes.

Prepare compiler stubs at safe VM call sites on actual use, prepare Montgomery work before its initial kernels, and retain small-product deferral. Refresh rooted call targets after blocking preparation. Use ordinary Java entries during static CDS dumping and place optional interpreter entries after ordinary bytecodes, with deoptimization entries last.

Current Linux x64 implementation `e41d7823` has clean release/fastdebug builds, 173 focused jtreg records including two flagless class-unloading checks, 1399 fastdebug native gtest passes (15 disabled), 864 flag/collector checks, 80 concurrent cold-GC probes and eight release dynamic-CDS checks. The structural layout test passes on both VMs and the diagnostic records zero flag-dependent offset changes across 239 bytecode handlers.

Public API measurements cover the complete 15-workload interpreter warm tier and 24 exact-size cold cases across interpreter, C1 levels 1/3 and C2. A fixed ten-round direct comparison corrected the large-array fallback regression: prior candidate 712 microseconds versus current 521, with a paired 95% reduction of 179–203 microseconds. All original observations, including a variable control fork and a weak cold feature-off control signal, remain in the evidence.

PENDING: final tier2 accounting, remaining cold/startup/warm/C2-control measurements and signal review. Current-source native ARM CDS/ZGC/performance and Windows/AVX-512 execution remain unqualified. See the final source-labelled benchmark report and immutable evidence links when complete.

- [ ] I confirm that I make this contribution in accordance with the [OpenJDK Interim AI Policy](https://openjdk.org/legal/ai).
