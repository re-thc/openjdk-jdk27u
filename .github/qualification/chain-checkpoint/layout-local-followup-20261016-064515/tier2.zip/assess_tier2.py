"""Account for final local tier2 coverage without rewriting original outcomes."""
import collections
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
from harness_trace_records import trace_records

r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
subprocess.run(['python3', str(r / 'observe_tier2_failures.py')], check=True, stdout=subprocess.DEVNULL)
observed = json.loads((r / 'tier2-observed-failures.json').read_text())
failed = {x['path']: x for x in observed['failed_jtrs']}
labels = ['hotspot-runtime', 'hotspot-resolution', 'hotspot-serviceability',
          'hotspot-compiler', 'hotspot-ctw', 'hotspot-shenandoah',
          'jdk-security', 'jdk-io-tools-time', 'jdk-net', 'langtools', 'jaxp']
required = [f'clean-{kind}-tier2-{label}' for kind in ['release', 'fastdebug'] for label in labels]
# Prepared dependencies and native fixtures are supplied to the new main runs.
# Only newly observed unmet selections need a fill; exact skips remain gated below.
required_fills = []
rows, cohorts, batch_errors = [], [], []
pending = []
provider_rules = {
    'sun/security/pkcs11/Cipher/TestSymmCiphers.java': 'transformation=Blowfish/',
    'sun/security/pkcs11/Cipher/TestSymmCiphersNoPad.java': 'transformation=Blowfish/',
    'sun/security/pkcs11/SecretKeyFactory/TestGeneral.java': 'no such algorithm: Blowfish',
    'sun/security/pkcs11/SecureRandom/Basic.java': 'does not support SecureRandom',
    'sun/security/pkcs11/SecureRandom/TestDeserialization.java': 'Skip test for provider SunPKCS11-NSS',
    'sun/security/pkcs11/Signature/SigInteropPSS2.java': 'No support for SHA3-224withRSASSA-PSS',
    'sun/security/pkcs11/Signature/SignatureTestPSS2.java#sha3': 'No support for SHA3-224withRSASSA-PSS',
    'sun/security/pkcs11/Signature/SignatureTestPSS.java#sha3': 'Algo Support: MAYBE',
    'sun/security/pkcs11/Signature/TestDSAKeyLength.java': 'Skip testing NSS Version[major=3, minor=117, patch=0]',
    'sun/security/pkcs11/ec/TestECDH.java': 'NSS only supports Basic ECC, skipping',
}
for name in required + required_fills:
    if not (r / (name + '.result.json')).exists():
        pending.append(name)
results = list(r.glob('clean-*-tier2-*.result.json'))
results += list(r.glob('tier2-nss-pinned-preflight-release.result.json'))
for result in sorted(results):
    if result.name.endswith('.log.result.json'):
        continue
    d = json.loads(result.read_text())
    assert d['source_checkout_at_start'] == source
    name = d['name']
    kind = 'release' if name == 'tier2-nss-pinned-preflight-release' else name.split('-')[1]
    scope = 'main' if name in required else 'fill'
    work = r / (name + '-work')
    counts = collections.Counter()
    recorded_tests = set()
    for jtr in sorted(work.rglob('*.jtr')):
        data = jtr.read_bytes()
        text = data.decode(errors='replace')
        fields = dict(re.findall(r'^(description|execStatus|keywords|test)=(.*)$', text, re.M))
        if 'execStatus' not in fields:
            continue
        status = fields['execStatus'].replace('\\:', ':')
        recorded_tests.add(fields.get('test', '').replace('\\#', '#'))
        identity = fields['description'].replace('\\:', ':').replace('\\#', '#').removeprefix('file:/workspace/openjdk-jdk27u/')
        assert identity.startswith('test/'), (name, identity)
        outcome = 'Skipped' if status.startswith('Passed. Skipped') else status.split('.')[0]
        counts[outcome] += 1
        path = str(jtr.relative_to(r))
        rows.append({'cohort': name, 'kind': kind, 'scope': scope, 'test': identity,
                     'outcome': outcome, 'status': status, 'path': path,
                     'sha256': hashlib.sha256(data).hexdigest(),
                     'manual': 'manual' in fields.get('keywords', '').split(),
                     'provider_conditional_reason_matched': (name.endswith(('-nss-ready', '-jdk-security')) and
                         identity.removeprefix('test/jdk/') in provider_rules and
                         provider_rules[identity.removeprefix('test/jdk/')] in text),
                     'failure_classification': failed.get(path, {}).get('classification')})
    for item in trace_records(work, r/'harness-trace-snapshots'):
        if item['test'] in recorded_tests:
            continue
        assert item['outcome'] == 'Error', ('Missing non-error JTR', name, item)
        assert name == 'clean-fastdebug-tier2-jdk-io-tools-time', (name, item)
        assert 'Cannot create directories for ' in item['status'] or "Can't create " in item['status']
        counts['Error'] += 1
        rows.append({'cohort': name, 'kind': kind, 'scope': scope,
                     'test': 'test/jdk/' + item['test'], 'outcome': 'Error',
                     'status': item['status'], 'path': None, 'sha256': None,
                     'jtr_available': False, 'trace_path': item['trace_path'],
                     'trace_snapshot_path': item['trace_snapshot_path'],
                     'trace_sha256': item['trace_sha256'], 'trace_line': item['trace_line'],
                     'manual': False, 'provider_conditional_reason_matched': False,
                     'failure_classification': 'harness-scratch-directory-setup-error'})
    summary_counts = collections.Counter()
    for line in d['summary'].splitlines():
        m = re.search(r'\s(Passed|Failed|Error|Not run)\.(.*)$', line)
        if m:
            summary_counts['Skipped' if m[1] == 'Passed' and m[2].startswith(' Skipped') else m[1]] += 1
    assert counts == summary_counts, (name, counts, summary_counts)
    if d['exit_code'] != 0 and not counts['Failed'] and not counts['Error']:
        batch_errors.append({'cohort': name, 'exit_code': d['exit_code'],
                             'reason': 'Nonzero batch exit without a failed/error test record'})
    if counts['Not run']:
        batch_errors.append({'cohort': name, 'reason': 'Unexecuted selected test records',
                             'count': counts['Not run']})
    cohorts.append({'name': name, 'scope': scope, 'exit_code': d['exit_code'],
                    'counts': dict(counts), 'result_sha256': hashlib.sha256(result.read_bytes()).hexdigest()})

passing = collections.defaultdict(list)
provider_gaps = collections.defaultdict(list)
for x in rows:
    if x['outcome'] == 'Passed':
        passing[x['kind'], x['test']].append(x['path'])
    elif x['outcome'] == 'Skipped' and x['provider_conditional_reason_matched']:
        provider_gaps[x['kind'], x['test']].append(x['path'])
skips = []
for x in rows:
    if x['outcome'] != 'Skipped':
        continue
    x = dict(x)
    replacements = passing.get((x['kind'], x['test']), [])
    if x['manual']:
        category = 'manual-outside-official-automatic-selection'
    elif replacements:
        category = 'fulfilled-by-executed-case'
        x['fulfilled_by'] = replacements
    elif x['scope'] == 'main' and provider_gaps.get((x['kind'], x['test'])):
        category = 'dependency-filled-provider-conditional-coverage-gap'
        x['provider_gap_record'] = provider_gaps[x['kind'], x['test']]
    elif x['provider_conditional_reason_matched']:
        category = 'pinned-nss-provider-conditional-coverage-gap'
    elif x['test'] == 'test/jdk/java/io/Console/ConsolePromptTest.java' and "'expect' command not found" in x['status']:
        category = 'environment-hardcoded-expect-path-unavailable'
    elif x['test'] == 'test/jdk/java/nio/file/attribute/BasicFileAttributeView/SetTimesNanos.java' and 'overlay not in' in x['status']:
        category = 'environment-unsupported-filesystem'
    elif x['test'] == 'test/jdk/java/net/InetAddress/ptr/Lookup.java' and "icann.org can't be resolved" in x['status']:
        category = 'environment-external-dns-coverage-gap'
    else:
        category = 'unreviewed-skip'
    x['classification'] = category
    skips.append(x)

main_state = {}
for kind in ['release', 'fastdebug']:
    state = json.loads((r / f'tier2-{kind}.json').read_text())
    assert state['source'] == source
    main_state[kind] = {'status': state['status'], 'groups': len(state['cohorts'])}
    if state['status'] not in ['passed', 'has-failures'] or len(state['cohorts']) != len(labels):
        pending.append('main-orchestrator-' + kind)
unknown = [x for x in rows if x['outcome'] in ['Failed', 'Error'] and x['failure_classification'] in [None, 'unclassified']]
unreviewed = [x for x in skips if x['classification'] == 'unreviewed-skip']
reviewed_skips = {(x['kind'], x['test']): x for x in skips if x['classification'] != 'unreviewed-skip'}
reviewed_setup_failures = {(x['kind'], x['test']): x for x in rows
                          if x['cohort'].startswith('clean-fastdebug-tier2-setup-fill-') and
                          x['failure_classification'] == 'environment-external-dns-unavailable'}
setup_resolutions = []
unmet_setup_cases = []
for row in rows:
    if row['failure_classification'] != 'harness-scratch-directory-setup-error':
        continue
    key = row['kind'], row['test']
    resolution = {'kind': row['kind'], 'test': row['test'], 'original_cohort': row['cohort'],
                  'original_path': row['path'], 'original_outcome': row['outcome']}
    if passing.get(key):
        resolution.update(status='fulfilled-by-actual-followup-pass', fulfilled_by=passing[key])
    elif key in reviewed_skips:
        replacement = reviewed_skips[key]
        resolution.update(status='followup-retains-explicit-coverage-gap',
                          gap_classification=replacement['classification'], fulfilled_by=[replacement['path']])
    elif key in reviewed_setup_failures:
        replacement = reviewed_setup_failures[key]
        resolution.update(status='followup-retains-explicit-environment-failure',
                          gap_classification=replacement['failure_classification'],
                          fulfilled_by=[replacement['path']], followup_outcome='Failed')
    else:
        resolution['status'] = 'unmet'
        unmet_setup_cases.append(resolution)
    setup_resolutions.append(resolution)
hold_path = r / 'qualification-hold.json'
qualification_hold = json.loads(hold_path.read_text()) if hold_path.exists() else None
coverage_complete = not pending and not unknown and not unreviewed and not batch_errors and not unmet_setup_cases
eligible = coverage_complete and not qualification_hold
status = ('completed-with-explicit-local-limitations' if eligible else
          'local-selections-complete-with-retained-failures-performance-held' if coverage_complete else
          'incomplete-or-review-required')
record = {'source': source, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'qualification_hold': qualification_hold,
          'status': status, 'local_selection_coverage_complete': coverage_complete,
          'local_timing_eligible': eligible, 'tier2_clean': False,
          'main_orchestrators': main_state, 'pending': pending,
          'cohorts': cohorts, 'executed_passing_records': sum(x['outcome'] == 'Passed' for x in rows),
          'executed_distinct_kind_test_pairs': len(passing),
          'failure_classifications': observed['counts'],
          'setup_error_resolutions': setup_resolutions, 'unmet_setup_cases': unmet_setup_cases,
          'unknown_failures': unknown, 'skip_classifications': dict(collections.Counter(x['classification'] for x in skips)),
          'unresolved_batch_errors': batch_errors,
          'unreviewed_skips': unreviewed, 'skipped_records': skips,
          'remaining_native_gaps': ['Current-source AArch64 builds, CDS/ZGC reproduction and performance',
                                    'Current-source Windows builds/tests and native AVX-512 execution'],
          'scope': 'Timing eligibility only. Original failures/skips remain failures/gaps; this does not certify tier2 clean or PR readiness.'}
(r / 'tier2-assessment.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['status', 'local_timing_eligible', 'pending', 'executed_passing_records',
                                       'failure_classifications', 'skip_classifications']}, indent=2))
