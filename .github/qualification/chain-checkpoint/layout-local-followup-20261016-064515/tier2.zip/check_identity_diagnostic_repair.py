"""Exercise diagnostic capture with tiny shell fixtures; never execute a JVM."""
import json
import os
import pathlib
import subprocess
import tempfile

import yaml

r = pathlib.Path('/workspace/pr9-layout-validation')
folder = r / 'native-identity-diagnostic-repair'
workflow = yaml.load((folder / '.github/workflows/pr9-native-linux.yml').read_text(),
                     Loader=yaml.BaseLoader)
step = next(s for s in workflow['jobs']['build-linux']['steps']
            if s.get('name') == 'Verify actual JVM source and retain core payload identity')
script = step['run'].replace('${{ inputs.platform }}', 'fixture-platform')
expected = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
cases = [
    ('single-clean', expected, f'SOURCE=".:git:{expected[:12]}"\n', 0),
    ('forest-diagnostic', expected,
     f'SOURCE=".:git:{expected[:12]}+ gtest:git:0123456789ab"\n', 1),
    ('wrong-checkout', '0' * 40, f'SOURCE=".:git:{expected[:12]}"\n', 1),
]
rows = []
for name, head, release, code in cases:
    with tempfile.TemporaryDirectory(prefix='identity-fixture-', dir=folder) as temporary:
        root = pathlib.Path(temporary)
        image = root / 'build/fixture-platform/images/jdk'
        (image / 'bin').mkdir(parents=True)
        (image / 'lib').mkdir()
        (image / 'release').write_text(release)
        (image / 'lib/modules').write_bytes(b'fixture only; not a JDK image\n')
        java = image / 'bin/java'
        java.write_text('#!/bin/sh\nprintf "fixture executable; no JVM launched\\n"\n')
        java.chmod(0o700)
        tools = root / 'tools'
        tools.mkdir()
        git = tools / 'git'
        git.write_text('#!/bin/sh\ncase "$1" in\nrev-parse) printf "%s\\n" "' + head +
                       '";;\nstatus) printf "?? gtest/\\n";;\n*) exit 88;;\nesac\n')
        git.chmod(0o700)
        runner = root / 'runner'
        runner.mkdir()
        env = dict(os.environ, PATH=str(tools) + ':/usr/bin:/bin', RUNNER_TEMP=str(runner),
                   GITHUB_SHA='fixture-workflow', GITHUB_WORKFLOW_REF='fixture-only',
                   GITHUB_RUN_ID='fixture-only')
        result = subprocess.run(['bash', '-c', script], cwd=root, env=env,
                                capture_output=True, text=True)
        identity = runner / 'pr9-identity'
        assert result.returncode == code, (name, result.returncode, result.stderr)
        assert (identity / 'release').read_text() == release
        assert (identity / 'checkout-source.txt').read_text().strip() == head
        assert (identity / 'source-line.txt').read_text() == release
        assert (identity / 'source-validation-status.txt').read_text().strip() == 'exit_code=' + str(code)
        assert release.strip() in result.stdout
        if code:
            assert not (identity / 'java-version.txt').exists(), 'No version executable on failed assertion'
        (folder / (name + '.stdout')).write_text(result.stdout)
        (folder / (name + '.stderr')).write_text(result.stderr)
        rows.append({'fixture': name, 'exit_code': result.returncode,
                     'release_and_checkout_saved_before_assertion': True,
                     'failure_status_preserved': True})
record = {'status': 'three-synthetic-diagnostic-capture-checks-passed', 'cases': rows,
          'scope': 'Shell stubs and text fixtures only. No JVM, build, archive test, workflow dispatch '
                   'or rerun occurred. The forest line is a format counterexample, not observed native metadata.'}
(folder / 'synthetic-checks.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
