# Common intrinsic measurements

DRAFT: remaining source-aligned tier2 and performance qualification is in progress.
Apply this report to the repository only after the final checks and signal review.

Implementation: `e41d7823bf6de77c4bfba52e896bf325221488cb`. Reference baseline:
`87edd79d3104ff502f7befec034716b081436f49`. Published PR-head control:
`c04d1ba1e96b2176ce8a8e56eacae73c2d356d2b`.

Measurements use clean Linux x64 images, AMD EPYC 9V74, GCC 16.2 and JMH 1.37.
Commands, image and classpath hashes, raw observations, and uncertainty intervals
are retained in the linked immutable evidence. Native AArch64 and Windows
execution remain qualification gaps for this implementation.

## First public API calls

Full-size 512- and 4096-bit operands, including dense odd moduli, were measured in
fresh JVMs. Each of 24 cases used 120 measured balanced five-variant blocks plus
20 discarded blocks. Each measured case contains all 120 variant permutations.
Call time and whole-process wall time are recorded separately.

Change in call time against the published enabled VM, milliseconds, with paired
Student-t 95% intervals. Negative values are faster in this measured case.

| Public API workload | Interpreter | C1 level 1 | C1 level 3 | C2 |
| --- | ---: | ---: | ---: | ---: |
| 512-bit self-square | -0.360 [-0.376, -0.344] | -0.510 [-0.551, -0.469] | -0.556 [-0.609, -0.502] | -0.002 [-0.039, +0.034] |
| 512-bit distinct product | -0.410 [-0.444, -0.375] | -0.577 [-0.646, -0.508] | -0.556 [-0.603, -0.510] | -0.012 [-0.040, +0.016] |
| 4096-bit modPow | -0.080 [-0.129, -0.032] | -0.022 [-0.112, +0.069] | -0.008 [-0.128, +0.113] | -0.025 [-0.095, +0.046] |

One initial C1 level-1 4096-bit self-square comparison was +0.062 ms
[+0.006, +0.118]. Its fixed independent 360-block follow-up was +0.010 ms
[-0.023, +0.042]. That follow-up retained a feature-off control difference of
+0.041 ms [+0.001, +0.080]; it remains part of the final control review.
All original observations remain in the evidence.

## Interpreter fallback layout

The complete interpreter warm tier used four balanced fresh-fork rounds across
15 public API workloads, for 144 JMH invocations and 240 parameter forks. Each
fork used three one-second warmup iterations and five one-second measurements.
None of the 15 workloads had a positive 95% paired slowdown interval against
the published enabled VM in this tier.

The preselected `Arrays.hashCode(byte[65537])` case had one unusually slow
published-control fork in the original four-round sample. A fixed ten-round
five-variant follow-up retained that sample and added the prior regressed
implementation `0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc` as a direct control.
The prior implementation averaged 712.204 microseconds and the new implementation
521.042 microseconds. The paired reduction was 191.162 microseconds, with a 95%
interval of 179.107 to 203.217 microseconds. Baseline and candidate flag-off
comparisons included no change in their intervals.

The layout diagnostic records identical offsets for all 239 ordinary bytecode
handlers with common intrinsics off and on. Optional entries follow the ordinary
handlers and precede deoptimization entries. The regression test checks that
structural invariant without a timing assertion.

## Correctness and remaining scope

Current-source release/fastdebug checks include 171 focused jtreg passes and two
additional flagless class-unloading/redefinition passes. Fastdebug native gtests
passed 1399 cases, with 15 disabled. All 864 functional flag/collector checks,
80 concurrent cold-GC probes (2571 actual GC cycles), and eight dynamic-CDS
record/replay checks passed. Static archive checks covered Serial, G1 and ZGC
with both compressed-oop settings and forced-safepoint variants.

PENDING: final tier2 counts, exact failure/skip accounting, remaining cold/startup,
C1/C2 warm throughput, C2 controls, and final review of every positive interval.

Current-source native ARM CDS/ZGC repetition, ARM throughput and size boundaries,
and Windows JVM/native AVX-512 execution remain unqualified. The original ARM
run tested JVM `d8fc74ba01f7e6ed0a77e94f89b1a0922a79a776` with test source
`8bf01e9e`; those historical results do not qualify this implementation.

## Evidence

- [Clean core checks](https://github.com/re-thc/openjdk-jdk27u/tree/b941718fd1fe04af8d9931559a9ad4a9c7c339f6/.github/qualification/chain-checkpoint/layout-stage-02-core)
- [Interpreter tier and complete candidate patch](https://github.com/re-thc/openjdk-jdk27u/tree/f1e6e5549d6e89726a27f42a3aa90b07bb540227/.github/qualification/chain-checkpoint/layout-stage-03-interpreter-warm)
- [Fixed direct hash comparison](https://github.com/re-thc/openjdk-jdk27u/tree/21627047813d25ed42cab49aa12666561a226524/.github/qualification/chain-checkpoint/layout-stage-04-hash-confirmed)
- [Exact-size cold calls and retained control signal](https://github.com/re-thc/openjdk-jdk27u/tree/347ddff8cfa34adb0df617df05b79f293402a189/.github/qualification/chain-checkpoint/layout-stage-05-exact-complete)
