import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation')
d = json.loads((r / 'nss-3.117/qualification-provenance.json').read_text())
command = ['python3', str(r / 'jtreg_batch.py'), 'tier2-nss-pinned-preflight-release',
           str(r / 'images/clean-release'),
           '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
           '--nativepath=/workspace/openjdk-jdk27u/build/pr9-release/images/test/jdk/jtreg/native',
           '--environment=LD_LIBRARY_PATH=' + d['libdir'],
           '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
           '-Djdk.test.lib.random.seed=42 -Dseed=42 '
           '-Djdk.test.lib.artifacts.nsslib-linux_x64=' + d['libdir'],
           'test/jdk/sun/security/pkcs11/tls/TestLeadingZeroesP11.java']
raise SystemExit(subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode)
