import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

r = pathlib.Path('/workspace/pr9-validation/external-data')
r.mkdir(exist_ok=False)
sources = [
    ('lamps-wg', 'kyber-certificates', 'draft-ietf-lamps-kyber-certificates-11', '29f3215b5d0211bf7d2209d2896c755c5d998b29'),
    ('lamps-wg', 'dilithium-certificates', 'draft-ietf-lamps-dilithium-certificates-13', '785a549e69eb7abdd1aa47e8404897a5de699455'),
    ('lamps-wg', 'cms-ml-dsa', 'draft-ietf-lamps-cms-ml-dsa-07', 'c8f0cf7a2df03a11f860ca9619e8b77ad3a3ffb0'),
    ('usnistgov', 'ACVP-Server', 'v1.1.0.38', '85f8742965b2691862079172982683757d8d91db'),
    ('openssl', 'openssl', 'openssl-3.5.4', 'c1eeb9406b6142148f267594197d853403d10208'),
]
record = {'sources': []}
for org, name, tag, expected in sources:
    target = r / org / name
    target.parent.mkdir(exist_ok=True)
    url = f'https://github.com/{org}/{name}.git'
    command = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
               '-c', 'advice.detachedHead=false', 'clone', '--depth=1',
               '--single-branch', '--branch', tag]
    if name == 'ACVP-Server':
        command += ['--filter=blob:none', '--sparse']
    command += [url, str(target)]
    subprocess.run(command, check=True)
    actual = subprocess.check_output(['git', '-C', str(target), 'rev-parse', 'HEAD'], text=True).strip()
    assert actual == expected, (name, actual)
    item = {'organization': org, 'name': name, 'url': url, 'tag': tag, 'commit': actual}
    if name == 'ACVP-Server':
        source = pathlib.Path('/workspace/openjdk-jdk27u/test/jdk/sun/security/provider/acvp/Launcher.java').read_text()
        block = source.split('private static final String[] TEST_FILES = {', 1)[1].split('};', 1)[0]
        files = re.findall(r'"([^"]+)"', block)
        assert files
        subprocess.run(['git', '-C', str(target), 'sparse-checkout', 'set', '--no-cone',
                        *['/' + p for p in files]], check=True)
        archive = r / 'ACVP-Server-1.1.0.38.zip'
        manifest = []
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
            for name_in_repo in files:
                f = target / name_in_repo
                data = f.read_bytes()
                json.loads(data)
                z.writestr('ACVP-Server-1.1.0.38/' + name_in_repo, data)
                manifest.append({'path': name_in_repo, 'bytes': len(data),
                                 'sha256': hashlib.sha256(data).hexdigest()})
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
        item.update(archive=str(archive), archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                    files=manifest)
    record['sources'].append(item)
    (r / 'source-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'verified_sources': len(record['sources'])}))
