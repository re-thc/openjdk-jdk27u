import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation/nss-3.117')
r.mkdir(exist_ok=False)
sources = [
    ('nss', 'NSS_3_117_RTM', '11dc5f9349ad12af08b792a3f705166056547950'),
    ('nspr', 'NSPR_4_37_RTM', '1fbac0ff5100d4ac3ea35477d70a5c6da1fe3ca5'),
]
record = {'documentation': 'https://firefox-source-docs.mozilla.org/security/nss/build.html',
          'target_nss_version': '3.117', 'sources': []}
for name, tag, expected in sources:
    url = f'https://github.com/mozilla/{name}.git'
    command = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
               '-c', 'advice.detachedHead=false', 'clone', '--depth=1',
               '--single-branch', '--branch', tag, url, str(r / name)]
    subprocess.run(command, check=True)
    actual = subprocess.check_output(['git', '-C', str(r / name), 'rev-parse', 'HEAD'], text=True).strip()
    assert actual == expected, (name, actual)
    record['sources'].append({'name': name, 'url': url, 'tag': tag, 'commit': actual})
(r / 'source-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
