import argparse
import hashlib
import json
import pathlib
import subprocess

p = argparse.ArgumentParser()
p.add_argument('kind', choices=['release', 'fastdebug'])
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-validation')
original = f'clean-{a.kind}-tier2-jdk-security'
assert (r / (original + '.result.json')).exists(), 'Wait for the original security batch to finish'
inputs = []
tests = []
for jtr in sorted((r / (original + '-work')).rglob('*.jtr')):
    text = jtr.read_text(errors='replace')
    status = next((line for line in text.splitlines() if line.startswith('execStatus=')), '')
    if not status.startswith('execStatus=Passed. Skipped'):
        continue
    if 'Could not find NSS' not in status and not jtr.name.startswith('FipsModeTLS'):
        continue
    description = next(line.split('=', 1)[1] for line in text.splitlines() if line.startswith('description='))
    description = description.replace('\\:', ':').replace('\\#', '#')
    test = description.removeprefix('file:/workspace/openjdk-jdk27u/')
    assert test.startswith('test/jdk/') and pathlib.Path('/workspace/openjdk-jdk27u', test.split('#')[0]).exists()
    if a.kind == 'release' and test.endswith('sun/security/pkcs11/tls/TestLeadingZeroesP11.java'):
        inputs.append({'original': str(jtr.relative_to(r)), 'test': test,
                       'fulfilled_by': 'tier2-nss-pinned-preflight-release'})
        continue
    tests.append(test)
    inputs.append({'original': str(jtr.relative_to(r)), 'test': test,
                   'sha256': hashlib.sha256(jtr.read_bytes()).hexdigest()})
assert tests
d = json.loads((r / 'nss-3.117/qualification-provenance.json').read_text())
name = f'clean-{a.kind}-tier2-nss-ready'
command = ['python3', str(r / 'jtreg_batch.py'), name, str(r / f'images/clean-{a.kind}'),
           '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
           '--nativepath=/workspace/openjdk-jdk27u/build/pr9-' + a.kind + '/images/test/jdk/jtreg/native',
           '--environment=LD_LIBRARY_PATH=' + d['libdir'],
           '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
           '-Djdk.test.lib.random.seed=42 -Dseed=42 '
           '-Djdk.test.lib.artifacts.nsslib-linux_x64=' + d['libdir'], *tests]
receipt = {'source': '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc',
           'nss_version': d['version'], 'inputs': inputs, 'command': command}
(r / f'tier2-{a.kind}-nss-fill.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode)
