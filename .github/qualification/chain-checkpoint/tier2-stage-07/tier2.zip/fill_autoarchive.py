import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation')
rows = []
for kind in ['release', 'fastdebug']:
    name = f'clean-{kind}-tier2-autoarchive-ready'
    command = ['python3', str(r / 'jtreg_batch.py'), name,
               str(r / f'images/clean-{kind}'),
               '--nativepath=/workspace/openjdk-jdk27u/build/pr9-' + kind + '/images/test/hotspot/jtreg/native',
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42 -Dtest.boot.jdk=/workspace/toolchains/jdk27',
               'test/hotspot/jtreg/runtime/cds/appcds/dynamicArchive/TestAutoCreateSharedArchiveUpgrade.java']
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    rows.append({'name': name, 'exit_code': code, 'command': command})
    (r / 'tier2-autoarchive-fill.json').write_text(json.dumps(rows, indent=2) + '\n')
