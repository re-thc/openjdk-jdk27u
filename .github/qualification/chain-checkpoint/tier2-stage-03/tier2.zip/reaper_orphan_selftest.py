import json
import os
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation/reaper-orphan-selftest')
r.mkdir(exist_ok=False)
children = []
for n in range(16):
    child = subprocess.Popen(['/usr/bin/tee', str(r / f'helper-{n}.txt')],
                             stdin=subprocess.PIPE, stdout=subprocess.DEVNULL)
    child.stdin.write(f'orphan-helper-{n}\n'.encode())
    child.stdin.flush()
    children.append(child)
(r / 'helpers.json').write_text(json.dumps({'parent_pid': os.getpid(),
    'helper_pids': [c.pid for c in children],
    'expected_children_reaped_by_supervisor': 17}, indent=2) + '\n')
# Deliberately skip Popen.wait and pipe cleanup. The real tee helpers are
# orphaned, receive EOF at exit, and must be adopted/reaped by run_reaped.py.
os._exit(0)
