import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation')
cds = ['test/hotspot/jtreg/runtime/cds/appcds/' + name + '.java'
       for name in ['TestEpsilonGCWithCDS', 'TestParallelGCWithCDS', 'TestShenandoahWithCDS']]
sa = ['test/hotspot/jtreg/serviceability/sa/' + name + '.java'
      for name in ['TestJmapCore', 'TestJmapCoreMetaspace']]
images = json.loads((r / 'images.json').read_text())
record = {'status': 'running', 'cohorts': []}
for label, image, options, tests in [
    ('master-default', 'master', '', cds + sa),
    ('before-default', 'before', '', cds + sa),
    ('current-fourbyte-off', 'final', ' -XX:-UseFourByteObjectHeaders', cds),
]:
    name = 'tier2-classify-' + label
    command = ['python3', str(r / 'jtreg_batch.py'), name, images[image]['path'],
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42' + options, *tests]
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    record['cohorts'].append({'name': name, 'image_source': images[image]['source'],
                              'exit_code': code, 'command': command})
    (r / 'tier2-classification.json').write_text(json.dumps(record, indent=2) + '\n')
record['status'] = 'completed-awaiting-analysis'
(r / 'tier2-classification.json').write_text(json.dumps(record, indent=2) + '\n')
