# First-use preparation review notes — source 0fb3e86a762

The changed code prepares the compiler blob before BigInteger's nontrivial
modular exponentiation and recursive squaring computations. Preparing only at
the first Montgomery kernel left two preparatory products in Java. Preparing
by an individual kernel's size also charged an isolated 2048-bit square for a
blob it could finish faster without. The selected hooks match the exact
bootstrap BigInteger class, private method names and signatures. They do not
replace those Java computations.

Recursive multiplication additionally reads the two magnitude lengths and
compares their product with 104^2 limbs in interpreter mode, or 120^2 when a
compiler is enabled. These thresholds came from the preserved exploratory
crossover samples and passed a fresh committed-source sample. Final timings
are pending; native ARM crossover performance has not been measured.

The magnitude reads reuse KnownField's allocation-free bootstrap field decoder.
A NoSafepointVerifier encloses the raw oop reads. The helper returns only an
intrinsic ID; its raw oop locals and verifier are gone before prepare() can
block. Every caller roots its selected Method. Cache publication and MemberName
publication retain source 0af's refresh of CallInfo's current method inside the
publication verifier after preparation. Blocking work stays outside that scope.
The new preparation decisions do not authorize publishing an obsolete target.

Preparation still goes through existing intrinsic/CPU availability and flag
checks. Smaller first products retain cumulative demand and Java execution;
compiled warm paths retain their existing stubs. The interpreter cache helper
also handles nonstatic BigInteger Java targets, while reading expression-stack
objects only for the exact two-argument static recursive multiply helper.

Both clean images passed the expanded initialization test, including deferred
medium operations, first large operations and fixed independent modPow oracles.
The previous 0af image fails the new first-large-square initialization assertion.
Both images passed concurrent non-identical method redefinition of the kernels
and enclosing Java targets. The original race test also passed before the
stale-target repair; no reproduced before/after VM crash is claimed.

Both images additionally passed 40 concurrent first-use product probes under
five collectors and both compressed-oop settings, with 2570 actual GC cycles.
All interpreter/C1 probes generated the blob after the first-use gate. Dynamic
CDS record/replay probes also produced matching results and one generation.

The shared interpreter generator still uses ordinary Java entries for static
archive assembly, while keeping common entries during AOT preimage training
and normal/dynamic execution. Release and fastdebug each passed six x64 archive
comparison records, including forced safepoints. Original ARM ZGC archive
nondeterminism remains unqualified: the approved older run is a different JVM,
and raw transfers into this executor are blocked by proxy 403. This packet does
not claim that a green workflow or a successful retry proves that ARM fix.
