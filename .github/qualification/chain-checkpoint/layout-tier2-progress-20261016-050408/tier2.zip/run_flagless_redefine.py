"""Execute the previously excluded class-unloading test with actual flagless VMs."""
import concurrent.futures
import json
import os
import pathlib
import subprocess

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
state=json.loads((r/'early-warm-state.json').read_text())
assert state['source']==source and state['status']=='first-interpreter-tier-complete-awaiting-review'
assert not subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True).stdout.strip()
cpus=sorted(os.sched_getaffinity(0));assert len(cpus)>=4
def run(item):
    kind,affinity=item
    build=json.loads((r/('clean-'+kind+'.json')).read_text())
    assert build['source']==source and build['status']=='passed'
    name='clean-'+kind+'-tier2-redefine-flagless-ready'
    command=['taskset','-c',','.join(map(str,affinity)),'python3',str(r/'jtreg_batch.py'),
             name,build['path'],'--vmoptions=',
             '--nativepath=/workspace/openjdk-jdk27u/build/pr9-'+kind+'/images/test/hotspot/jtreg/native',
             'test/hotspot/jtreg/serviceability/jvmti/RedefineClasses/RedefinePreviousVersions.java']
    code=subprocess.run(command,cwd='/workspace/openjdk-jdk27u').returncode
    return {'kind':kind,'name':name,'command':command,'exit_code':code,
            'scope':'Real flagless VM selection. CPU affinity bounds resources without overriding TEST_VM_FLAGLESS.'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(run,[('release',cpus[:2]),('fastdebug',cpus[2:4])]))
(r/'flagless-redefinition-fill.json').write_text(json.dumps({'source':source,'records':rows},indent=2)+'\n')
assert all(x['exit_code']==0 for x in rows),rows
