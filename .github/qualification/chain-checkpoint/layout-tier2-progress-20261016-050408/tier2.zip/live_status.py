"""Record a compact live snapshot without changing qualification outcomes."""
import datetime
import json
import os
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-layout-validation')
result = subprocess.run(['python3', str(r / 'tier2_status.py')],
                        capture_output=True, text=True, check=True)
lines = result.stdout.splitlines()
groups = {line.split()[0]: int(line.split()[-1]) for line in lines[:2]}
active = [json.loads(line) for line in lines[2:-1]]
totals = json.loads(lines[-1])
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
          'completed_main_groups': groups, 'active': active, **totals,
          'memory_events': pathlib.Path('/sys/fs/cgroup/memory.events').read_text()}
path = r / 'live-status.json'
temporary = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
temporary.write_text(json.dumps(record, indent=2) + '\n')
temporary.replace(path)
print(json.dumps({k: record[k] for k in ['utc', 'completed_main_groups',
                 'total_observed_counts', 'active_batches', 'pid1_zombies', 'free_GiB']}))
