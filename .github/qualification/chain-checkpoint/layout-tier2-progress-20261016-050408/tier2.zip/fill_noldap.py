import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-layout-validation')
rows = []
for kind in ['release', 'fastdebug']:
    name = f'clean-{kind}-tier2-noldap-ready'
    command = ['python3', str(r / 'jtreg_batch.py'), name, str(r / f'images/clean-{kind}'),
               '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
               '--nativepath=/workspace/openjdk-jdk27u/build/pr9-' + kind + '/images/test/jdk/jtreg/native',
               '--javaoptions=--limit-modules=java.base',
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42',
               'test/jdk/java/security/cert/CertStore/NoLDAP.java']
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    rows.append({'name': name, 'exit_code': code, 'command': command})
    (r / 'tier2-noldap-fill.json').write_text(json.dumps(rows, indent=2) + '\n')
raise SystemExit(0 if all(row['exit_code'] == 0 for row in rows) else 1)
