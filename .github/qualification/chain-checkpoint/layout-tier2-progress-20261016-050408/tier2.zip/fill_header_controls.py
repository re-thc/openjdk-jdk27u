"""Additional matching-header controls; preserve original cross-GC failures."""
import datetime
import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'],
                               text=True).strip() == source
tests = ['test/hotspot/jtreg/runtime/cds/appcds/' + test + '.java'
         for test in ['TestEpsilonGCWithCDS', 'TestParallelGCWithCDS',
                      'TestShenandoahWithCDS']]
record = {'source': source, 'status': 'running', 'cohorts': [],
          'scope': 'Additional controls with matching archive/object-header flags. '
                   'Original failures remain unchanged; unrelated to ARM same-flag '
                   'archive-resolution nondeterminism.'}
for kind in ['release', 'fastdebug']:
    name = f'clean-{kind}-tier2-crossgc-headeroff-ready'
    command = ['python3', str(r / 'jtreg_batch.py'), name,
               str(r / f'images/clean-{kind}'),
               '--nativepath=' + str(repo / f'build/pr9-{kind}/images/test/hotspot/jtreg/native'),
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42 -XX:-UseFourByteObjectHeaders',
               *tests]
    code = subprocess.run(command, cwd=repo).returncode
    record['cohorts'].append({'name': name, 'exit_code': code, 'command': command})
    record['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (r / 'tier2-header-control-fill.json').write_text(json.dumps(record, indent=2) + '\n')
record['status'] = ('passed-additional-controls' if
                    all(x['exit_code'] == 0 for x in record['cohorts']) else 'has-failures')
(r / 'tier2-header-control-fill.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(0 if record['status'] == 'passed-additional-controls' else 1)
