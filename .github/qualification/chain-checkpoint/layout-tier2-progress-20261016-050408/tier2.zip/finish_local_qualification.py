"""Continue the authorized local work after the last healthy tier2 batch."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
state = {'source': source, 'status': 'waiting-for-main-tier2', 'steps': []}
state_path = r / 'local-continuation.json'
assert not state_path.exists(), 'Do not duplicate the local continuation'

def save():
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')

def read_json(path):
    for attempt in range(5):
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError:
            if attempt == 4:
                raise
            time.sleep(.1)

def run(name, *arguments):
    state['status'] = name
    save()
    log = r / ('local-continuation-' + name + '.log')
    command = ['python3', str(r / 'run_reaped.py'), str(log), *arguments]
    code = subprocess.run(command).returncode
    state['steps'].append({'name': name, 'command': command, 'exit_code': code})
    save()
    if code:
        raise RuntimeError(name + ' failed; preserve logs for review')
    return log

try:
    save()
    while True:
        groups = [read_json(r / ('tier2-' + kind + '.json'))
                  for kind in ['release', 'fastdebug']]
        assert all(d['source'] == source for d in groups)
        if all(d['status'] in ['passed', 'has-failures'] and len(d['cohorts']) == 11
               for d in groups):
            break
        time.sleep(10)
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'],
                                   text=True).strip() == source
    run('assessment', 'python3', str(r / 'assess_tier2.py'))
    assessment_path = r / 'tier2-assessment.json'
    assessment = json.loads(assessment_path.read_text())
    assert assessment['source'] == source and assessment['local_timing_eligible']
    for key in ['pending', 'unknown_failures', 'unreviewed_skips', 'unresolved_batch_errors']:
        assert not assessment[key], (key, assessment[key])
    label = 'layout-tier2-final'
    folder = pathlib.Path('/workspace/pr9-recovery') / label
    run('pack-tier2', 'python3', str(r / 'pack_tier2_evidence.py'), label)
    qualification = json.loads((folder / 'qualification.json').read_text())
    assert qualification['source'] == source
    assert qualification['status'] == 'completed-tier2-with-explicit-local-limitations'
    remote_folder = '.github/qualification/chain-checkpoint/' + label
    log = run('publish-tier2', 'python3', str(r / 'publish_evidence.py'), str(folder),
              remote_folder, 'Checkpoint completed source-aligned local tier2 qualification')
    commit = log.read_text().strip().splitlines()[-1]
    assert re.fullmatch('[0-9a-f]{40}', commit), commit
    receipt = {'source': source,
               'assessment_sha256': hashlib.sha256(assessment_path.read_bytes()).hexdigest(),
               'commit': commit, 'qualification_path': remote_folder + '/qualification.json'}
    receipt_path = r / 'pre-performance-evidence.json'
    assert not receipt_path.exists(), 'Preserve the original pre-performance receipt'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    state['pre_performance_evidence'] = receipt
    save()
    run('performance', 'python3', str(r / 'final_performance.py'))
    run('performance-analysis', 'python3', str(r / 'analyze_final_performance.py'))
    state['status'] = 'local-measurements-complete-awaiting-signal-review'
    save()
except BaseException as error:
    state['status'] = 'blocked-for-review'
    state['error'] = repr(error)
    save()
    raise
