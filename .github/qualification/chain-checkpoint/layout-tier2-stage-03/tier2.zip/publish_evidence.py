import argparse, json, os, pathlib, subprocess, tempfile
p=argparse.ArgumentParser()
p.add_argument('folder');p.add_argument('remote_folder');p.add_argument('message');a=p.parse_args()
folder=pathlib.Path(a.folder).resolve(strict=True)
assert folder.is_dir(), 'Evidence source must be a directory'
qualification=json.loads((folder/'qualification.json').read_text())
assert qualification.get('source') and qualification.get('status'), 'Require completed packet metadata before publication'
files=sorted(f for f in folder.rglob('*') if f.is_file())
assert files, 'Refuse an empty evidence checkpoint'
r=pathlib.Path('/workspace/openjdk-jdk27u')
def git(*args,input=None,env=None):
 return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',
                                 '-C',str(r),*args],input=input,env=env).decode().strip()
branch='pr/common-intrinsics-final-evidence'
git('fetch','origin','refs/heads/'+branch+':refs/remotes/origin/'+branch)
base=git('rev-parse','refs/remotes/origin/'+branch)
with tempfile.TemporaryDirectory(prefix='evidence-index-',dir='/workspace/pr9-recovery') as td:
 env=dict(os.environ,GIT_INDEX_FILE=td+'/index')
 git('read-tree',base,env=env)
 for f in files:
  remote=a.remote_folder.rstrip('/')+'/'+str(f.relative_to(folder))
  blob=git('hash-object','-w','--stdin',input=f.read_bytes())
  git('update-index','--add','--cacheinfo','100644,'+blob+','+remote,env=env)
 tree=git('write-tree',env=env)
 commit=git('commit-tree',tree,'-p',base,input=(a.message+'\n').encode())
 git('push','origin',commit+':refs/heads/'+branch)
 print(commit,flush=True)
