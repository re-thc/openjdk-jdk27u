"""Prepare an unapplied workflow-only diagnostic repair; never launch a build."""
import difflib
import hashlib
import json
import pathlib
import re
import subprocess

import yaml

r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
out = r / 'native-identity-diagnostic-repair'
out.mkdir(exist_ok=False)
base = '12fb0c876b9ec3b23ce59f003badc086e2b0f368'
expected = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
patches, files, checks = [], [], []
for platform in ['linux', 'windows']:
    name = f'.github/workflows/pr9-native-{platform}.yml'
    before = subprocess.check_output(['git', '-C', str(repo), 'show', base + ':' + name], text=True)
    old = '''          set -euo pipefail
          test "$(git rev-parse HEAD)" = e41d7823bf6de77c4bfba52e896bf325221488cb
          image="build/${{ inputs.platform }}/images/jdk"
          grep -Fx 'SOURCE=".:git:e41d7823bf6d"' "$image/release"
          identity="$RUNNER_TEMP/pr9-identity"
          mkdir -p "$identity"
          git rev-parse HEAD > "$identity/checkout-source.txt"
          cp "$image/release" "$identity/release"
'''
    new = '''          set -euo pipefail
          image="build/${{ inputs.platform }}/images/jdk"
          identity="$RUNNER_TEMP/pr9-identity"
          mkdir -p "$identity"
          trap 'rc=$?; printf "exit_code=%s\\n" "$rc" > "$identity/source-validation-status.txt"; trap - EXIT; exit "$rc"' EXIT
          git rev-parse HEAD | tee "$identity/checkout-source.txt"
          git status --porcelain > "$identity/git-status.txt"
          cp "$image/release" "$identity/release"
          sed -n '/^SOURCE=/p' "$image/release" | tee "$identity/source-line.txt"
          set -x
          test "$(git rev-parse HEAD)" = e41d7823bf6de77c4bfba52e896bf325221488cb
          grep -Fx 'SOURCE=".:git:e41d7823bf6d"' "$image/release"
          set +x
'''
    assert before.count(old) == 1
    after = before.replace(old, new)
    assert after.count('    strategy:\n      matrix:\n') == 1
    after = after.replace('    strategy:\n      matrix:\n',
                          '    strategy:\n      fail-fast: false\n      matrix:\n')
    target = "      - name: 'Upload actual-source identity receipt'\n"
    assert after.count(target) == 1
    after = after.replace(target, target + "        if: ${{ !cancelled() && steps.build.outcome == 'success' }}\n")
    fallback = '''
      - name: 'Preserve built bundles after diagnostic failure'
        if: ${{ failure() && !cancelled() && steps.build.outcome == 'success' }}
        uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a
        with:
          name: pr9-native-unverified-bundles-${{ inputs.platform }}-${{ matrix.debug-level }}
          path: build/${{ inputs.platform }}/bundles/*
          if-no-files-found: error
          retention-days: 14
'''
    # Appending the forced-on-failure upload avoids changing candidate-source
    # composite actions, and leaves the normal successful upload untouched.
    after += fallback
    original = yaml.load(before, Loader=yaml.BaseLoader)
    revised = yaml.load(after, Loader=yaml.BaseLoader)
    job_key = 'build-' + platform
    assert original['on'] == revised['on']
    assert revised['jobs'][job_key]['strategy']['fail-fast'] == 'false'
    original_steps = original['jobs'][job_key]['steps']
    revised_steps = revised['jobs'][job_key]['steps']
    for label in ['Checkout the JDK source', 'Checkout immutable candidate bundle',
                  'Restore and verify exact candidate source', 'Configure', 'Build',
                  'Check development profile']:
        assert next(s for s in original_steps if s.get('name') == label) == next(
            s for s in revised_steps if s.get('name') == label), label
    assert after.count("grep -Fx 'SOURCE=\".:git:e41d7823bf6d\"'") == 1
    for step in revised_steps:
        if 'run' in step:
            shell = re.sub(r'\$\{\{.*?\}\}', 'static-check-value', step['run'], flags=re.S)
            result = subprocess.run(['bash', '-n'], input=shell, text=True, capture_output=True)
            assert result.returncode == 0, (name, step.get('name'), result.stderr)
            checks.append({'workflow': name, 'step': step.get('name'), 'check': 'bash-n'})
    path = out / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(after)
    files.append({'path': name, 'sha256': hashlib.sha256(after.encode()).hexdigest()})
    patches.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                       fromfile='a/' + name, tofile='b/' + name))
patch = out / 'identity-diagnostics.patch'
patch.write_text(''.join(patches))
metadata = {'source': expected, 'base_workflow_revision': base,
            'status': 'prepared-only-not-applied-not-dispatched', 'files': files,
            'patch_sha256': hashlib.sha256(patch.read_bytes()).hexdigest(),
            'static_checks': checks,
            'scope': 'Diagnostic output/artifact retention and matrix failure isolation only. '
                     'Runtime sources, build commands and existing identity assertions are unchanged. '
                     'Actual remote SOURCE is unknown, so the strict check is not relaxed. '
                     'No build, rerun, VM test or stopped archive stress was launched.'}
(out / 'qualification.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'status': metadata['status'], 'patch_sha256': metadata['patch_sha256'],
                  'shell_steps': len(checks)}))
