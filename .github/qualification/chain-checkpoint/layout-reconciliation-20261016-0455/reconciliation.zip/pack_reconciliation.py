"""Checkpoint diagnostics and existing results, without executing qualification."""
import argparse
import datetime
import hashlib
import json
import pathlib
import shutil
import zipfile

p = argparse.ArgumentParser()
p.add_argument('label')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
out = pathlib.Path('/workspace/pr9-recovery') / a.label
out.mkdir(exist_ok=False)
names = ['RECONCILIATION.md', 'native-terminal-reconciliation.json',
         'old-archive-diagnostic-reconciliation.json', 'unfinished-work-reconciliation.json',
         'local-unmet-cases-plan.json', 'directory-creation-probe.json',
         'reconciliation-resource-evidence.json', 'qualification-hold.json',
         'assess_tier2.py', 'assess_tier2.pre-reconciliation.py', 'tier2-assessment.json',
         'tier2-observed-failures.json', 'reconciliation-assessment.log',
         'prepare_identity_diagnostic_repair.py', 'check_identity_diagnostic_repair.py',
         'pack_reconciliation.py', 'core-assessment.json', 'core-evidence.json',
         'early-warm-state.json', 'early-exact-performance.json', 'hash-review-decision.json',
         'exact-cold-review-decision.json', 'layout-hash-confirmation-analysis.json',
         'exact-square-confirmation-analysis.json', 'reconciled-source-history.txt',
         'ARM_CDS_SOURCE_TRACE.md', 'original-arm-transfer-blockers.json',
         'live-status.json', 'tier2-release.json', 'tier2-fastdebug.json',
         'local-continuation.json', 'after-net-prefetch.json', 'after-security-prefetch.json',
         'native-activation.json', 'native-qualification-proposal.json',
         'periodic-tier2-checkpoints.json', 'pr9-metadata-return.json']
files = {r / name for name in names if (r / name).is_file()}
files.update(f for f in (r / 'native-failure-logs').rglob('*') if f.is_file())
files.update(f for f in (r / 'native-identity-diagnostic-repair').rglob('*') if f.is_file())
for result in r.glob('clean-*-tier2-*.result.json'):
    if not result.name.endswith('.log.result.json'):
        files.add(result)
observed = json.loads((r / 'tier2-observed-failures.json').read_text())
for row in observed['failed_jtrs']:
    file = r / row['path']
    assert hashlib.sha256(file.read_bytes()).hexdigest() == row['sha256']
    files.add(file)
manifest = []
with zipfile.ZipFile(out / 'reconciliation.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(files):
        data = file.read_bytes()
        relative = str(file.relative_to(r))
        archive.writestr(relative, data)
        manifest.append({'path': relative, 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'reconciliation.zip') as archive:
    assert archive.testzip() is None
shutil.copyfile(r / 'RECONCILIATION.md', out / 'README.md')
repair = r / 'native-identity-diagnostic-repair'
shutil.copyfile(repair / 'identity-diagnostics.patch', out / 'identity-diagnostics.patch')
shutil.copyfile(repair / 'synthetic-checks.json', out / 'synthetic-checks.json')
packet = out / 'reconciliation.zip'
record = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
          'status': 'incomplete-qualification-held-diagnostic-repair-only',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'files': len(manifest),
          'archive': {'name': packet.name, 'bytes': packet.stat().st_size,
                      'sha256': hashlib.sha256(packet.read_bytes()).hexdigest()},
          'diagnostic_patch_sha256': hashlib.sha256((out / 'identity-diagnostics.patch').read_bytes()).hexdigest(),
          'no_workflow_patch_applied': True, 'no_dispatch_or_rerun': True,
          'security_constraint': 'No stopped four-byte-header stress was rerouted or executed.',
          'scope': 'Existing logs/results/source identity reconciliation and unapplied workflow diagnostics. '
                   'No native binary identity, original ARM archive correctness, complete performance '
                   'or readiness qualification is claimed.'}
(out / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
