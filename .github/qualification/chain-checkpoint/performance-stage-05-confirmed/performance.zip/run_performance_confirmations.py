"""Execute the prospectively recorded follow-ups after the main matrix."""
import hashlib
import json
import os
import pathlib
import subprocess
import time

r = pathlib.Path('/workspace/pr9-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
plan_path = r / 'performance-confirmation-plan.json'
plan_bytes = plan_path.read_bytes()
plan = json.loads(plan_bytes)
main = json.loads((r / 'final-performance.json').read_text())
assert plan['source'] == main['source'] == source
stop_path = r / 'performance-interruption.json'
if stop_path.exists():
    stop = json.loads(stop_path.read_text())
    assert stop['source'] == source and stop.get('verified_quiet_utc')
    assert main['status'] == 'measurement-failed' and len(main['phases']) == 6
    assert all(x['exit_code'] == 0 for x in main['phases'][:5])
    assert main['phases'][-1]['name'] == 'warm' and main['phases'][-1]['exit_code'] == 241
    assert stop['supervisor_result']['exit_code'] == -15
    assert not any(x['exit_code'] for x in json.loads((r / 'final-warm/manifest.json').read_text())['records'])
else:
    assert main['status'] == 'measurements-complete-awaiting-regression-analysis'
    assert len(main['phases']) == 7 and all(x['exit_code'] == 0 for x in main['phases'])
    assert json.loads((r / 'local-continuation.json').read_text())['status'] == 'local-measurements-complete-awaiting-signal-review'
    analysis = json.loads((r / 'final-performance-analysis.json').read_text())
    assert analysis['source'] == source and analysis['status'] == 'complete-awaiting-signal-review' and not analysis['missing']
assert sorted(os.sched_getaffinity(0))[:2] == [0, 1]
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
assert hashlib.sha256((r / 'images.json').read_bytes()).hexdigest() == plan['images_sha256']
for attempt in range(12):
    running = subprocess.run(['ps', '-C', 'java,make,gmake,cc1plus', '-o', 'pid='],
                             capture_output=True, text=True)
    if not running.stdout.strip(): break
    time.sleep(5)
else:
    raise RuntimeError('Other JVM/build activity remains; do not time concurrently')
images = json.loads((r / 'images.json').read_text())
for image in images.values():
    for name, fingerprint in image['fingerprints'].items():
        assert hashlib.sha256((pathlib.Path(image['path']) / name).read_bytes()).hexdigest() == fingerprint['sha256']
path = r / 'performance-confirmations.json'
state = json.loads(path.read_text()) if path.exists() else {
    'source': source, 'plan_sha256': hashlib.sha256(plan_bytes).hexdigest(),
    'cold_helper_sha256': hashlib.sha256((r / 'cold_matrix.py').read_bytes()).hexdigest(),
    'status': 'measuring', 'cases': []}
assert state['source'] == source and state['plan_sha256'] == hashlib.sha256(plan_bytes).hexdigest()
assert state['cold_helper_sha256'] == hashlib.sha256((r / 'cold_matrix.py').read_bytes()).hexdigest()

def save():
    path.write_text(json.dumps(state, indent=2) + '\n')

completed = {x['name']: x for x in state['cases']}
save()
for followup in plan['commands']:
    name, command = followup['name'], followup['command']
    folder = r / command[command.index('--output') + 1]
    warm = followup.get('kind') == 'warm'
    output = folder / 'manifest.json' if warm else folder
    if name in completed:
        previous = completed[name]
        assert previous['command'] == command and previous['exit_code'] == 0
        assert hashlib.sha256(output.read_bytes()).hexdigest() == previous['output_sha256']
        if warm:
            assert hashlib.sha256((folder / 'summary.json').read_bytes()).hexdigest() == previous['summary_sha256']
        continue
    start = time.time()
    code = subprocess.run(command).returncode
    record = {'name': name, 'command': command, 'exit_code': code,
              'seconds': time.time() - start}
    if code == 0:
        data = json.loads(output.read_text())
        assert data['images'] == images
        if warm:
            assert data['pairs'] == 8 and len(data['records']) == 32
            assert all(x['exit_code'] == 0 for x in data['records'])
            for invocation in data['records']:
                assert hashlib.sha256((folder / (invocation['name'] + '.json')).read_bytes()).hexdigest() == invocation['result_sha256']
            subprocess.run(['python3', str(r / 'summarize_warm.py'), str(folder)], check=True)
            record['summary_sha256'] = hashlib.sha256((folder / 'summary.json').read_bytes()).hexdigest()
        else:
            assert all(x['status'] == 'passed' for x in data['results'].values())
        record['output_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
    state['cases'].append(record)
    save()
    if code:
        state['status'] = 'measurement-failed-preserve-originals'
        save()
        raise SystemExit(code)
state['status'] = 'measurements-complete-awaiting-confirmation-review'
save()
