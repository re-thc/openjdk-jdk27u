"""Prospective large-hash follow-up using the original JMH command template."""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--pairs', type=int, default=8)
p.add_argument('--output', required=True)
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-validation')
original = json.loads((r / 'final-warm/manifest.json').read_text())
images = json.loads((r / 'images.json').read_text())
assert original['images'] == images
assert images['final']['source'] == '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
assert sorted(os.sched_getaffinity(0))[:2] == [0, 1]
os.sched_setaffinity(0, {1})
for name, sha in original['classpath_sha256'].items():
    assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() == sha
out = r / a.output
out.mkdir(exist_ok=True)
path = out / 'manifest.json'
records = []
if path.exists():
    prior = json.loads(path.read_text())
    assert prior['images'] == images and prior['pairs'] == a.pairs
    assert prior['classpath_sha256'] == original['classpath_sha256']
    records = prior['records']
completed = {x['name']: x for x in records}
labels = ['master', 'before-on', 'final-off', 'final-on']
templates = {}
for label in labels:
    templates[label] = next(x for x in original['records'] if x['tier'] == 'int' and
                            x['case'] == 'hash' and x['label'] == label and x['pair'] == 0)

def save():
    data = {k: v for k, v in original.items() if k != 'records'}
    data.update(pairs=a.pairs, records=records,
                scope='Prospective interpreter hash65537 confirmation; no other warm cases repeated.')
    path.write_text(json.dumps(data, indent=2) + '\n')

for pair in range(a.pairs):
    order = labels[pair % 4:] + labels[:pair % 4]
    for label in order:
        name = f'int-hash-{label}-{pair}'
        result = out / (name + '.json')
        command = list(templates[label]['command'])
        index = command.index('-p') + 1
        assert command[index] == 'length=1,32,65537'
        command[index] = 'length=65537'
        command[command.index('-rff') + 1] = str(result)
        if name in completed:
            old = completed[name]
            assert old['command'] == command and old['exit_code'] == 0
            assert hashlib.sha256(result.read_bytes()).hexdigest() == old['result_sha256']
            continue
        assert not result.exists(), 'Unrecorded output requires investigation: ' + str(result)
        with (out / (name + '.log')).open('w') as log:
            code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
        record = {'name': name, 'tier': 'int', 'case': 'hash', 'label': label,
                  'pair': pair, 'command': command, 'exit_code': code}
        if code == 0:
            body = result.read_bytes()
            data = json.loads(body)
            assert len(data) == 1 and data[0]['params'] == {'length': '65537'}
            record.update(results=data, result_sha256=hashlib.sha256(body).hexdigest())
        records.append(record)
        save()
        print(name + ' exit ' + str(code), flush=True)
        if code: raise SystemExit(code)
