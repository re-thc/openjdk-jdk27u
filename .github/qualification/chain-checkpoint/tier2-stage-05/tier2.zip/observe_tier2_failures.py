import collections
import hashlib
import json
import pathlib
import re

r = pathlib.Path('/workspace/pr9-validation')
known = json.loads((r / 'tier2-failure-analysis.json').read_text())['failures']
known = {x['test_jtr']: x for x in known}
rows = []
for work in sorted(r.glob('clean-*-tier2-*-work')):
    for jtr in sorted(work.rglob('*.jtr')):
        text = jtr.read_text(errors='replace')
        status = re.search(r'^execStatus=(Failed|Error)\.(.*)$', text, re.M)
        if status is None:
            continue
        rel = str(jtr.relative_to(work))
        keys = re.search(r'^keywords=(.*)$', text, re.M)
        classification = 'unclassified'
        if keys and 'manual' in keys.group(1).split():
            classification = 'manual-outside-official-automatic-selection'
        elif rel in known and known[rel]['message'] in text:
            matched = True
            if rel.endswith('/Cleaners.jtr'):
                detail = known[rel]
                child = work / 'sun/security/krb5/auto/Cleaners/server.stderr'
                matched = ((work.name == 'clean-release-tier2-jdk-security-work' and
                            hashlib.sha256(jtr.read_bytes()).hexdigest() == detail['original_jtr_sha256']) or
                           (child.exists() and detail['native_cause_message'] in child.read_text(errors='replace')))
            if matched:
                classification = known[rel]['category']
        rows.append({'cohort': work.name.removesuffix('-work'), 'test_jtr': rel,
                     'path': str(jtr.relative_to(r)), 'status': status.group(1),
                     'detail': status.group(2), 'classification': classification})
counts = dict(collections.Counter(x['classification'] for x in rows))
record = {'source': '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc',
          'status': 'investigation-required' if counts.get('unclassified', 0)
                    else 'incomplete-with-classified-observed-failures',
          'counts': counts, 'failed_jtrs': rows,
          'scope': 'Observed JTRs only. This does not certify a clean or complete tier2.'}
(r / 'tier2-observed-failures.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'counts': counts,
                  'unknown': [x for x in rows if x['classification'] == 'unclassified']}))
