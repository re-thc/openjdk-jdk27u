import argparse
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import zipfile

p = argparse.ArgumentParser()
p.add_argument('label')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-validation')
out = pathlib.Path('/workspace/pr9-recovery') / a.label
out.mkdir(parents=True, exist_ok=False)
source = subprocess.check_output(['git', '-C', '/workspace/openjdk-jdk27u',
                                  'rev-parse', 'HEAD'], text=True).strip()
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert source == '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
cohorts = []
files = set()
snapshots = {}
active = []
for result in sorted(r.glob('clean-*-tier2-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    d = json.loads(result.read_text())
    assert d['source_checkout_at_start'] == source
    name = result.name.removesuffix('.result.json')
    lines = d['summary'].splitlines()
    counts = {status: sum((' ' + status + '.') in line for line in lines)
              for status in ['Passed', 'Failed', 'Error', 'Skipped', 'Not run']}
    cohorts.append({'name': name, 'exit_code': d['exit_code'], 'counts': counts})
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-report/text')).glob('*'))
for log in sorted(r.glob('clean-*-tier2-*.log')):
    if (r / (log.stem + '.result.json')).exists():
        continue
    data = log.read_bytes()
    snapshots[log] = data
    lines = data.decode(errors='replace').splitlines()
    active.append({'name': log.stem, 'status': 'incomplete',
                   'passed_log_records': sum(x.startswith('Passed:') for x in lines),
                   'failed_log_records': sum(x.startswith('FAILED:') for x in lines)})
    for jtr in (r / (log.stem + '-work')).rglob('*.jtr'):
        data = jtr.read_bytes()
        lines = data.decode(errors='replace').splitlines()
        if lines and lines[-1].startswith('test result: '):
            snapshots[jtr] = data
for name in ['tier2-release.json', 'tier2-fastdebug.json', 'run_tier2.py',
             'jtreg_batch.py', 'run_reaped.py', 'pack_tier2_evidence.py',
             'tier2-runtime-selection.txt', 'tier2-classification.json',
             'reaper-prevention-before.json', 'reaper-prevention-after.json',
             'reaper_orphan_selftest.py', 'reaper-orphan-selftest.log',
             'reaper-orphan-selftest.log.result.json', 'classify_tier2.py',
             'analyze_tier2_failures.py', 'tier2-failure-analysis.json',
             'pr9-current-metadata.json', 'tier2-selection-correction.json',
             'tier2-reuse-preflight.json', 'observe_tier2_failures.py',
             'tier2-observed-failures.json', 'tier2-ldap-classification.json',
             'classify_ldap_dns.py', 'tier2-resource-check.json', 'tier2_status.py']:
    f = r / name
    if f.exists(): files.add(f)
for name in ['classify_cleaners.py', 'tier2-cleaners-classification.json']:
    f = r / name
    if f.exists(): files.add(f)
for result in sorted(r.glob('tier2-classify-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    name = result.name.removesuffix('.result.json')
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-work')).rglob('*.stderr'))
    files.update((r / (name + '-report/text')).glob('*'))
files.update((r / 'reaper-orphan-selftest').glob('*'))
analysis = r / 'tier2-failure-analysis.json'
if analysis.exists():
    for failure in json.loads(analysis.read_text())['failures']:
        for rel in [*failure['reproduced'].values(),
                    *failure['passing_same_source_fourbyte_headers_off'].values()]:
            files.add(r / rel)
observed = r / 'tier2-observed-failures.json'
if observed.exists():
    files.update(r / x['path'] for x in json.loads(observed.read_text())['failed_jtrs'])
manifest = []
with zipfile.ZipFile(out / 'tier2.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files | snapshots.keys()):
        if not f.is_file(): continue
        data = snapshots[f] if f in snapshots else f.read_bytes()
        name = str(f.relative_to(r))
        z.writestr(name, data)
        manifest.append({'path': name, 'size': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'tier2.zip') as z:
    assert z.testzip() is None
packet = out / 'tier2.zip'
record = {'source': source, 'status': 'partial-tier2-with-retained-failures',
          'snapshot_started_utc': started_at,
          'snapshot_finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts': cohorts, 'active_snapshots': active, 'files': len(manifest),
          'archive': {'name': packet.name, 'size': packet.stat().st_size,
                      'sha256': hashlib.sha256(packet.read_bytes()).hexdigest()}}
(out / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
observed_record = json.loads(observed.read_text()) if observed.exists() else {}
(out / 'README.md').write_text(
    f'Source {source} clean-image tier2 checkpoint.\n\n'
    f'Tier2 remains incomplete. The {len(cohorts)} completed groups report '
    f'{sum(x["counts"]["Passed"] for x in cohorts)} passed records and '
    f'{sum(x["counts"]["Failed"] for x in cohorts)} failures. Original statuses, '
    'commands, image fingerprints and failed JTRs remain intact. Finished JTRs and '
    'logs from active groups are snapshots only and do not certify those groups complete.\n\n'
    'The observed failure inventory is ' + json.dumps(observed_record.get('counts', {})) +
    '. Named failures are checked against their exact messages and control-image '
    'evidence. Cleaners native GSS controls additionally retain child stderr; the '
    'original parent-only JTR limitation is explicit in its analysis. This does '
    'not certify tier2 clean or classify later failures automatically.\n\n'
    'New batches use Make\'s automatic/ignore-quiet/failure-retention options. '
    'Preexisting commands/results remain intact; locks and exact-command/source '
    'checks prevent duplicate prelaunched groups. The bounded supervision self-test '
    'reaped one parent plus sixteen deliberately orphaned tee helpers, verified '
    'their outputs and left no new persistent zombie. PID1 was untouched.\n\n'
    'Final performance, original native ARM ZGC reproduction, and current-source '
    'native ARM/Windows builds/tests remain pending. No approval, source-readiness '
    'or speedup conclusion is made.\n')
print(json.dumps(record, indent=2))
