import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import time
import zipfile

p = argparse.ArgumentParser()
p.add_argument('label')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
out = pathlib.Path('/workspace/pr9-recovery') / a.label
out.mkdir(exist_ok=False)
state = json.loads((r / 'final-performance.json').read_text())
assert state['source'] == source
files = {}
snapshots = {}
warm_snapshots = []
def snapshot_bytes(path, validate_json=True):
    for attempt in range(3):
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        stable = (before.st_mtime_ns, before.st_size) == (after.st_mtime_ns, after.st_size)
        if stable:
            try:
                if validate_json and path.suffix == '.json': json.loads(data)
                return data
            except json.JSONDecodeError:
                pass
        time.sleep(0.05)
    raise RuntimeError('Concurrent write prevented a readable snapshot: ' + str(path))

for name in ['images.json', 'clean-release.json', 'clean-fastdebug.json',
             'tier2-assessment.json', 'pre-performance-evidence.json',
             'final-performance.json', 'final-library-preparation.json',
             'final-performance-analysis.json', 'cold_matrix.py', 'warm_matrix.py',
             'final_performance.py', 'summarize_warm.py', 'analyze_final_performance.py',
             'run_reaped.py', 'pack_final_performance.py', 'FirstBigInteger.java',
             'performance_environment.py', 'performance-environment-before.json',
             'performance-environment-after.json',
             'finish_local_qualification.py', 'local-continuation.json',
             'performance_status.py',
             'performance-boundary-review.json',
             'performance-startup-review.json', 'performance-cold-analysis.log',
             'performance-cold-analysis.log.result.json',
             'performance-confirmation-plan.json', 'performance-confirmations.json',
             'performance-confirmation-analysis.json',
             'run_performance_confirmations.py', 'performance-confirmations.log',
             'performance-confirmations.log.result.json',
             'snapshot_warm_tier.py',
             'confirm_warm_hash.py', 'performance-interruption.json',
             'stopped-main-warm-manifest.json',
             'performance-confirmation-plan-before-warm-signal.json',
             'performance-packaging-correction.json',
             'performance-stage-03-pack.log', 'performance-stage-03-pack.log.result.json',
             'FirstBigIntegerExact.java', 'CommonBigIntegerSquares.java',
             'build_square_benchmark.py', 'square-benchmark-provenance.json',
             'square-benchmark-build.log', 'square-benchmark-build.log.result.json',
             'square-benchmark-list.log', 'square-benchmark-list.log.result.json']:
    f = r / name
    if f.exists(): files[name] = f
phase_names = ['first-legacy', 'first-exact', 'first-boundaries', 'first-other',
               'startup', 'warm', 'warm-controls']
for phase in phase_names:
    for suffix in ['.log', '.log.result.json']:
        f = r / ('final-' + phase + suffix)
        if f.exists(): files[f.name] = f
for name in ['final-first-legacy.json', 'final-first-exact.json',
             'final-first-boundaries.json', 'final-first-other.json', 'final-startup.json',
             'final-confirm-boundary-c2.json', 'final-confirm-sha64-c1l1.json',
             'final-confirm-startup-c1l3.json']:
    f = r / name
    if f.exists(): files[name] = f
for pattern in ['local-continuation*.log', 'local-continuation*.log.result.json']:
    for f in r.glob(pattern): files[str(f.relative_to(r))] = f
for name in ['boundary-c2', 'sha64-c1l1', 'startup-c1l3', 'warm-hash-int']:
    for suffix in ['.log', '.log.result.json']:
        f = r / ('final-confirm-' + name + suffix)
        if f.exists(): files[f.name] = f
for folder in ['final-warm', 'final-warm-controls', 'final-confirm-warm-hash-int']:
    mp = r / folder / 'manifest.json'
    if not mp.exists(): continue
    name = str(mp.relative_to(r))
    snapshots[name] = snapshot_bytes(mp)
    files[name] = mp
    wm = json.loads(snapshots[name])
    assert wm['images']['final']['source'] == source
    # JMH creates its output file before the current invocation completes.
    # A frozen manifest identifies exactly the completed, owned result files.
    for invocation in wm['records']:
        for suffix in ['.json', '.log']:
            f = r / folder / (invocation['name'] + suffix)
            if not f.exists():
                assert invocation['exit_code'] != 0, str(f)
                continue
            name = str(f.relative_to(r))
            body = snapshot_bytes(f, validate_json=invocation['exit_code'] == 0)
            if suffix == '.json' and invocation['exit_code'] == 0:
                assert hashlib.sha256(body).hexdigest() == invocation['result_sha256']
            snapshots[name] = body
            files[name] = f
    summary = r / folder / 'summary.json'
    if summary.exists(): files[str(summary.relative_to(r))] = summary
    warm_snapshots.append({'folder': folder, 'completed_invocations': len(wm['records']),
                           'parameter_forks': sum(len(x.get('results', [])) for x in wm['records']),
                           'failed_invocations': sum(x['exit_code'] != 0 for x in wm['records'])})
for f in (r / 'jmh').glob('*.jar'):
    files[str(f.relative_to(r))] = f
for tier in ['int', 'c1-l1', 'c1-l3', 'c2']:
    for f in (r / ('warm-tier-' + tier)).glob('*.json'):
        files[str(f.relative_to(r))] = f
for f in (r / 'jmh/classes').glob('First*.class'):
    files[str(f.relative_to(r))] = f
for name in ['FirstUse.java', 'CommonBigIntegerCalls.java', 'CommonSmallIntrinsics.java']:
    files['fixture-sources/' + name] = pathlib.Path('/workspace/pr9-evidence/replacement-x64') / name
micro = repo / 'test/micro/org/openjdk/bench/vm/compiler/CommonIntrinsics.java'
files['fixture-sources/CommonIntrinsics.java'] = micro
manifest = []
with zipfile.ZipFile(out / 'performance.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name, f in sorted(files.items()):
        data = snapshots[name] if name in snapshots else snapshot_bytes(f)
        z.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'performance.zip') as z:
    assert z.testzip() is None
packet = out / 'performance.zip'
record = {'source': source, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': state['status'], 'phases': state['phases'], 'file_count': len(manifest),
          'warm_snapshots': warm_snapshots,
          'archive': {'name': packet.name, 'bytes': packet.stat().st_size,
                      'sha256': hashlib.sha256(packet.read_bytes()).hexdigest()},
          'scope': 'Linux x64 measurements. Phase completion is not regression review or PR approval.'}
(out / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
(out / 'README.md').write_text(
    f'Linux x64 performance checkpoint for implementation {source}.\n\n'
    'Raw commands, paired fresh-JVM observations, JMH fresh-fork results, image '
    'fingerprints, fixture sources/bytecode and all classpath JARs are retained '
    'with a per-file SHA256 manifest. Original measurement files remain intact. '
    'Incomplete phases are partial evidence only.\n\n'
    'First-call cases use fresh JVMs with a warm operating-system file cache; '
    'call time and whole-process wall time are separate. Legacy BigInteger inputs '
    'have nominal sizes whose actual bit length is seven bits smaller; the exact '
    'fixture supplies full-size operands. Startup retains wall and CreateVM time. '
    'Paired Student-t 95% intervals are reported; JMH iterations are not treated '
    'as independent forks. Positive intervals remain explicit review signals.\n\n'
    'This packet does not qualify native ARM CDS/performance, Windows or AVX-512 '
    'on Windows, or certify clean tier2. The pre-performance checkpoint and '
    'assessment retain the local test limitations. No speedup or readiness '
    'conclusion follows merely from completing a measurement phase.\n')
print(json.dumps(record, indent=2))
