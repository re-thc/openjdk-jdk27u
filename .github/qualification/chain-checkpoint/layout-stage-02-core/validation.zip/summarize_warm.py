import argparse,collections,json,math,os,pathlib,statistics
os.environ['OPENBLAS_NUM_THREADS']='1'
from scipy.stats import t
p=argparse.ArgumentParser();p.add_argument('folder');a=p.parse_args();r=pathlib.Path(a.folder);d=json.loads((r/'manifest.json').read_text());groups=collections.defaultdict(dict)
for record in d['records']:
 if record['exit_code']:continue
 for result in record['results']:
  assert result['primaryMetric']['scoreUnit']=='ns/op'
  key=(record['tier'],result['benchmark'],tuple(sorted(result.get('params',{}).items())))
  groups[key][(record['label'],record['pair'])]=result['primaryMetric']['score']
def ci(values):
 n=len(values);m=statistics.mean(values);h=float(t.ppf(.975,n-1))*statistics.stdev(values)/math.sqrt(n);return [m-h,m+h]
rows=[]
for (tier,benchmark,params),samples in sorted(groups.items()):
 labels=sorted({k[0] for k in samples});means={label:statistics.mean(v for (l,pair),v in samples.items() if l==label) for label in labels};comparisons={}
 for left,right in [('master','final-on'),('before-on','final-on'),('final-off','final-on'),('master','final-off')]:
  pairs=sorted({p for l,p in samples if l==left}&{p for l,p in samples if l==right})
  if len(pairs)<2:continue
  delta=[samples[(right,p)]-samples[(left,p)] for p in pairs];logs=[math.log(samples[(left,p)]/samples[(right,p)]) for p in pairs];ratio_ci=list(map(math.exp,ci(logs)))
  comparisons[left+'_'+right]={'pairs':len(pairs),'difference_ns':statistics.mean(delta),'paired_95_ci_ns':ci(delta),'geometric_speedup':math.exp(statistics.mean(logs)),'speedup_95_ci':ratio_ci}
 rows.append({'tier':tier,'benchmark':benchmark,'parameters':dict(params),'means_ns':means,'comparisons':comparisons})
(r/'summary.json').write_text(json.dumps({'method':'Paired Student t 95% on fresh-fork block means; speedup intervals use paired log ratios. JMH iterations are not treated as independent forks.','results':rows},indent=2)+'\n');print('summarized',len(rows),'workloads')
