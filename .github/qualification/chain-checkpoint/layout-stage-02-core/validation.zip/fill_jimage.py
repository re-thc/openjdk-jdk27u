import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-layout-validation')
rows = []
for kind in ['release', 'fastdebug']:
    name = f'clean-{kind}-tier2-jimage-ready'
    image = '/workspace/openjdk-jdk27u/build/pr9-' + kind + '/images/jdk'
    command = ['python3', str(r / 'jtreg_batch.py'), name, image,
               '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
               '--nativepath=/workspace/openjdk-jdk27u/build/pr9-' + kind + '/images/test/jdk/jtreg/native',
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42',
               'test/jdk/tools/jimage/VerifyJimage.java#compare']
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    rows.append({'name': name, 'exit_code': code, 'command': command,
                 'image_alias': 'Core fingerprints verified equal to frozen clean image'})
    (r / 'tier2-jimage-fill.json').write_text(json.dumps(rows, indent=2) + '\n')
