import argparse
import json
import pathlib
import subprocess

p = argparse.ArgumentParser()
p.add_argument('kind', choices=['release', 'fastdebug'])
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
original = r / f'clean-{a.kind}-tier2-jdk-security.result.json'
assert original.exists(), 'Wait for the original security group to finish'
image = r / f'images/clean-{a.kind}'
external = r / 'external-data'
openssl = external / 'openssl/install/bin/openssl'
assert openssl.exists()
version = subprocess.check_output([str(openssl), 'version'], text=True).strip()
assert version.startswith('OpenSSL 3.5.4 '), version
list_file = r / f'{a.kind}-compatibility-jdks.txt'
list_file.write_text(str(image) + '\n/workspace/toolchains/jdk27\n')
tests = []
inputs = []
for jtr in sorted((r / f'clean-{a.kind}-tier2-jdk-security-work').rglob('*.jtr')):
    text = jtr.read_text(errors='replace')
    status = next((x for x in text.splitlines() if x.startswith('execStatus=')), '')
    keywords = next((x.split('=', 1)[1].split() for x in text.splitlines() if x.startswith('keywords=')), [])
    if 'manual' in keywords:
        continue
    if not status.startswith('execStatus=Passed. Skipped'):
        continue
    if not any(x in status for x in ['No JDKs to test', 'Could not find openssl',
                                     'Cannot find kyber-certificates', 'Cannot find cms-ml-dsa',
                                     'ACVP-Server not available']):
        continue
    description = next(x.split('=', 1)[1] for x in text.splitlines() if x.startswith('description='))
    description = description.replace('\\:', ':').replace('\\#', '#')
    test = description.removeprefix('file:/workspace/openjdk-jdk27u/')
    assert test.startswith('test/jdk/')
    tests.append(test)
    inputs.append({'original': str(jtr.relative_to(r)), 'test': test, 'reason': status})
assert tests
options = ('-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
           '-Djdk.test.lib.random.seed=42 -Dseed=42 '
           '-Dtest.jdk.list.file=' + str(list_file) +
           ' -Dtest.openssl.path=' + str(openssl) +
           ' -Djdk.tests.repos.pattern=' + external.as_uri() + '/%o/%n/%e' +
           ' -Djdk.test.lib.artifacts.ACVP-Server=' + str(external / 'ACVP-Server-1.1.0.38.zip'))
name = f'clean-{a.kind}-tier2-security-data-ready'
command = ['python3', str(r / 'jtreg_batch.py'), name, str(image),
           '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
           '--nativepath=/workspace/openjdk-jdk27u/build/pr9-' + a.kind + '/images/test/jdk/jtreg/native',
           '--vmoptions=' + options, *tests]
receipt = {'source': 'e41d7823bf6de77c4bfba52e896bf325221488cb',
           'inputs': inputs, 'openssl_version': version, 'command': command}
(r / f'tier2-{a.kind}-security-data-fill.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode)
