import hashlib
import json
import pathlib
import shutil
import stat
import subprocess

r = pathlib.Path('/workspace/pr9-layout-validation')
repo = pathlib.Path('/workspace/openjdk-jdk27u')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == source
q = subprocess.run(['ps', '-C', 'make,gmake,cc1plus,gcc,g++', '-o', 'pid='], capture_output=True, text=True)
assert not q.stdout.strip(), 'A build is active'
objects = repo / 'build/pr9-fastdebug/hotspot/variant-server/libjvm/objs'
assert objects.is_dir() and not objects.is_symlink()
assert objects.resolve() == objects
files = sorted(objects.glob('*.o'))
assert files and all(stat.S_ISREG(f.lstat().st_mode) for f in files)
def verify_images():
    rows = []
    for kind in ['release', 'fastdebug']:
        d = json.loads((r / f'clean-{kind}.json').read_text())
        assert d['source'] == source and d['status'] == 'passed'
        for name, expected in d['fingerprints'].items():
            f = pathlib.Path(d['path']) / name
            h = hashlib.sha256()
            with f.open('rb') as inp:
                for block in iter(lambda: inp.read(8 * 1024 * 1024), b''): h.update(block)
            assert h.hexdigest() == expected['sha256'], (kind, name)
            rows.append({'image': kind, 'file': name, 'sha256': h.hexdigest()})
    return rows
record = {'source': source, 'reason': 'Reclaim only owned completed fastdebug native objects for current-source qualification capacity',
          'free_before': shutil.disk_usage('/workspace').free,
          'image_hashes_before': verify_images(), 'status': 'prepared',
          'objects': [{'path': str(f.relative_to(repo)), 'bytes': f.stat().st_size} for f in files]}
p = r / 'fastdebug-object-reclaim.json'
p.write_text(json.dumps(record, indent=2) + '\n')
for f in files: f.unlink()
record.update(status='completed', deleted_count=len(files),
              deleted_bytes=sum(x['bytes'] for x in record['objects']),
              free_after=shutil.disk_usage('/workspace').free, image_hashes_after=verify_images())
assert record['image_hashes_before'] == record['image_hashes_after']
p.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['status', 'deleted_count', 'deleted_bytes', 'free_before', 'free_after']}))
