import argparse,json,pathlib,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--images',nargs='+',default=['clean-release','clean-fastdebug']);p.add_argument('--output',default='cold-gc-probe');a=p.parse_args();r=pathlib.Path('/workspace/pr9-layout-validation');out=r/a.output;out.mkdir(exist_ok=True)
records=[];tiers=[('int',['-Xint']),('c1-l1',['-Xbatch','-XX:TieredStopAtLevel=1']),('c1-l3',['-Xbatch','-XX:TieredStopAtLevel=3']),('c2',['-Xbatch','-XX:-TieredCompilation'])]
images={name:json.loads((r/(name+'.json')).read_text()) for name in a.images}
assert all(v['status']=='passed' for v in images.values())
for image in a.images:
 for gc in ['Serial','G1','Z','Parallel','Shenandoah']:
  for tier,mode in tiers:
   for compressed in [True,False]:
    name=f'{image}-{gc}-{tier}-oops-{compressed}'
    opts=['-XX:ActiveProcessorCount=2','-XX:CICompilerCount=2','-Xms16m','-Xmx128m','-XX:+UnlockExperimentalVMOptions','-XX:+UnlockDiagnosticVMOptions','-XX:+Use'+gc+'GC','-XX:'+('+' if compressed else '-')+'UseCompressedOops','-XX:-DisableExplicitGC','-XX:+UseCommonIntrinsics','-Xlog:gc,startuptime',*mode]
    if image.endswith('fastdebug'):opts+=['-XX:+CheckUnhandledOops','-XX:+VerifyOops']
    command=[str(r/'images'/image/'bin/java'),*opts,'-cp',str(r/'jmh/classes'),'ColdBigIntegerGC'];
    try:q=subprocess.run(command,capture_output=True,text=True,timeout=120)
    except subprocess.TimeoutExpired as e:
     from types import SimpleNamespace
     def decode(v):return v.decode(errors='replace') if isinstance(v,bytes) else (v or '')
     q=SimpleNamespace(returncode=124,stdout=decode(e.stdout),stderr=decode(e.stderr)+'\nTIMEOUT')
    text=q.stdout+q.stderr;(out/(name+'.log')).write_text(text)
    collections=len(set(re.findall(r'GC\((\d+)\)',text)));passed=q.returncode==0 and re.search(r'^PASS -?\d+$',text,re.M) is not None and collections>0
    records.append({'name':name,'command':command,'exit_code':q.returncode,'gc_cycles':collections,'passed':passed,'compiler_stub_generations':text.count('StubRoutines generation compiler stubs')});(out/'manifest.json').write_text(json.dumps({'images':{n:{'source':v['source'],'fingerprints':v['fingerprints']} for n,v in images.items()},'records':records},indent=2)+'\n')
    if not passed:raise SystemExit(name+' failed')
  print(image,gc,'passed',flush=True)
