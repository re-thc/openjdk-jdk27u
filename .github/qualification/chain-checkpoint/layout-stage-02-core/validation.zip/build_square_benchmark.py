import hashlib
import json
import pathlib
import subprocess
import time

r = pathlib.Path('/workspace/pr9-validation')
jmh = r / 'jmh'
java = pathlib.Path('/workspace/toolchains/jdk27/bin')
source = r / 'CommonBigIntegerSquares.java'
target = jmh / 'squares'
target.mkdir(exist_ok=False)
(target / 'classes').mkdir()
(target / 'generated').mkdir()
original = jmh / 'benchmarks.jar'
original_sha = hashlib.sha256(original.read_bytes()).hexdigest()
commands = [
    [str(java / 'javac'), '-cp', str(jmh / 'jmh-core.jar'),
     '-processorpath', str(jmh / 'jmh-core.jar') + ':' + str(jmh / 'jmh-generator-annprocess.jar'),
     '-d', str(target / 'classes'), '-s', str(target / 'generated'), str(source)],
    [str(java / 'jar'), '--create', '--file', str(jmh / 'square-benchmarks.jar'),
     '-C', str(target / 'classes'), '.'],
]
records = []
for command in commands:
    started = time.time()
    subprocess.run(command, check=True)
    records.append({'command': command, 'seconds': time.time() - started, 'exit_code': 0})
assert hashlib.sha256(original.read_bytes()).hexdigest() == original_sha
manifest = {'commands': records, 'original_benchmarks_jar_unchanged_sha256': original_sha,
            'files': []}
for f in [source, jmh / 'square-benchmarks.jar', jmh / 'jmh-core.jar', jmh / 'jmh-generator-annprocess.jar']:
    manifest['files'].append({'path': str(f), 'size': f.stat().st_size,
                              'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
(r / 'square-benchmark-provenance.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
