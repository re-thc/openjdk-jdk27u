"""Review a completed tier without modifying the active JMH manifest."""
import argparse
import hashlib
import json
import math
import pathlib
import subprocess

p = argparse.ArgumentParser()
p.add_argument('tier', choices=['int', 'c1-l1', 'c1-l3', 'c2'])
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
manifest_bytes = (r / 'final-warm/manifest.json').read_bytes()
d = json.loads(manifest_bytes)
assert d['images']['final']['source'] == source and d['pairs'] == 4
records = [x for x in d['records'] if x['tier'] == a.tier]
assert len(records) == 144 and sum(len(x['results']) for x in records) == 240
groups = {}
for record in records:
    assert record['exit_code'] == 0
    raw = r / 'final-warm' / (record['name'] + '.json')
    body = raw.read_bytes()
    assert hashlib.sha256(body).hexdigest() == record['result_sha256']
    assert json.loads(body) == record['results']
    for result in record['results']:
        metric = result['primaryMetric']
        assert metric['scoreUnit'] == 'ns/op' and math.isfinite(metric['score']) and metric['score'] > 0
        key = (result['benchmark'], tuple(sorted(result.get('params', {}).items())))
        sample = (record['label'], record['pair'])
        assert sample not in groups.setdefault(key, set())
        groups[key].add(sample)
expected = {(label, pair) for label in ['master', 'before-on', 'final-off', 'final-on']
            for pair in range(4)}
assert len(groups) == 15 and all(samples == expected for samples in groups.values())
out = r / ('warm-tier-' + a.tier)
out.mkdir(exist_ok=False)
d['records'] = records
d['scope'] = 'Completed ' + a.tier + ' tier only; the overall warm matrix remains in progress.'
(out / 'manifest.json').write_text(json.dumps(d, indent=2) + '\n')
(out / 'provenance.json').write_text(json.dumps({
    'source': source, 'tier': a.tier, 'source_manifest': 'final-warm/manifest.json',
    'source_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'completed_invocations': len(records), 'parameter_forks': 240,
    'scope': d['scope']}, indent=2) + '\n')
subprocess.run(['python3', str(r / 'summarize_warm.py'), str(out)], check=True)
summary = json.loads((out / 'summary.json').read_text())
signals = []
for result in summary['results']:
    value = result['comparisons']['before-on_final-on']
    if value['paired_95_ci_ns'][0] > 0:
        signals.append({'benchmark': result['benchmark'], 'parameters': result['parameters'],
                        'comparison': value})
print(json.dumps({'tier': a.tier, 'workloads': len(summary['results']),
                  'slower_beforeon_finalon': signals}, indent=2))
