"""Retain every final comparison and surface regression signals for review."""
import hashlib
import json
import math
import pathlib
import statistics

r = pathlib.Path('/workspace/pr9-layout-validation')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
expected = {'final-first-legacy.json': 36, 'final-first-exact.json': 24,
            'final-first-boundaries.json': 20, 'final-first-other.json': 12,
            'final-startup.json': 4}
rows, inputs, missing = [], [], []
for name, cases in expected.items():
    f = r / name
    if not f.exists():
        missing.append(name)
        continue
    d = json.loads(f.read_text())
    assert d['images']['final']['source'] == source
    assert len(d['results']) == cases
    for key, result in d['results'].items():
        assert result['status'] == 'passed'
        assert len(result['raw']) == 5 * (d['blocks'] + d['discarded_blocks'])
        assert all(x['exit_code'] == 0 for x in result['raw'])
        for metric, summary in result['summary'].items():
            for comparison, value in summary['comparisons'].items():
                lower, upper = value['paired_95_ci_ms']
                rows.append({'input': name, 'case': key, 'metric': metric,
                             'comparison': comparison, 'difference': value['difference_ms'],
                             'unit': 'ms', 'paired_95_ci': [lower, upper],
                             'pairs': value['samples'],
                             'signal': 'slower' if lower > 0 else 'faster' if upper < 0 else 'unresolved'})
    inputs.append({'path': name, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
for folder, forks in [('final-warm', 576), ('final-warm-controls', 64)]:
    f = r / folder / 'summary.json'
    if not f.exists():
        missing.append(str(f.relative_to(r)))
        continue
    manifest_path = f.parent / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['images']['final']['source'] == source
    assert len(manifest['records']) == forks
    for record in manifest['records']:
        assert record['exit_code'] == 0
        raw = f.parent / (record['name'] + '.json')
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == record['result_sha256']
        for result in record['results']:
            assert math.isfinite(result['primaryMetric']['score']) and result['primaryMetric']['score'] > 0
    for result in json.loads(f.read_text())['results']:
        for comparison, value in result['comparisons'].items():
            lower, upper = value['paired_95_ci_ns']
            rows.append({'input': str(f.relative_to(r)), 'case': result['tier'] + '-' + result['benchmark'],
                         'parameters': result['parameters'], 'metric': 'ns/op',
                         'comparison': comparison, 'difference': value['difference_ns'],
                         'unit': 'ns', 'paired_95_ci': [lower, upper], 'pairs': value['pairs'],
                         'geometric_speedup': value['geometric_speedup'],
                         'speedup_95_ci': value['speedup_95_ci'],
                         'signal': 'slower' if lower > 0 else 'faster' if upper < 0 else 'unresolved'})
    for path in [f, manifest_path]:
        inputs.append({'path': str(path.relative_to(r)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
signals = [x for x in rows if x['signal'] == 'slower']
record = {'source': source, 'status': 'incomplete' if missing else 'complete-awaiting-signal-review',
          'missing': missing, 'inputs': inputs, 'comparisons': rows, 'slower_95_signals': signals,
          'interpretation': 'Positive paired 95% intervals are review signals, not automatic attribution. '
                            'Inspect flags, off-controls, call and whole-process metrics, source identities, '
                            'and multiplicity. Any confirmation must target a newly unresolved concern; '
                            'do not repeat completed measurements merely for review. No native ARM or '
                            'Windows performance conclusion follows from Linux x64 results.'}
(r / 'final-performance-analysis.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'missing': missing,
                  'comparison_count': len(rows), 'slower_95_signals': signals}, indent=2))
