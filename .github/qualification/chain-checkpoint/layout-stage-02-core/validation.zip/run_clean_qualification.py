import argparse,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('kind',choices=['release','fastdebug']);a=p.parse_args()
r=pathlib.Path('/workspace/pr9-layout-validation');build=json.loads((r/('clean-'+a.kind+'.json')).read_text());assert build['status']=='passed'
image=build['path'];assert 'e41d7823bf6' in (pathlib.Path(image)/'release').read_text()
oldnames=(['safety-release-common','safety-release-archives','safety-release-jdk','safety-release-hotspot','safety-release-aot','safety-release-flagless','final-release-c1-math-l1','final-release-c1-math-l3'] if a.kind=='release' else ['safety-fastdebug-common-ready','safety-fastdebug-archives','safety-fastdebug-aot','safety-fastdebug-flagless','safety-related-redefine'])
results=[]
for old in oldnames:
 d=json.loads((r/'templates'/(old+'.result.json')).read_text());cmd=d['command'];tests=cmd[next(i for i,x in enumerate(cmd) if x.startswith('test/')):];opts=next(x.split(':',1)[1] for x in cmd if x.startswith('-vmoptions:'));name=('clean-'+old.split('-',1)[1]).replace('-ready','')
 command=['python3',str(r/'jtreg_batch.py'),name,image,'--vmoptions='+opts,'--nativepath=/workspace/openjdk-jdk27u/build/pr9-'+a.kind+'/images/test/hotspot/jtreg/native',*tests]
 code=subprocess.run(command).returncode;results.append({'name':name,'exit_code':code});(r/('clean-'+a.kind+'-qualification.json')).write_text(json.dumps({'source':build['source'],'image_fingerprints':build['fingerprints'],'cohorts':results},indent=2)+'\n')
 # Preserve a failing cohort and continue the independent selections.
print(json.dumps(results),flush=True)
raise SystemExit(1 if any(x['exit_code'] for x in results) else 0)
