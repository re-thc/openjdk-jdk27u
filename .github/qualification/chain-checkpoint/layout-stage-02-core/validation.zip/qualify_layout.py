"""Qualify only the new clean images; previous receipts are command templates."""
import concurrent.futures
import hashlib
import json
import pathlib
import re
import subprocess
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
old = pathlib.Path('/workspace/pr9-validation')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
state = {'source': source, 'status': 'waiting-for-clean-builds', 'steps': []}
path = r / 'layout-qualification.json'
assert not path.exists()

def save():
    path.write_text(json.dumps(state, indent=2) + '\n')

def run(name, arguments):
    command = ['python3', str(r/'run_reaped.py'), str(r/(name+'-wrapper.log')), *arguments]
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    row = {'name': name, 'command': command, 'exit_code': code}
    return row

def group(label, commands):
    state['status'] = label
    save()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(lambda item: run(*item), commands))
    state['steps'].extend(rows)
    save()
    assert all(x['exit_code'] == 0 for x in rows), rows

try:
    save()
    while True:
        builds = {kind: json.loads((old/('layout-'+kind+'.json')).read_text())
                  for kind in ['release', 'fastdebug']}
        assert all(x['source'] == source and x['status'] != 'failed' for x in builds.values())
        if all(x['status'] == 'passed' for x in builds.values()):
            break
        time.sleep(10)
    for kind, build in builds.items():
        image = pathlib.Path(build['path'])
        for name, fp in build['fingerprints'].items():
            assert hashlib.sha256((image/name).read_bytes()).hexdigest() == fp['sha256']
        (r/('clean-'+kind+'.json')).write_text(json.dumps(build, indent=2)+'\n')
        (r/'images'/('clean-'+kind)).symlink_to(image, target_is_directory=True)
    images = json.loads((old/'images.json').read_text())
    release = builds['release']
    images['final'] = {k: release[k] for k in ['path', 'source', 'fingerprints']}
    images['final']['clean_build'] = True
    (r/'images.json').write_text(json.dumps(images, indent=2)+'\n')
    group('focused-jtreg', [(kind+'-focused', ['python3',str(r/'run_clean_qualification.py'),kind])
                            for kind in builds])
    group('functional-flags-gc', [(kind+'-flags', ['python3',str(r/'gc_flags_probe.py'),
           '--images','clean-'+kind,'--output',kind+'-gc-flags.json']) for kind in builds])
    group('concurrent-cold-gc', [(kind+'-cold-gc', ['python3',str(r/'cold_gc_probe.py'),
           '--images','clean-'+kind,'--output',kind+'-cold-gc']) for kind in builds])
    group('native-gtests', [('fastdebug-gtests',[
        '/workspace/openjdk-jdk27u/build/pr9-fastdebug/images/test/hotspot/gtest/server/gtestLauncher',
        '-jdk:'+builds['fastdebug']['path'],'-XX:ActiveProcessorCount=2','-XX:CICompilerCount=2',
        '-Xmx512m','--gtest_output=xml:'+str(r/'fastdebug-gtests.xml')])])
    group('interpreter-layout', [('interpreter-layout', ['python3',
          str(r/'diagnose_interpreter_layout.py'),'--output','layout-after-diagnostic'])])
    diagnostic = json.loads((r/'layout-after-diagnostic/layout.json').read_text())
    assert not diagnostic['changed_final_on_off_bytecodes'], 'Ordinary handlers still move'
    state['status'] = 'core-qualification-passed-ready-for-quiet-warm-tier'
    save()
except BaseException as error:
    state['status'] = 'blocked-for-review'
    state['error'] = repr(error)
    save()
    raise
