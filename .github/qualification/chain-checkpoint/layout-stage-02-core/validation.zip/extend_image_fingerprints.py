"""Fingerprint all new archive variants before the benchmark reads its images."""
import hashlib
import json
import os
import pathlib
import time

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
os.sched_setaffinity(0,{max(os.sched_getaffinity(0))})
while not (r/'images.json').exists():
    state=json.loads((r/'layout-qualification.json').read_text())
    assert state['status']!='blocked-for-review'
    time.sleep(5)
for kind in ['release','fastdebug']:
    build=json.loads((r/('clean-'+kind+'.json')).read_text())
    assert build['source']==source and build['status']=='passed'
    image=pathlib.Path(build['path'])
    paths=[image/'release',image/'bin/java',*sorted((image/'lib/server').glob('*.jsa'))]
    extra={'source':source,'path':str(image),'fingerprints':{
        str(p.relative_to(image)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in paths}}
    record=r/(kind+'-extra-image-fingerprints.json')
    if record.exists():assert json.loads(record.read_text())==extra
    else:record.write_text(json.dumps(extra,indent=2)+'\n')
    if kind=='release':
        images=json.loads((r/'images.json').read_text())
        assert images['final']['source']==source
        images['final']['fingerprints'].update(extra['fingerprints'])
        temporary=r/'images.extended.tmp';temporary.write_text(json.dumps(images,indent=2)+'\n')
        temporary.replace(r/'images.json')
print('New image launchers, metadata and every CDS archive variant fingerprinted.',flush=True)
