"""Run official tier2 groups against new images with the prepared test inputs."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import time

p=argparse.ArgumentParser()
p.add_argument('kind',choices=['release','fastdebug'])
p.add_argument('--only')
a=p.parse_args()
r=pathlib.Path('/workspace/pr9-layout-validation')
repo=pathlib.Path('/workspace/openjdk-jdk27u')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
build=json.loads((r/('clean-'+a.kind+'.json')).read_text())
assert build['status']=='passed' and build['source']==source
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==source
native=repo/'build'/('pr9-'+a.kind)/'images/test'
nativepaths={'hotspot/jtreg':native/'hotspot/jtreg/native','jdk':native/'jdk/jtreg/native'}
assert all(x.is_dir() for x in nativepaths.values())
cases=[('hotspot-runtime','hotspot/jtreg','hotspot_tier2_runtime'),
       ('hotspot-resolution','hotspot/jtreg','hotspot_tier2_runtime_platform_agnostic'),
       ('hotspot-serviceability','hotspot/jtreg','hotspot_tier2_serviceability'),
       ('hotspot-compiler','hotspot/jtreg','tier2_compiler'),
       ('hotspot-ctw','hotspot/jtreg','tier2_ctw'),
       ('hotspot-shenandoah','hotspot/jtreg','tier2_gc_shenandoah'),
       ('jdk-security','jdk','tier2_part1'),('jdk-io-tools-time','jdk','tier2_part2'),
       ('jdk-net','jdk','tier2_part3'),('langtools','langtools','tier2'),('jaxp','jaxp','tier2')]
if a.only:
    assert a.only in [c[0] for c in cases]
    cases=[c for c in cases if c[0]==a.only]
record={'source':source,'image':build['path'],'fingerprints':build['fingerprints'],
        'scope':cases,'concurrency':1,'cohorts':[],'status':'running',
        'empty_group':'hotspot tier2_gc_epsilon is empty in TEST.groups',
        'prepared_inputs':'Pinned NSS/OpenSSL/PQC/ACVP dependencies retained from the previous run; '
                          'all test outcomes here are new executions against e41d.'}
path=r/('tier2-'+a.kind+('-prefetch-'+a.only if a.only else '')+'.json')
def save():path.write_text(json.dumps(record,indent=2)+'\n')
save()
for label,suite,group in cases:
    name='clean-'+a.kind+'-tier2-'+label
    problem=repo/'test'/suite/'ProblemList.txt'
    if not problem.exists():problem=r/'empty-problem-list.txt';problem.write_text('')
    image=build['path']
    # VerifyJimage locates exploded modules through the build image directory.
    if label=='jdk-io-tools-time':
        image=str(repo/'build'/('pr9-'+a.kind)/'images/jdk')
        for file,fp in build['fingerprints'].items():
            assert hashlib.sha256((pathlib.Path(image)/file).read_bytes()).hexdigest()==fp['sha256']
    options='-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g -Djdk.test.lib.random.seed=42 -Dseed=42'
    environment=[]
    if label=='jdk-security':
        nss=json.loads((r/'nss-3.117/qualification-provenance.json').read_text())
        external=r/'external-data'
        jdks=r/(a.kind+'-compatibility-jdks.txt');jdks.write_text(image+'\n/workspace/toolchains/jdk27\n')
        options+=(' -Djdk.test.lib.artifacts.nsslib-linux_x64='+nss['libdir']+
                  ' -Dtest.jdk.list.file='+str(jdks)+
                  ' -Dtest.openssl.path='+str(external/'openssl/install/bin/openssl')+
                  ' -Djdk.tests.repos.pattern='+external.as_uri()+'/%o/%n/%e'+
                  ' -Djdk.test.lib.artifacts.ACVP-Server='+str(external/'ACVP-Server-1.1.0.38.zip'))
        environment=['--environment=LD_LIBRARY_PATH='+nss['libdir']]
    command=['python3',str(r/'jtreg_batch.py'),name,image,'--concurrency=1',
             '--exclude='+str(problem),'--nativepath='+str(nativepaths.get(suite,nativepaths['hotspot/jtreg'])),
             *environment,'--vmoptions='+options,'test/'+suite+':'+group]
    start=time.time();code=subprocess.run(command,cwd=repo).returncode
    record['cohorts'].append({'name':name,'exit_code':code,'seconds':time.time()-start,'command':command})
    save()
record['status']='passed' if all(x['exit_code']==0 for x in record['cohorts']) else 'has-failures'
save()
raise SystemExit(0 if record['status']=='passed' else 1)
