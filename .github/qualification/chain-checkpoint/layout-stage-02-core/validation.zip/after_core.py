"""Run the prospectively selected first warm tier after all core workers stop."""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import time

r = pathlib.Path('/workspace/pr9-layout-validation')
source = 'e41d7823bf6de77c4bfba52e896bf325221488cb'
path = r/'early-warm-state.json'
assert not path.exists()
state = {'source': source, 'status': 'waiting-for-core-qualification', 'steps': [],
         'scope': 'First interpreter tier of the final matrix, measured before new tier2. '
                  'Completed command/hash-matched forks may be reused by the final matrix. '
                  'This is not complete performance or tier2 qualification.'}
def save(): path.write_text(json.dumps(state, indent=2)+'\n')
def run(name, arguments):
    state['status'] = name; save()
    command = ['python3',str(r/'run_reaped.py'),str(r/(name+'-wrapper.log')),*arguments]
    code = subprocess.run(command,cwd='/workspace/openjdk-jdk27u').returncode
    state['steps'].append({'name':name,'command':command,'exit_code':code});save()
    assert code == 0, (name,code)
try:
    save()
    while True:
        core = json.loads((r/'layout-qualification.json').read_text())
        assert core['source'] == source and core['status'] != 'blocked-for-review'
        if core['status'] == 'core-qualification-passed-ready-for-quiet-warm-tier':break
        time.sleep(10)
    # Record/replay only current images. Prior records provide exact command templates.
    out = r/'dynamic-big-probe';out.mkdir()
    templates = json.loads(pathlib.Path('/workspace/pr9-validation/dynamic-big-probe/manifest.json').read_text())
    records = []
    for template in templates:
        command = [s.replace('/workspace/pr9-validation',str(r)) for s in template['command']]
        log = out/(template['tier']+'-'+template['op']+'-'+template['phase']+'.log')
        q = subprocess.run(command,capture_output=True,text=True)
        text = q.stdout+q.stderr;log.write_text(text)
        generations = [i for i,s in enumerate(text.splitlines()) if 'StubRoutines generation compiler stubs' in s]
        vm_end = next(i for i,s in enumerate(text.splitlines()) if '] Create VM,' in s)
        result = re.findall(r'^([0-9]+ -?[0-9]+)$',text,re.M)
        passed = q.returncode == 0 and len(generations) == 1 and generations[0] > vm_end and len(result) == 1
        records.append({'source':source,'tier':template['tier'],'op':template['op'],
                        'phase':template['phase'],'command':command,'exit_code':q.returncode,
                        'generations':len(generations),'generation_before_create_vm_end':
                        any(i < vm_end for i in generations),'result':result,'passed':passed,
                        'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
        (out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
        assert passed, records[-1]
    for tier in ['int','c1-l1']:
        for op in ['multiply','modpow']:
            values=[int(x['result'][0].split()[1]) for x in records if x['tier']==tier and x['op']==op]
            assert len(values)==2 and values[0]==values[1]
    for attempt in range(12):
        q=subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True)
        if not q.stdout.strip():break
        time.sleep(5)
    else:raise RuntimeError('Other VM/build workers still active')
    from performance_environment import snapshot
    state['environment_before']=snapshot('early-int-before');save()
    images=json.loads((r/'images.json').read_text());original=os.sched_getaffinity(0)
    os.sched_setaffinity(0,{min(original)});prep=[]
    for name,entry in images.items():
        image=pathlib.Path(entry['path'])
        for f,fp in entry['fingerprints'].items():
            assert hashlib.sha256((image/f).read_bytes()).hexdigest()==fp['sha256']
        library=image/'lib/server/libjvm.so';data=library.read_bytes()
        with library.open('r+b') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        assert hashlib.sha256(library.read_bytes()).hexdigest()==entry['fingerprints']['lib/server/libjvm.so']['sha256']
        prep.append({'image':name,'sha256':hashlib.sha256(data).hexdigest(),'rewritten_unchanged':True})
    os.sched_setaffinity(0,original)
    (r/'early-library-preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
    run('early-int-warm',['python3',str(r/'warm_matrix.py'),'--pairs','4','--tier','int','--output','final-warm'])
    run('early-int-review',['python3',str(r/'snapshot_warm_tier.py'),'int'])
    state['environment_after']=snapshot('early-int-after')
    state['status']='first-interpreter-tier-complete-awaiting-review';save()
except BaseException as error:
    state['status']='blocked-for-review';state['error']=repr(error);save();raise
