import argparse
import hashlib
import json
import pathlib
import re
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--images', default='images.json')
p.add_argument('--output', default='layout-before-diagnostic')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-layout-validation')
images = json.loads((r / a.images).read_text())
assert not subprocess.run(['ps', '-C', 'java', '-o', 'pid='], capture_output=True, text=True).stdout.strip()
out = r / a.output
out.mkdir(exist_ok=False)
flags = ['-Xint', '-Xshare:off', '-XX:ActiveProcessorCount=1', '-XX:CICompilerCount=2',
         '-XX:+UseSerialGC', '-Xms64m', '-Xmx64m', '-XX:-UseFourByteObjectHeaders',
         '-XX:-UseCompressedOops', '-XX:+UnlockDiagnosticVMOptions', '-XX:+PrintInterpreter']
header = re.compile(r'^(.+?)\s+\[(0x[0-9a-fA-F]+),\s*(0x[0-9a-fA-F]+)\]\s+(\d+) bytes$', re.M)
results = {}
for label, role, extra in [('master', 'master', []), ('before-on', 'before', ['-XX:+UseCommonIntrinsics']),
                            ('final-off', 'final', ['-XX:-UseCommonIntrinsics']),
                            ('final-on', 'final', ['-XX:+UseCommonIntrinsics'])]:
    command = [images[role]['path'] + '/bin/java', *flags, *extra, '-version']
    log = out / (label + '.log')
    with log.open('w') as stream:
        code = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT).returncode
    assert code == 0, (label, code)
    text = log.read_text()
    rows = [(name.strip(), int(start, 16), int(end, 16), int(size))
            for name, start, end, size in header.findall(text)]
    base = next(start for name, start, end, size in rows if name == 'slow signature handler')
    bytecodes = {}
    for name, start, end, size in rows:
        fields = name.split()
        if len(fields) >= 2 and fields[-2].isdigit():
            key = fields[-2] + ':' + fields[-1]
            assert key not in bytecodes
            bytecodes[key] = {'offset': start - base, 'size': size}
    assert len(bytecodes) > 150 and '51:baload' in bytecodes
    results[label] = {'source': images[role]['source'], 'command': command, 'exit_code': code,
                      'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                      'base': base, 'codelets': len(rows), 'bytecodes': bytecodes,
                      'common_offsets': [start - base for name, start, end, size in rows
                                         if name == 'common intrinsic entry points']}
off, on = results['final-off']['bytecodes'], results['final-on']['bytecodes']
assert set(off) == set(on)
changes = {key: {'off': off[key], 'on': on[key], 'offset_delta': on[key]['offset'] - off[key]['offset']}
           for key in off if off[key] != on[key]}
record = {'images': images, 'variants': results, 'changed_final_on_off_bytecodes': changes,
          'scope': 'Read-only generated-code layout diagnostic; not a performance result.'}
(out / 'layout.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'bytecodes': len(off), 'changed_on_off': len(changes),
                  'deltas': sorted({x['offset_delta'] for x in changes.values()}),
                  'common_offsets': {k: v['common_offsets'] for k, v in results.items()}}, indent=2))
