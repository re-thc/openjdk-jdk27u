"""Match new failures only to precise, retained baseline control evidence."""
import collections
import hashlib
import json
import pathlib
import re

r=pathlib.Path('/workspace/pr9-layout-validation')
old=pathlib.Path('/workspace/pr9-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
control_path=old/'tier2-failure-analysis.json'
known={x['test_jtr']:x for x in json.loads(control_path.read_text())['failures']}
rows=[]
for work in sorted(r.glob('clean-*-tier2-*-work')):
    for jtr in sorted(work.rglob('*.jtr')):
        data=jtr.read_bytes();text=data.decode(errors='replace')
        status=re.search(r'^execStatus=(Failed|Error)\.(.*)$',text,re.M)
        if status is None:continue
        rel=str(jtr.relative_to(work));classification='unclassified';proof=None
        if rel in known and known[rel]['message'] in text:
            detail=known[rel]
            baseline=old/detail['reproduced']['master-default']
            if baseline.exists() and detail['message'] in baseline.read_text(errors='replace'):
                matched=True
                if rel.endswith('/Cleaners.jtr'):
                    current_child=work/'sun/security/krb5/auto/Cleaners/server.stderr'
                    baseline_child=old/detail['native_server_stderr']['master']['path']
                    matched=(current_child.exists() and baseline_child.exists() and
                             detail['native_cause_message'] in current_child.read_text(errors='replace') and
                             detail['native_cause_message'] in baseline_child.read_text(errors='replace'))
                if matched:
                    classification=detail['category']
                    proof={'source':'87edd79d3104ff502f7befec034716b081436f49',
                           'path':str(baseline),'sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),
                           'scope':'Retained historical baseline control, not a new-source test pass.'}
                    if rel.endswith('/Cleaners.jtr'):
                        proof['baseline_child_stderr']={'path':str(baseline_child),
                            'sha256':hashlib.sha256(baseline_child.read_bytes()).hexdigest()}
                        proof['current_child_stderr']={'path':str(current_child),
                            'sha256':hashlib.sha256(current_child.read_bytes()).hexdigest()}
        rows.append({'cohort':work.name.removesuffix('-work'),'test_jtr':rel,
                     'path':str(jtr.relative_to(r)),'sha256':hashlib.sha256(data).hexdigest(),
                     'status':status[1],'detail':status[2],'classification':classification,
                     'baseline_control':proof})
counts=dict(collections.Counter(x['classification'] for x in rows))
record={'source':source,'status':'investigation-required' if counts.get('unclassified') else 'observed-failures-classified',
        'counts':counts,'failed_jtrs':rows,
        'historical_control_index':{'source':json.loads(control_path.read_text())['source'],
             'path':str(control_path),'sha256':hashlib.sha256(control_path.read_bytes()).hexdigest()},
        'scope':'Current-source failures stay failures. Matching named baseline causes does not certify clean tier2.'}
(r/'tier2-observed-failures.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'counts':counts,'unknown':[x for x in rows if x['classification']=='unclassified']},indent=2))
