"""Checkpoint new actual correctness results before releasing the warm matrix."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import time
import zipfile

r=pathlib.Path('/workspace/pr9-layout-validation')
old=pathlib.Path('/workspace/pr9-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
gate=r/'core-evidence.json'
assert not gate.exists()
os.sched_setaffinity(0,{max(os.sched_getaffinity(0))})
while True:
    state=json.loads((r/'layout-qualification.json').read_text())
    early=json.loads((r/'early-warm-state.json').read_text())
    assert state['status']!='blocked-for-review' and early['status']!='blocked-for-review'
    manifest=r/'dynamic-big-probe/manifest.json'
    if state['status']=='core-qualification-passed-ready-for-quiet-warm-tier' and manifest.exists():
        rows=json.loads(manifest.read_text())
        if len(rows)==8 and all(x['passed'] for x in rows):break
    time.sleep(5)
subprocess.run(['python3',str(r/'assess_core.py')],check=True)
assessment=json.loads((r/'core-assessment.json').read_text())
out=pathlib.Path('/workspace/pr9-recovery/layout-stage-02-core');out.mkdir()
files={}
for pattern in ['*.py','*.json','*.log','*.xml','layout-after-diagnostic/*','dynamic-big-probe/*.log','dynamic-big-probe/*.json','release-cold-gc/*','fastdebug-cold-gc/*']:
    for p in r.glob(pattern):
        if p.is_file():files[str(p.relative_to(r))]=p
for cohort in assessment['cohorts']:
    name=cohort['name']
    for p in (r/(name+'-work')).rglob('*.jtr'):files[str(p.relative_to(r))]=p
for kind in ['release','fastdebug']:
    for suffix in ['.json','-build.log','-build.log.result.json','-prepare.log','-prepare.log.result.json']:
        p=old/('layout-'+kind+suffix)
        if p.exists():files['builds/'+p.name]=p
files['ACTIVE_STATE.json']=pathlib.Path('/workspace/pr9-recovery/ACTIVE_STATE.json')
manifest=[]
with zipfile.ZipFile(out/'validation.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):
        data=p.read_bytes();z.writestr(name,data)
        manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'validation.zip') as z:assert z.testzip() is None
packet=out/'validation.zip'
qualification={k:v for k,v in assessment.items() if k!='cohorts'}
qualification['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
qualification['archive']={'name':packet.name,'bytes':packet.stat().st_size,
                          'sha256':hashlib.sha256(packet.read_bytes()).hexdigest()}
(out/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
remote='.github/qualification/chain-checkpoint/layout-stage-02-core'
command=['python3',str(r/'run_reaped.py'),str(r/'publish-core-evidence.log'),
         'python3',str(old/'publish_evidence.py'),str(out),remote,
         'Checkpoint actual clean e41d Linux x64 core qualification']
subprocess.run(command,check=True)
commit=(r/'publish-core-evidence.log').read_text().strip().splitlines()[-1]
assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
receipt={'source':source,'commit':commit,'qualification_path':remote+'/qualification.json',
         'core_assessment_sha256':hashlib.sha256((r/'core-assessment.json').read_bytes()).hexdigest(),
         'archive':qualification['archive'],'scope':qualification['scope']}
temporary=gate.with_suffix('.tmp');temporary.write_text(json.dumps(receipt,indent=2)+'\n');temporary.replace(gate)
print(json.dumps(receipt,indent=2),flush=True)
