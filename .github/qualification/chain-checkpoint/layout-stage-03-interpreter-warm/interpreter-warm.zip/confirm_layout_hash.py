"""Fixed ten-round follow-up including the previous regressed VM as a control."""
import hashlib
import json
import os
import pathlib
import subprocess

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
plan=json.loads((r/'layout-hash-confirmation-plan.json').read_text())
assert plan['source']==source and plan['rounds']==10
assert json.loads((r/'early-warm-state.json').read_text())['status']=='first-interpreter-tier-complete-awaiting-review'
assert not subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True).stdout.strip()
original=json.loads((r/'final-warm/manifest.json').read_text())
images=json.loads((r/'images.json').read_text());assert images==original['images'] and images['final']['source']==source
assert len(original['records'])==144
previous=json.loads(pathlib.Path('/workspace/pr9-validation/clean-release.json').read_text())
assert previous['source']=='0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc' and previous['status']=='passed'
images['previous']={k:previous[k] for k in ['path','source','fingerprints']}
assert sorted(os.sched_getaffinity(0))[:2]==[0,1]
from performance_environment import snapshot
snapshot('hash-confirmation-before')
os.sched_setaffinity(0,{0});prep=[]
for role,image in images.items():
    base=pathlib.Path(image['path'])
    for file,fp in image['fingerprints'].items():
        h=hashlib.sha256()
        with (base/file).open('rb') as stream:
            for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
        assert h.hexdigest()==fp['sha256'],(role,file)
    lib=base/'lib/server/libjvm.so';data=lib.read_bytes()
    with lib.open('r+b') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    assert hashlib.sha256(lib.read_bytes()).hexdigest()==image['fingerprints']['lib/server/libjvm.so']['sha256']
    prep.append({'image':role,'path':str(lib),'sha256':hashlib.sha256(data).hexdigest(),'rewritten_unchanged':True})
(r/'hash-confirmation-library-preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
os.sched_setaffinity(0,{1})
for name,sha in original['classpath_sha256'].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==sha
labels=plan['labels'];assert labels==['master','before-on','previous-on','final-off','final-on']
templates={label:next(x for x in original['records'] if x['tier']=='int' and x['case']=='hash' and
            x['label']==('final-on' if label=='previous-on' else label) and x['pair']==0) for label in labels}
out=r/'confirm-layout-hash';out.mkdir(exist_ok=False);rows=[]
def save():
    (out/'manifest.json').write_text(json.dumps({'source':source,'images':images,'pairs':10,
        'labels':labels,'flags':original['flags'],'classpath':original['classpath'],
        'classpath_sha256':original['classpath_sha256'],'plan':plan,'records':rows},indent=2)+'\n')
save()
for pair in range(10):
    order=labels[pair%5:]+labels[:pair%5]
    for label in order:
        name=f'int-hash-{label}-{pair}';result=out/(name+'.json')
        command=list(templates[label]['command']);assert command[command.index('-p')+1]=='length=1,32,65537'
        command[command.index('-p')+1]='length=65537';command[command.index('-rff')+1]=str(result)
        if label=='previous-on':
            java=images['previous']['path']+'/bin/java';command[3]=java;command[command.index('-jvm')+1]=java
        with (out/(name+'.log')).open('w') as log:
            code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
        row={'name':name,'tier':'int','case':'hash','label':label,'pair':pair,'command':command,'exit_code':code}
        if code==0:
            data=result.read_bytes();values=json.loads(data)
            assert len(values)==1 and values[0]['params']=={'length':'65537'}
            row.update(results=values,result_sha256=hashlib.sha256(data).hexdigest())
        rows.append(row);save();print(name+' exit '+str(code),flush=True)
        if code:raise SystemExit(code)
snapshot('hash-confirmation-after')
