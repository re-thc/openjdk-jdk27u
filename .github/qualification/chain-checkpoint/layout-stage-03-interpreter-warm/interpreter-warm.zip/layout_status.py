"""Compact read-only status for the new-source validation namespace."""
import collections
import datetime
import json
import pathlib
import re
import sys
import time

r=pathlib.Path('/workspace/pr9-layout-validation')
old=pathlib.Path('/workspace/pr9-validation')
def read(path):
    for attempt in range(3):
        try:return json.loads(path.read_text())
        except json.JSONDecodeError:
            if attempt==2:raise
            time.sleep(.1)
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
for kind in ['release','fastdebug']:
    d=read(old/('layout-'+kind+'.json'))
    print(json.dumps({'build':kind,'source':d['source'],'status':d['status']}))
for name in ['layout-qualification.json','early-warm-state.json','final-performance.json']:
    p=r/name
    if p.exists():
        d=read(p);print(json.dumps({'file':name,'status':d['status'],'steps':[
            {'name':x['name'],'exit_code':x['exit_code']} for x in d.get('steps',[]) if '--brief' not in sys.argv],
            'error':d.get('error')}))
counts=collections.Counter();cohorts=[]
for p in sorted(r.glob('clean-*.result.json')):
    if p.name.endswith('.log.result.json'):continue
    d=read(p)
    if 'source_checkout_at_start' not in d:continue
    own=collections.Counter()
    for line in d['summary'].splitlines():
        m=re.search(r'\s(Passed|Failed|Error|Not run)\.(.*)$',line)
        if m:own['Skipped' if m[1]=='Passed' and m[2].startswith(' Skipped') else m[1]]+=1
    counts.update(own);cohorts.append({'name':d['name'],'exit_code':d['exit_code'],'counts':dict(own)})
print(json.dumps({'completed_jtreg':cohorts if '--brief' not in sys.argv else len(cohorts),'completed_counts':dict(counts)}))
for folder in ['final-warm','final-warm-controls']:
    p=r/folder/'manifest.json'
    if p.exists():
        d=read(p);rows=d['records'];print(json.dumps({'folder':folder,'invocations':len(rows),
            'parameter_forks':sum(len(x.get('results',[])) for x in rows),
            'failed':sum(x['exit_code']!=0 for x in rows),'last':rows[-1]['name'] if rows else None}))
