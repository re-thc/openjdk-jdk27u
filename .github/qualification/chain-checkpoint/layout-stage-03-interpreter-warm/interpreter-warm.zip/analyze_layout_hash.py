"""Account for every fork in the fixed five-variant, ten-round follow-up."""
import hashlib
import json
import math
import os
import pathlib
import statistics
os.environ['OPENBLAS_NUM_THREADS']='1'
from scipy.stats import t
r=pathlib.Path('/workspace/pr9-layout-validation');out=r/'confirm-layout-hash'
body=(out/'manifest.json').read_bytes();d=json.loads(body)
assert d['source']=='e41d7823bf6de77c4bfba52e896bf325221488cb' and d['pairs']==10 and len(d['records'])==50
samples={}
for row in d['records']:
    data=(out/(row['name']+'.json')).read_bytes()
    assert row['exit_code']==0 and hashlib.sha256(data).hexdigest()==row['result_sha256']
    result=row['results'][0];metric=result['primaryMetric']
    assert metric['scoreUnit']=='ns/op' and math.isfinite(metric['score']) and metric['score']>0
    samples[row['label'],row['pair']]=metric['score']
assert set(samples)=={(l,p) for l in d['labels'] for p in range(10)}
comparisons={}
for left,right in [('previous-on','final-on'),('previous-on','before-on'),('before-on','final-on'),
                   ('master','final-on'),('final-off','final-on'),('master','final-off')]:
    values=[samples[right,p]-samples[left,p] for p in range(10)]
    mean=statistics.mean(values);half=float(t.ppf(.975,9))*statistics.stdev(values)/math.sqrt(10)
    comparisons[left+'_'+right]={'pairs':10,'difference_ns':mean,'paired_95_ci_ns':[mean-half,mean+half]}
record={'source':d['source'],'means_ns':{l:statistics.mean(samples[l,p] for p in range(10)) for l in d['labels']},
        'comparisons':comparisons,'all_samples':[{'label':l,'pair':p,'ns_per_op':samples[l,p]} for l in d['labels'] for p in range(10)],
        'manifest_sha256':hashlib.sha256(body).hexdigest(),
        'scope':'Fixed prospective hash65537 follow-up only; no trimming, early stopping, or replacement of original4rounds. '
                'Paired Student-t95% on fork means. Remaining performance and native qualification stay separate.'}
(r/'layout-hash-confirmation-analysis.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='all_samples'},indent=2))
