"""Read completed current-source results without treating skipped cases as passes."""
import collections
import hashlib
import json
import pathlib
import re
import xml.etree.ElementTree as ET

r=pathlib.Path('/workspace/pr9-layout-validation')
source='e41d7823bf6de77c4bfba52e896bf325221488cb'
state=json.loads((r/'layout-qualification.json').read_text())
assert state['source']==source and state['status']=='core-qualification-passed-ready-for-quiet-warm-tier'
cohorts=[];totals=collections.Counter()
for kind in ['release','fastdebug']:
    qualification=json.loads((r/('clean-'+kind+'-qualification.json')).read_text())
    assert qualification['source']==source
    for cohort in qualification['cohorts']:
        name=cohort['name'];result=r/(name+'.result.json');d=json.loads(result.read_text())
        assert d['source_checkout_at_start']==source and d['exit_code']==0
        counts=collections.Counter();jtrs=[]
        for jtr in sorted((r/(name+'-work')).rglob('*.jtr')):
            data=jtr.read_bytes();text=data.decode(errors='replace')
            match=re.search(r'^execStatus=(.*)$',text,re.M)
            if match is None:continue
            status=match[1];outcome='Skipped' if status.startswith('Passed. Skipped') else status.split('.')[0]
            counts[outcome]+=1
            jtrs.append({'path':str(jtr.relative_to(r)),'outcome':outcome,'status':status,
                         'sha256':hashlib.sha256(data).hexdigest()})
        assert not counts['Failed'] and not counts['Error'] and not counts['Not run']
        totals.update(counts)
        cohorts.append({'name':name,'counts':dict(counts),'result_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),'jtrs':jtrs})
    layout=[j for c in cohorts if c['name']=='clean-'+kind+'-common'
            for j in c['jtrs'] if j['path'].endswith('TestCommonIntrinsicInterpreterLayout.jtr')]
    assert len(layout)==1 and layout[0]['outcome']=='Passed'
flags=[];gc=[]
for kind in ['release','fastdebug']:
    rows=json.loads((r/(kind+'-gc-flags.json')).read_text())
    assert len(rows)==432 and all(x['exit_code']==0 and x['checksum']==x['expected'] for x in rows)
    flags.extend(rows)
    d=json.loads((r/(kind+'-cold-gc/manifest.json')).read_text())
    assert all(x['source']==source for x in d['images'].values())
    assert len(d['records'])==40 and all(x['passed'] and x['gc_cycles']>0 for x in d['records'])
    gc.extend(d['records'])
root=ET.parse(r/'fastdebug-gtests.xml').getroot()
tests=list(root.iter('testcase'))
assert not list(root.iter('failure')) and not list(root.iter('error'))
disabled=sum(x.get('status')=='notrun' or x.find('skipped') is not None for x in tests)
diagnostic=json.loads((r/'layout-after-diagnostic/layout.json').read_text())
assert not diagnostic['changed_final_on_off_bytecodes']
dynamic=json.loads((r/'dynamic-big-probe/manifest.json').read_text())
assert len(dynamic)==8 and all(x['source']==source and x['passed'] for x in dynamic)
record={'source':source,'status':'completed-focused-linux-x64-qualification',
        'focused_counts':dict(totals),'cohorts':cohorts,'functional_flag_gc_passes':len(flags),
        'concurrent_cold_gc_passes':len(gc),'actual_gc_cycles':sum(x['gc_cycles'] for x in gc),
        'fastdebug_native_gtests':{'passed':len(tests)-disabled,'disabled':disabled},
        'dynamic_cds_checks':len(dynamic),'ordinary_interpreter_bytecodes':len(diagnostic['variants']['final-on']['bytecodes']),
        'on_off_bytecode_layout_differences':0,
        'scope':'Actual e41d clean-image executions only. This does not qualify full tier2, '
                'performance, native ARM CDS/performance or Windows native/AVX512 execution.'}
(r/'core-assessment.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='cohorts'},indent=2))
