import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation')
images = json.loads((r / 'images.json').read_text())
rows = []
for label in ['master', 'before']:
    name = f'tier2-classify-filestore-{label}'
    command = ['python3', str(r / 'jtreg_batch.py'), name, images[label]['path'],
               '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
               '--nativepath=/workspace/openjdk-jdk27u/build/pr9-release/images/test/jdk/jtreg/native',
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42',
               'test/jdk/java/nio/file/FileStore/Basic.java']
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    rows.append({'name': name, 'image_source': images[label]['source'],
                 'command': command, 'exit_code': code})
    (r / 'tier2-filestore-classification.json').write_text(json.dumps(rows, indent=2) + '\n')
