import json
import os
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation/external-data/openssl')
source = r / 'openssl'
prefix = r / 'install'
env = dict(os.environ, LDFLAGS='-Wl,-rpath,' + str(prefix / 'lib'))
commands = [
    ['perl', 'Configure', '--prefix=' + str(prefix), '--libdir=lib', 'no-tests'],
    ['make', '-j1', 'build_sw'],
    ['make', '-j1', 'install_sw'],
]
record = {'source_commit': 'c1eeb9406b6142148f267594197d853403d10208',
          'version': '3.5.4', 'prefix': str(prefix),
          'environment': {'LDFLAGS': env['LDFLAGS']}, 'commands': [], 'status': 'building'}
for command in commands:
    code = subprocess.run(command, cwd=source, env=env).returncode
    record['commands'].append({'command': command, 'exit_code': code})
    (r / 'build-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
    if code:
        raise SystemExit(code)
record['status'] = 'built-awaiting-fingerprint-validation'
(r / 'build-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
