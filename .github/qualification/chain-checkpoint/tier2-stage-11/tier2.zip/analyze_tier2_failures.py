import json
import hashlib
import pathlib

r = pathlib.Path('/workspace/pr9-validation')
source = '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
cases = []
for cls in ['TestEpsilonGCWithCDS', 'TestParallelGCWithCDS', 'TestShenandoahWithCDS']:
    for ident in [0, 1]:
        cases.append((f'runtime/cds/appcds/{cls}_id{ident}.jtr',
                      'UseFourByteObjectHeaders differs from the archive (0 vs 1).',
                      'baseline-cross-collector-header-mismatch'))
for cls in ['TestJmapCore', 'TestJmapCoreMetaspace']:
    cases.append((f'serviceability/sa/{cls}.jtr',
                  'java.io.FileNotFoundException: /proc/sys/kernel/core_pattern',
                  'environment-core-pattern-unavailable'))
cases.append(('com/sun/jndi/ldap/LdapPoolTimeoutTest.jtr',
              'java.net.UnknownHostException: example.com',
              'environment-external-dns-unavailable'))
cases.append(('sun/security/krb5/auto/Cleaners.jtr',
              'java.lang.Exception: Proc abnormal end',
              'baseline-reproduced-native-gss-failure'))
cases.append(('java/nio/file/FileStore/Basic.jtr',
              'FileStores should be unique',
              'baseline-reproduced-filestore-failure'))
records = []
for rel, message, category in cases:
    ldap = rel.startswith('com/sun/jndi/')
    cleaners = rel.endswith('/Cleaners.jtr')
    filestore = rel.startswith('java/nio/file/FileStore/')
    suite = ('jdk-security' if cleaners else 'jdk-io-tools-time' if ldap or filestore else
             'hotspot-runtime' if rel.startswith('runtime/') else 'hotspot-serviceability')
    paths = {
        'current-release': r / f'clean-release-tier2-{suite}-work' / rel,
        'master-default': r / ('tier2-classify-filestore-master-work' if filestore else
                               'tier2-classify-cleaners-master-work' if cleaners else
                               'tier2-classify-master-ldap-dns-work' if ldap
                               else 'tier2-classify-master-default-work') / rel,
        'before-default': r / ('tier2-classify-filestore-before-work' if filestore else
                               'tier2-classify-cleaners-before-on-work' if cleaners else
                               'tier2-classify-before-ldap-dns-work' if ldap
                               else 'tier2-classify-before-default-work') / rel,
    }
    fd = r / f'clean-fastdebug-tier2-{suite}-work' / rel
    if fd.exists() and 'execStatus=Failed.' in fd.read_text(errors='replace'):
        paths['current-fastdebug'] = fd
    for label, path in paths.items():
        text = path.read_text(errors='replace')
        assert 'execStatus=Failed.' in text, (label, path)
        assert message in text, (label, path)
        if filestore:
            assert 'expected: <false> but was: <true>' in text, (label, path)
    corrected = {}
    if rel.startswith('runtime/'):
        for kind, name in [('release', 'current'), ('fastdebug', 'fastdebug')]:
            path = r / f'tier2-classify-{name}-fourbyte-off-work' / rel
            if path.exists() and 'execStatus=' in path.read_text(errors='replace'):
                assert 'execStatus=Passed.' in path.read_text(errors='replace')
                corrected[kind] = str(path.relative_to(r))
    extra = {}
    if cleaners:
        cause = 'GSSException: Security context init/accept not yet called or context deleted'
        evidence = {}
        for label in ['current-on', 'current-off', 'before-on', 'master']:
            f = r / f'tier2-classify-cleaners-{label}-work/sun/security/krb5/auto/Cleaners/server.stderr'
            text = f.read_text(errors='replace')
            assert cause in text and 'NativeGSSContext.acceptSecContext' in text
            evidence[label] = {'path': str(f.relative_to(r)),
                               'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
        original = paths['current-release']
        text = original.read_text(errors='replace')
        assert 'PROC: server readline: <EOF>' in text and 'Cleaners.java:107' in text
        extra = {'native_cause_message': cause, 'native_server_stderr': evidence,
                 'original_jtr_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                 'original_child_stderr_retained': False,
                 'notes': 'Original parent EOF at server accept; retained diagnostic runs reproduce that stage with the same native GSS exception in all four variants. Attribution beyond baseline reproduction is not claimed.'}
    records.append({'test_jtr': rel, 'category': category, 'message': message,
                    'reproduced': {k: str(v.relative_to(r)) for k, v in paths.items()},
                    'passing_same_source_fourbyte_headers_off': corrected, **extra})
record = {'source': source, 'status': 'classification-of-named-observed-failures',
          'full_tier2_status': 'incomplete-not-clean', 'failures': records,
          'core_pattern_exists': pathlib.Path('/proc/sys/kernel/core_pattern').exists(),
          'scope': 'These controls classify only the named failures; later failures need separate investigation.'}
(r / 'tier2-failure-analysis.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'categories': {c: sum(x['category'] == c for x in records)
                               for c in sorted({x['category'] for x in records})},
                  'records': len(records)}))
