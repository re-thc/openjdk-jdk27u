import json
import pathlib
import subprocess

r = pathlib.Path('/workspace/pr9-validation')
images = json.loads((r / 'images.json').read_text())
record = {'status': 'running', 'cohorts': []}
for label, image, extra in [
    ('current-on', 'final', ' -XX:+UseCommonIntrinsics'),
    ('current-off', 'final', ' -XX:-UseCommonIntrinsics'),
    ('before-on', 'before', ' -XX:+UseCommonIntrinsics'),
    ('master', 'master', ''),
]:
    name = f'tier2-classify-cleaners-{label}'
    command = ['python3', str(r / 'jtreg_batch.py'), name, images[image]['path'],
               '--exclude=/workspace/openjdk-jdk27u/test/jdk/ProblemList.txt',
               '--nativepath=/workspace/openjdk-jdk27u/build/pr9-release/images/test/jdk/jtreg/native',
               '--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g '
               '-Djdk.test.lib.random.seed=42 -Dseed=42' + extra,
               'test/jdk/sun/security/krb5/auto/Cleaners.java']
    code = subprocess.run(command, cwd='/workspace/openjdk-jdk27u').returncode
    record['cohorts'].append({'name': name, 'image_source': images[image]['source'],
                              'command': command, 'exit_code': code})
    (r / 'tier2-cleaners-classification.json').write_text(json.dumps(record, indent=2) + '\n')
record['status'] = 'completed-awaiting-analysis'
(r / 'tier2-cleaners-classification.json').write_text(json.dumps(record, indent=2) + '\n')
