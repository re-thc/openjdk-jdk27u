package org.openjdk.bench.vm.compiler;

import java.math.BigInteger;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
public class CommonBigIntegerSquares {
    @Param({"512", "2048", "4096"}) public int bits;
    private BigInteger value;

    @Setup public void setup() {
        value = new BigInteger(bits, new Random(42)).setBit(bits - 1);
    }

    @Benchmark public BigInteger selfSquare() {
        return value.multiply(value);
    }
}
