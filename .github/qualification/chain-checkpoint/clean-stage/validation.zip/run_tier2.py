import argparse,json,pathlib,subprocess,time
p=argparse.ArgumentParser();p.add_argument('kind',choices=['release','fastdebug']);p.add_argument('--concurrency',type=int,default=2);p.add_argument('--skip',action='append',default=[]);a=p.parse_args()
r=pathlib.Path('/workspace/pr9-validation');repo=pathlib.Path('/workspace/openjdk-jdk27u');build=json.loads((r/('clean-'+a.kind+'.json')).read_text());assert build['status']=='passed';image=build['path']
native=repo/'build'/('pr9-'+a.kind)/'images/test'
nativepaths={'hotspot/jtreg':native/'hotspot/jtreg/native','jdk':native/'jdk/jtreg/native'}
assert all(x.is_dir() for x in nativepaths.values()),nativepaths
cases=[('hotspot-runtime','hotspot/jtreg','hotspot_tier2_runtime'),('hotspot-resolution','hotspot/jtreg','hotspot_tier2_runtime_platform_agnostic'),('hotspot-serviceability','hotspot/jtreg','hotspot_tier2_serviceability'),('hotspot-compiler','hotspot/jtreg','tier2_compiler'),('hotspot-ctw','hotspot/jtreg','tier2_ctw'),('hotspot-shenandoah','hotspot/jtreg','tier2_gc_shenandoah'),('jdk-security','jdk','tier2_part1'),('jdk-io-tools-time','jdk','tier2_part2'),('jdk-net','jdk','tier2_part3'),('langtools','langtools','tier2'),('jaxp','jaxp','tier2')]
record={'source':build['source'],'image':image,'fingerprints':build['fingerprints'],'scope':cases,'nativepaths':{k:str(v) for k,v in nativepaths.items()},'concurrency':a.concurrency,'empty_group':'hotspot tier2_gc_epsilon is empty in TEST.groups','cohorts':[],'status':'running'}
def save():(r/('tier2-'+a.kind+'.json')).write_text(json.dumps(record,indent=2)+'\n')
save()
for label,suite,group in cases:
 if label in a.skip:
  previous=r/('clean-'+a.kind+'-tier2-'+label+'.result.json');assert previous.exists();old=json.loads(previous.read_text());assert old['exit_code']==0 and old['source_checkout_at_start']==build['source']
  record['cohorts'].append({'name':'clean-'+a.kind+'-tier2-'+label,'exit_code':0,'previous_completed_batch':True});save();continue
 name='clean-'+a.kind+'-tier2-'+label;problem=repo/'test'/suite/'ProblemList.txt'
 # Some suites have no ProblemList; use an explicit empty list in that case.
 if not problem.exists():
  problem=r/'empty-problem-list.txt';problem.write_text('')
 command=['python3',str(r/'jtreg_batch.py'),name,image,'--concurrency='+str(a.concurrency),'--exclude='+str(problem),'--nativepath='+str(nativepaths.get(suite,nativepaths['hotspot/jtreg'])),'--vmoptions=-XX:ActiveProcessorCount=2 -XX:CICompilerCount=2 -Xmx1g -Djdk.test.lib.random.seed=42 -Dseed=42','test/'+suite+':'+group]
 start=time.time();code=subprocess.run(command,cwd=repo).returncode;record['cohorts'].append({'name':name,'exit_code':code,'seconds':time.time()-start,'command':command});save()
record['status']='passed' if all(x['exit_code']==0 for x in record['cohorts']) else 'has-failures';save();raise SystemExit(0 if record['status']=='passed' else 1)
