import json
import argparse
from pathlib import Path
import subprocess

root = Path('/workspace/pr9-validation')
p = argparse.ArgumentParser()
p.add_argument('--images', nargs='+', default=['final-release', 'final-fastdebug'])
p.add_argument('--output', default='gc-flags-probe.json')
a = p.parse_args()
tiers = [('int', ['-Xint']), ('c1-l1', ['-Xbatch', '-XX:TieredStopAtLevel=1']),
         ('c1-l3', ['-Xbatch', '-XX:TieredStopAtLevel=3']), ('c2', ['-Xbatch', '-XX:-TieredCompilation'])]
cases = [('FirstUse', ['hash']), ('FirstUse', ['sha256']), ('FirstUse', ['scalar']),
         ('FirstBigInteger', ['multiply', '512']), ('FirstBigInteger', ['multiply', '4096']),
         ('FirstBigInteger', ['modpow', '512']), ('FirstBigInteger', ['modpow', '4096']),
         ('FirstBigInteger', ['product', '2560']), ('FirstBigInteger', ['product', '4096'])]
base = ['-XX:ActiveProcessorCount=1', '-XX:CICompilerCount=2', '-Xms32m', '-Xmx256m']
checksums = {}
for cls, args in cases:
    cmd = [str(root / 'images/master-release/bin/java'), '-Xint', *base,
           '-cp', str(root / 'first-use.jar'), cls, *args]
    r = subprocess.run(cmd, capture_output=True, text=True, check=True)
    checksums[(cls, tuple(args))] = int(r.stdout.split()[-1])
records = []
for image in a.images:
    for gc in ['Serial', 'G1', 'Z', 'Parallel', 'Shenandoah']:
        for tier, mode in tiers:
            for enabled in [False, True]:
                for cls, args in cases:
                    opts = [*base, '-XX:+UnlockExperimentalVMOptions', '-XX:+Use' + gc + 'GC',
                            '-XX:' + ('+' if enabled else '-') + 'UseCommonIntrinsics', *mode]
                    if image.endswith('fastdebug'):
                        opts += ['-XX:+UnlockDiagnosticVMOptions', '-XX:+CheckUnhandledOops', '-XX:+VerifyOops']
                    cmd = [str(root / 'images' / image / 'bin/java'), *opts, '-cp', str(root / 'first-use.jar'), cls, *args]
                    r = subprocess.run(cmd, capture_output=True, text=True)
                    checksum = int(r.stdout.split()[-1]) if r.returncode == 0 else None
                    row = {'image': image, 'gc': gc, 'tier': tier, 'enabled': enabled,
                           'class': cls, 'args': args, 'command': cmd, 'exit_code': r.returncode,
                           'checksum': checksum, 'expected': checksums[(cls, tuple(args))]}
                    if r.returncode != 0 or checksum != row['expected']:
                        row.update(stdout=r.stdout, stderr=r.stderr)
                    records.append(row)
                    (root / a.output).write_text(json.dumps(records, indent=2) + '\n')
                    if r.returncode != 0 or checksum != row['expected']:
                        raise RuntimeError(row)
        print(image, gc, 'passed', flush=True)
