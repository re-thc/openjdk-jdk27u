import java.math.BigInteger;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public class ColdBigIntegerGC {
    public static void main(String[] args) throws Exception {
        byte[] input = new byte[512];
        input[0] = (byte) 0x80;
        input[511] = 3;
        BigInteger x = new BigInteger(1, input);
        input[511] = 5;
        BigInteger y = new BigInteger(1, input);
        byte[] result = new byte[1024];
        result[0] = 0x40;
        result[511] = 4;
        result[1023] = 15;
        BigInteger expected = new BigInteger(1, result);
        CountDownLatch ready = new CountDownLatch(8);
        CountDownLatch gate = new CountDownLatch(1);
        CountDownLatch gcEntered = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Thread[] workers = new Thread[8];
        for (int i = 0; i < workers.length; i++) {
            workers[i] = new Thread(() -> {
                ready.countDown();
                try {
                    gate.await();
                    for (int n = 0; n < 32; n++) {
                        if (!x.multiply(y).equals(expected)) throw new AssertionError("product");
                    }
                } catch (Throwable t) { failure.compareAndSet(null, t); }
            });
            workers[i].start();
        }
        ready.await();
        Thread collector = new Thread(() -> {
            try {
                gcEntered.countDown();
                byte[][] live = new byte[4][];
                for (int n = 0; n < 32; n++) {
                    live[n & 3] = new byte[256 * 1024];
                    System.gc();
                }
                java.lang.ref.Reference.reachabilityFence(live);
            } catch (Throwable t) { failure.compareAndSet(null, t); }
        });
        collector.start();
        gcEntered.await();
        System.out.println("before-first-product");
        gate.countDown();
        for (Thread worker : workers) worker.join();
        collector.join();
        if (failure.get() != null) throw new AssertionError(failure.get());
        System.out.println("PASS " + expected.hashCode());
    }
}
