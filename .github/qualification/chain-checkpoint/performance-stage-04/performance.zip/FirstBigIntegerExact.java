import java.math.BigInteger;
public class FirstBigIntegerExact {
    public static void main(String[] args) {
        int bits = Integer.parseInt(args[1]);
        byte[] input = new byte[bits / 8];
        for (int i = 0; i < input.length; i++) input[i] = (byte) (i * 31 + 1);
        input[0] |= (byte) 0x80;
        byte[] modulusInput = new byte[input.length];
        for (int i = 0; i < modulusInput.length; i++) modulusInput[i] = (byte) (i * 17 + 7);
        modulusInput[0] |= (byte) 0x80;
        modulusInput[modulusInput.length - 1] |= 1;
        long start = System.nanoTime();
        BigInteger value = new BigInteger(1, input);
        BigInteger result;
        if (args[0].equals("multiply")) {
            result = value.multiply(value);
        } else if (args[0].equals("product")) {
            result = value.multiply(value.add(BigInteger.ONE));
        } else {
            BigInteger modulus = new BigInteger(1, modulusInput);
            result = value.modPow(BigInteger.valueOf(65537), modulus);
        }
        long elapsed = System.nanoTime() - start;
        System.out.println(elapsed + " " + result.hashCode());
    }
}
