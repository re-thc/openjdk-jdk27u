import hashlib,json,os,pathlib,subprocess,sys,time
from performance_environment import snapshot
r=pathlib.Path('/workspace/pr9-validation');source='0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
state_path=r/'final-performance.json'
state=json.loads(state_path.read_text()) if state_path.exists() else {'source':source,'status':'waiting-for-tier2','phases':[]}
assert state['source']==source
def save():(r/'final-performance.json').write_text(json.dumps(state,indent=2)+'\n')
assessment_path=r/'tier2-assessment.json'
assessment=json.loads(assessment_path.read_text())
assert assessment['source']==source and assessment['local_timing_eligible']
assert not assessment['pending'] and not assessment['unknown_failures'] and not assessment['unreviewed_skips']
assert not assessment['unresolved_batch_errors']
for cohort in assessment['cohorts']:
 f=r/(cohort['name']+'.result.json')
 assert hashlib.sha256(f.read_bytes()).hexdigest()==cohort['result_sha256']
for kind in ['release','fastdebug']:
 d=json.loads((r/('tier2-'+kind+'.json')).read_text())
 assert d['source']==source and d['status'] in ['passed','has-failures'] and len(d['cohorts'])==11
receipt=json.loads((r/'pre-performance-evidence.json').read_text())
assert receipt['source']==source and receipt['assessment_sha256']==hashlib.sha256(assessment_path.read_bytes()).hexdigest()
repo='/workspace/openjdk-jdk27u'
assert subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','-C',repo,'status','--porcelain'],text=True).strip()
qualification=json.loads(subprocess.check_output(['git','-C',repo,'show',receipt['commit']+':'+receipt['qualification_path']]))
assert qualification['source']==source and qualification['status']=='completed-tier2-with-explicit-local-limitations'
state['assessment_sha256']=receipt['assessment_sha256'];state['pre_performance_evidence']=receipt;save()
# The completed test wrappers must leave no JVM/build activity before timing.
for attempt in range(12):
 q=subprocess.run(['ps','-C','java,make,gmake,cc1plus','-o','pid='],capture_output=True,text=True)
 if not q.stdout.strip():break
 time.sleep(5)
else:state['status']='blocked-by-other-work';save();raise SystemExit(1)
if 'environment_before' not in state:
 state['environment_before']=snapshot('before');save()
images=json.loads((r/'images.json').read_text());assert images['final']['source']==source
original=os.sched_getaffinity(0);os.sched_setaffinity(0,{min(original)});prep=[]
for name,entry in images.items():
 image=pathlib.Path(entry['path'])
 for f,v in entry['fingerprints'].items():
  h=hashlib.sha256()
  with (image/f).open('rb') as inp:
   for b in iter(lambda:inp.read(8*1024*1024),b''):h.update(b)
  assert h.hexdigest()==v['sha256'],(name,f)
 f=image/'lib/server/libjvm.so';data=f.read_bytes();sha=hashlib.sha256(data).hexdigest()
 with f.open('r+b') as out:out.write(data);out.flush();os.fsync(out.fileno())
 assert hashlib.sha256(f.read_bytes()).hexdigest()==sha
 prep.append({'image':name,'path':str(f),'sha256':sha,'rewritten_unchanged':True})
os.sched_setaffinity(0,original);(r/'final-library-preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
phases=[('first-legacy',['cold_matrix.py','first','--blocks','120','--sizes','512,2048,4096','--operations','multiply,product,modpow','--output','final-first-legacy.json']),('first-exact',['cold_matrix.py','first','--blocks','120','--sizes','512,4096','--operations','multiply,product,modpow','--fixture','FirstBigIntegerExact','--output','final-first-exact.json']),('first-boundaries',['cold_matrix.py','first','--blocks','120','--sizes','2560,3072,3328,3584,3840','--operations','product','--output','final-first-boundaries.json']),('first-other',['cold_matrix.py','first','--blocks','120','--sizes','64','--operations','scalar,hash,sha256','--fixture','FirstUse','--output','final-first-other.json']),('startup',['cold_matrix.py','startup','--blocks','600','--output','final-startup.json']),('warm',['warm_matrix.py','--pairs','4','--output','final-warm']),('warm-controls',['warm_matrix.py','--pairs','8','--controls','--tier','c2','--output','final-warm-controls'])]
def output_path(args):
 p=r/args[args.index('--output')+1]
 return p/'manifest.json' if args[0]=='warm_matrix.py' else p
completed={x['name']:x for x in state['phases']}
state['status']='measuring';save()
for name,args in phases:
 command=['python3',str(r/'run_reaped.py'),str(r/('final-'+name+'.log')),'python3',str(r/args[0]),*args[1:]]
 if name in completed:
  old=completed[name]
  assert old['exit_code']==0 and old['command']==command
  assert hashlib.sha256(output_path(args).read_bytes()).hexdigest()==old['output_sha256']
  print('Reuse verified completed phase: '+name,flush=True);continue
 start=time.time();code=subprocess.run(command).returncode
 record={'name':name,'command':command,'exit_code':code,'seconds':time.time()-start}
 if code==0:record['output_sha256']=hashlib.sha256(output_path(args).read_bytes()).hexdigest()
 state['phases'].append(record);save()
 if code:state['status']='measurement-failed';save();raise SystemExit(code)
for folder in ['final-warm','final-warm-controls']:
 subprocess.run(['python3',str(r/'summarize_warm.py'),str(r/folder)],check=True)
if 'environment_after' not in state:
 state['environment_after']=snapshot('after');save()
state['status']='measurements-complete-awaiting-regression-analysis';save()
