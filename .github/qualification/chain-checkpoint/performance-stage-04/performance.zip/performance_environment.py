"""Read-only machine-state snapshots surrounding the quiet measurements."""
import datetime
import json
import os
import pathlib
import platform
import subprocess

root = pathlib.Path('/workspace/pr9-validation')

def snapshot(label):
    values = {}
    for name in ['cpu.max', 'cpu.stat', 'cpu.pressure', 'memory.events',
                 'memory.current', 'pids.current']:
        path = pathlib.Path('/sys/fs/cgroup') / name
        if path.exists():
            values['cgroup/' + name] = path.read_text()
    for name in ['/proc/loadavg', '/proc/pressure/cpu', '/proc/pressure/memory',
                 '/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor']:
        path = pathlib.Path(name)
        if path.exists():
            values[name] = path.read_text()
    commands = {}
    for command in [['lscpu', '-J'], ['uname', '-a'], ['python3', '--version'],
                    ['taskset', '--version']]:
        result = subprocess.run(command, capture_output=True, text=True)
        commands[' '.join(command)] = {
            'exit_code': result.returncode, 'stdout': result.stdout,
            'stderr': result.stderr}
    record = {'label': label,
              'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'host': platform.node(), 'affinity': sorted(os.sched_getaffinity(0)),
              'values': values, 'commands': commands}
    path = root / ('performance-environment-' + label + '.json')
    assert not path.exists(), 'Preserve the original environment snapshot'
    path.write_text(json.dumps(record, indent=2) + '\n')
    return path.name
