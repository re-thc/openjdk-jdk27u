import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import zipfile

p = argparse.ArgumentParser()
p.add_argument('label')
a = p.parse_args()
r = pathlib.Path('/workspace/pr9-validation')
out = pathlib.Path('/workspace/pr9-recovery') / a.label
out.mkdir(parents=True, exist_ok=False)
source = subprocess.check_output(['git', '-C', '/workspace/openjdk-jdk27u',
                                  'rev-parse', 'HEAD'], text=True).strip()
assert source == '0fb3e86a762be2cd3ed9ec35f327e1e7c64682bc'
cohorts = []
files = set()
for result in sorted(r.glob('clean-*-tier2-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    d = json.loads(result.read_text())
    assert d['source_checkout_at_start'] == source
    name = result.name.removesuffix('.result.json')
    lines = d['summary'].splitlines()
    counts = {status: sum((' ' + status + '.') in line for line in lines)
              for status in ['Passed', 'Failed', 'Error', 'Skipped', 'Not run']}
    cohorts.append({'name': name, 'exit_code': d['exit_code'], 'counts': counts})
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-report/text')).glob('*'))
for name in ['tier2-release.json', 'tier2-fastdebug.json', 'run_tier2.py',
             'jtreg_batch.py', 'run_reaped.py', 'pack_tier2_evidence.py',
             'tier2-runtime-selection.txt', 'tier2-classification.json',
             'reaper-prevention-before.json', 'reaper-prevention-after.json',
             'reaper_orphan_selftest.py', 'reaper-orphan-selftest.log',
             'reaper-orphan-selftest.log.result.json', 'classify_tier2.py',
             'analyze_tier2_failures.py', 'tier2-failure-analysis.json',
             'pr9-current-metadata.json']:
    f = r / name
    if f.exists(): files.add(f)
for result in sorted(r.glob('tier2-classify-*.result.json')):
    if result.name.endswith('.log.result.json'):
        continue
    name = result.name.removesuffix('.result.json')
    files.add(result)
    for suffix in ['.log', '.log.result.json']:
        f = r / (name + suffix)
        if f.exists(): files.add(f)
    files.update((r / (name + '-work')).rglob('*.jtr'))
    files.update((r / (name + '-report/text')).glob('*'))
files.update((r / 'reaper-orphan-selftest').glob('*'))
manifest = []
with zipfile.ZipFile(out / 'tier2.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files):
        if not f.is_file(): continue
        data = f.read_bytes()
        name = str(f.relative_to(r))
        z.writestr(name, data)
        manifest.append({'path': name, 'size': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'tier2.zip') as z:
    assert z.testzip() is None
packet = out / 'tier2.zip'
record = {'source': source, 'status': 'partial-tier2-with-retained-failures',
          'cohorts': cohorts, 'files': len(manifest),
          'archive': {'name': packet.name, 'size': packet.stat().st_size,
                      'sha256': hashlib.sha256(packet.read_bytes()).hexdigest()}}
(out / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
(out / 'README.md').write_text(
    'Source 0fb3e86a clean-image tier2 checkpoint.\n\n'
    'Tier2 is incomplete. Original failed JTRs are retained. Six release CDS records '
    'show a cross-collector UseFourByteObjectHeaders archive mismatch; two SA records '
    'cannot read /proc/sys/kernel/core_pattern. Both pristine87edd and publishedc04d '
    'reproduce all eight failures. With explicit four-byte headers off, the six CDS '
    'records pass on both current clean release and fastdebug. This classifies the '
    'named failures only; additional failures require investigation. '
    'The bounded supervision check reaped one parent plus sixteen deliberately '
    'orphaned real tee helpers; all outputs matched and zombie count remained44. '
    'No source-readiness or performance conclusion is made.\n')
print(json.dumps(record, indent=2))
