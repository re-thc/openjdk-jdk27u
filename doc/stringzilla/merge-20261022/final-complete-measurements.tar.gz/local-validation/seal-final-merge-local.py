from pathlib import Path
import importlib.util,json,re,shutil,subprocess,sys
sys.dont_write_bytecode=True
mode=sys.argv[1];r=Path('/workspace/stringzilla-merge-check');a=Path('/workspace/stringzilla-recovery/integration-20261021');ev=Path('/workspace/stringzilla-evidence/doc/stringzilla/merge-20261022')
master='8d030adbd245b19e6339e3ccd052eb7fe3635319';merge='cd785f1c66fb72404c12b150d5f3d8e0fe0a4776';product='2538e2fd80a363ea19d45044950701df62a0162f';expected={'master':master,'candidate':merge}[mode]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==expected
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
spec=importlib.util.spec_from_file_location('support',ev/'support.py');support=importlib.util.module_from_spec(spec);spec.loader.exec_module(support)
image=a/'images'/('final-merge' if mode=='candidate' else 'merge-master');shutil.copytree(r/'build/stringzilla-merge/images/jdk',image);shutil.copyfile(r/'build/stringzilla-merge/spec.gmk',a/('final-merge-'+mode+'-spec.gmk'))
release=(image/'release').read_text();assert head[:12] in release and '+' not in re.search(r'^SOURCE="(.*)"$',release,re.M)[1]
original_spec=Path('/workspace/stringzilla-baseline/build/stringzilla-original/spec.gmk');settings=support.read_spec(a/('final-merge-'+mode+'-spec.gmk'));assert settings==support.read_spec(original_spec)
banners=[]
for f in [Path('/workspace/stringzilla-baseline/build/stringzilla-original/configure.log'),r/'build/stringzilla-merge/configure.log']:
 lines=[s for s in f.read_text().splitlines() if 'Boot JDK version...' in s or 'compiler version' in s];assert len(lines)>=3;banners.append(lines)
assert banners[0]==banners[1],banners
shipped=a/('final-merge-'+mode+'-shipped');classes={}
for name in ['String','StringLatin1','StringUTF16']+(['StringZilla'] if mode=='candidate' else []):
 subprocess.run([str(image/'bin/jimage'),'extract','--include','glob:**/java/lang/'+name+'.class','--dir',str(shipped),str(image/'lib/modules')],check=True)
 actual=shipped/'java.base/java/lang'/(name+'.class');built=r/'build/stringzilla-merge/jdk/modules/java.base/java/lang'/(name+'.class');assert support.sha(actual)==support.sha(built);classes[name]=support.sha(actual)
receipt={'source':head,'clean_source':True,'release':release,'inventory':support.image(image),'matched_build_settings':settings,'full_compiler_boot_banners_equal':True,'compiler_boot_banners':banners,'shipped_classes_sha256':classes,'classes_match_build_outputs':True,'source_trees':subprocess.check_output(['git','ls-tree','HEAD','bin','make','src','test'],cwd=r,text=True)}
(a/('final-merge-'+mode+'-seal.json')).write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copyfile(r/'build/stringzilla-merge/configure.log',a/('final-merge-'+mode+'-configure.log'))
if mode=='candidate':
 assert subprocess.check_output(['git','show','-s','--format=%P',head],cwd=r,text=True).strip().split()==[master,product]
 paths=['src/java.base/share/classes/java/lang/'+n+'.java' for n in ['String','StringLatin1','StringUTF16','StringZilla']]+['make/modules/java.base/lib/CoreLibraries.gmk','src/java.base/share/native/libjava/StringZillaKernels.c']
 subprocess.run(['git','diff','--exit-code',product,merge,'--',*paths],cwd=r,check=True)
 old=json.loads((a/'selected-922-controls.json').read_text());m=json.loads((a/'merge-master-seal.json').read_text());candidate={'image':str(image),'spec':str(a/'final-merge-candidate-spec.gmk'),'source':merge,'expected_tree_sha256':receipt['inventory']['tree_sha256']}
 controls={'original':old['original'],'master':{'image':str(a/'images/merge-master'),'spec':str(a/'merge-master-spec.gmk'),'source':master,'baseline':True,'expected_tree_sha256':m['inventory']['tree_sha256']},'prior':old['candidate'],'candidate':candidate,'disabled':{**candidate,'flags':['-XX:-UseStringZillaIntrinsics']}}
 (a/'final-merge-controls.json').write_text(json.dumps(controls,indent=2)+'\n');process={'original':controls['original'],'prior':controls['master'],'candidate':controls['candidate'],'disabled':controls['disabled']};(a/'final-merge-process-controls.json').write_text(json.dumps(process,indent=2)+'\n')
 (ev/'local-seal.json').write_text(json.dumps({'master':m,'actual_merge':receipt,'controls':controls},indent=2)+'\n')
print(json.dumps({'source':head,'mode':mode,'tree':receipt['inventory']['tree_sha256']}))
