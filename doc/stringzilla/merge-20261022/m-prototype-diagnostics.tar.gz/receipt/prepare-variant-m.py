from pathlib import Path
import difflib,hashlib,json,re
root=Path('/workspace/stringzilla-merge-check');out=Path('/workspace/stringzilla-recovery/integration-20261021');changes={}
def edit(name,func):
 p=root/name;old=p.read_text();new=func(old);assert old!=new,name;changes[name]=(old,new)
name='src/java.base/share/classes/java/lang/StringZilla.java'
def z(s):
 old='''    // Compilers fold this into their tier; the Java body keeps interpreter routing.
    @IntrinsicCandidate
    @ForceInline
    static int compilerTier() {
        return 0;
    }

'''
 assert s.count(old)==1;s=s.replace(old,'');return re.sub(r'(?<![\w.])compilerTier\(\)', 'String.compilerTier()',s)
edit(name,z)
for name in ['src/java.base/share/classes/java/lang/StringLatin1.java','src/java.base/share/classes/java/lang/StringUTF16.java']:
 edit(name,lambda s:s.replace('StringZilla.compilerTier()','String.compilerTier()'))
def string(s):
 old='''                    && (!StringZilla.ENABLED || StringZilla.compilerTier() == StringZilla.C1))'''
 new='''                    && (compilerTier() == StringZilla.C1 || !StringZilla.ENABLED))'''
 assert s.count(old)==1;s=s.replace(old,new)
 marker='''    /**
     * Code shared by String and AbstractStringBuilder to do searches.'''
 method='''    // String is initialized before its compiled callers query their tier.
    @IntrinsicCandidate
    @ForceInline
    static int compilerTier() {
        return 0;
    }

'''
 pos=s.rfind(marker);assert pos>=0 and 'static int lastIndexOf' in s[pos:pos+1100];return s[:pos]+method+s[pos:]
edit('src/java.base/share/classes/java/lang/String.java',string)
def vm(s):
 old='do_intrinsic(_stringzillaCompilerTier, java_lang_StringZilla,';new='do_intrinsic(_stringzillaCompilerTier, java_lang_String,';assert s.count(old)==1;return s.replace(old,new)
edit('src/hotspot/share/classfile/vmIntrinsics.hpp',vm)
edit('test/hotspot/jtreg/compiler/intrinsics/string/TestStringZillaAvailability.java',lambda s:s.replace('klass.getDeclaredMethod("compilerTier")','String.class.getDeclaredMethod("compilerTier")'))
edit('test/hotspot/jtreg/compiler/intrinsics/string/TestStringZillaDispatch.java',lambda s:s.replace('bridge.getDeclaredMethod("compilerTier")','String.class.getDeclaredMethod("compilerTier")'))
edit('test/hotspot/jtreg/compiler/intrinsics/string/java.base/java/lang/StringZillaDispatchHelper.java',lambda s:s.replace('StringZilla.compilerTier()','String.compilerTier()'))
patch=''.join(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n,(a,b) in changes.items());(out/'variant-m.patch').write_text(patch)
(out/'variant-m-proposal.json').write_text(json.dumps({'base':'actual merge2883; whitespace L changes are separate and do not overlap these edits','applied':False,'tested':False,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'files':{n:{'before':hashlib.sha256(a.encode()).hexdigest(),'after':hashlib.sha256(b.encode()).hexdigest()} for n,(a,b) in changes.items()},'purpose':'Move the existing tier-query intrinsic to already-initialized String and query C1 before touching StringZilla state. Same intrinsic ID/flag controls; migrate internal callers/tests, no compatibility wrapper or new public API.'},indent=2)+'\n');print('M proposal prepared, not applied:',len(changes),'files',len(patch.splitlines()),'patch lines')
