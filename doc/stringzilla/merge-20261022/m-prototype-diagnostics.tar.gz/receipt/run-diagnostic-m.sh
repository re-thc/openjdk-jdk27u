#!/bin/bash
set -euo pipefail
python3 /workspace/stringzilla-recovery/integration-20261021/seal-variant-m.py
python3 /workspace/stringzilla-evidence/doc/stringzilla/merge-20261022/compare.py --source /workspace/stringzilla-merge-check --controls /workspace/stringzilla-recovery/integration-20261021/diagnostic-m-controls.json --jars /workspace/stringzilla-recovery/final7048-avx2/jmh --manifest /workspace/stringzilla-recovery/integration-20261021/diagnostic-m-cases.json --output /workspace/stringzilla-recovery/integration-20261021/diagnostic-m --rounds 5 --warmup 2 --samples 3 --duration 200ms > /workspace/stringzilla-recovery/integration-20261021/diagnostic-m.log 2>&1
