from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
r=Path('/workspace/stringzilla-recovery/integration-20261021');root=Path('/workspace/stringzilla-merge-check');driver=Path('/workspace/stringzilla-evidence/doc/stringzilla/merge-20261022')
assert 'TEST SUCCESS' in (r/'variant-m-tests.log').read_text()
proposal=json.loads((r/'variant-m-proposal.json').read_text())
for name,v in proposal['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==v['after'],name
image=r/'images/variant-m';shutil.copytree(root/'build/stringzilla-merge/images/jdk',image)
spec=importlib.util.spec_from_file_location('support',driver/'support.py');support=importlib.util.module_from_spec(spec);spec.loader.exec_module(support)
inventory=support.image(image);old=json.loads((r/'diagnostic-l-controls.json').read_text());controls={'original':old['original'],'master':old['master'],'prior':old['candidate'],'candidate':{'image':str(image),'spec':str(root/'build/stringzilla-merge/spec.gmk'),'source':'2883aefd62a6a6cdd5e30f4f3d22049d155df938 plus variant-lm.patch','expected_tree_sha256':inventory['tree_sha256']}};controls['disabled']={**controls['candidate'],'flags':['-XX:-UseStringZillaIntrinsics']}
assert all(support.read_spec(Path(c['spec']))==support.read_spec(Path(controls['original']['spec'])) for c in controls.values())
shipped=r/'variant-m-shipped';hashes={}
for name in ['String','StringLatin1','StringUTF16','StringZilla']:
 subprocess.run([str(image/'bin/jimage'),'extract','--include','glob:**/java/lang/'+name+'.class','--dir',str(shipped),str(image/'lib/modules')],check=True)
 a=shipped/'java.base/java/lang'/(name+'.class');b=root/'build/stringzilla-merge/jdk/modules/java.base/java/lang'/(name+'.class');assert support.sha(a)==support.sha(b);hashes[name]=support.sha(a)
(r/'diagnostic-m-controls.json').write_text(json.dumps(controls,indent=2)+'\n');(r/'variant-m-image.json').write_text(json.dumps(inventory,indent=2)+'\n');(r/'variant-m-seal.json').write_text(json.dumps({'base':'2883aefd62a6a6cdd5e30f4f3d22049d155df938','patch':'variant-lm.patch','patch_sha256':support.sha(r/'variant-lm.patch'),'complete_image_tree':inventory['tree_sha256'],'shipped_classes_sha256':hashes,'matches_source_proposal_and_build_outputs':True,'controls':controls},indent=2)+'\n');print(json.dumps({'image':inventory['tree_sha256'],'source':'actual merge2883 + L + M','correctness':'full local suite TEST SUCCESS'}))
