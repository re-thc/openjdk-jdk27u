#!/usr/bin/env python3
# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Sequential ordinary JMH forks with balanced paired controls and retained raw data."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time

ROOT = Path('/workspace/openjdk-jdk27u')
JARS = Path('/workspace/stringzilla-recovery/final7048-avx2/jmh')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--controls', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--warmup', type=int, default=2)
    parser.add_argument('--samples', type=int, default=3)
    parser.add_argument('--duration', default='200ms')
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('support', ROOT/'.github/scripts/stringzilla-performance.py')
    support = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(support)
    affinity = support.pin_cpu()
    for name in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS'):
        os.environ.pop(name, None)
    controls = json.loads(args.controls.read_text())
    cases = json.loads(args.manifest.read_text())
    specifications = {name: support.read_spec(Path(data['spec'])) for name, data in controls.items()}
    assert all(value == specifications['original'] for value in specifications.values()), 'Unmatched build settings'
    assert len({c['id'] for c in cases}) == len(cases)
    inventories = {name: support.image(Path(data['image'])) for name, data in controls.items()}
    classes = args.output/'classes'
    classes.mkdir()
    jars = [JARS/n for n in ('jmh-core-1.37.jar', 'jmh-generator-annprocess-1.37.jar', 'jopt-simple-5.0.4.jar', 'commons-math3-3.6.1.jar')]
    sources = [ROOT/'test/micro/org/openjdk/bench/java/lang'/f'{n}.java' for n in ('StringZillaScans', 'StringZillaSearch', 'StringZillaLongNeedle', 'StringZillaTailSearch')]
    javac = Path(controls['original']['image'])/'bin/javac'
    subprocess.run([str(javac), '-cp', str(jars[0]), '-processorpath', os.pathsep.join(map(str,jars[:2])), '-processor', 'org.openjdk.jmh.generators.BenchmarkProcessor', '-d', str(classes), *map(str,sources)], check=True)
    cp = os.pathsep.join(map(str,[classes,jars[0],*jars[2:]]))
    write = lambda name, value: (args.output/name).write_text(json.dumps(value,indent=2)+'\n')
    provenance = {'started':time.time(),'controls':controls,'matched_build_settings':specifications,'images':inventories,'affinity':affinity,'machine':platform.platform(),'cpu':Path('/proc/cpuinfo').read_text().split('\n\n')[0], 'driver_sha256':digest(Path(__file__)),'manifest_sha256':digest(args.manifest),'cases':cases,'method':{'rounds':args.rounds,'forks':1,'warmup_iterations':args.warmup,'measurement_iterations':args.samples,'iteration_duration':args.duration,'order':'rotating control order; every position once when rounds equal control count','summary':'median of paired round-median ratios; all samples and losses retained'},'benchmark_sources':{str(p.relative_to(ROOT)):digest(p) for p in sources},'harness':{str(p):digest(p) for p in jars},'compiled_harness':{str(p.relative_to(classes)):digest(p) for p in classes.rglob('*') if p.is_file()}}
    write('provenance.json',provenance)
    names = list(controls)
    results = []
    for ci,case in enumerate(cases):
        rounds=[]
        for repeat in range(args.rounds):
            group={}
            order=names[(ci+repeat)%len(names):]+names[:(ci+repeat)%len(names)]
            for name in order:
                control=controls[name]
                java=Path(control['image'])/'bin/java'
                flags=['-Xms256m','-Xmx256m','-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xshare:off',f'-XX:UseAVX={case.get("avx",2)}',*{'c2':['-XX:-TieredCompilation'],'c1':['-XX:TieredStopAtLevel=1'],'interpreter':['-Xint']}[case.get('tier','c2')],*control.get('flags',[])]
                stem=f'{case["id"]}-r{repeat}-{name}'
                target=(args.output/(stem+'.json')).resolve()
                benchmark=case['benchmark'] if case['benchmark'].startswith('org.openjdk.') else 'org.openjdk.bench.java.lang.'+case['benchmark']
                argv=[str(java),*flags,'-cp',cp,'org.openjdk.jmh.Main',benchmark+'$',*[v for key,value in case['params'].items() for v in ('-p',key+'='+str(value))],'-f','1','-wi',str(args.warmup),'-w',args.duration,'-i',str(args.samples),'-r',args.duration,'-foe','true','-jvm',str(java),'-jvmArgs',' '.join(flags),'-rf','json','-rff',str(target)]
                with (args.output/(stem+'.log')).open('w') as log:
                    subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
                data=json.loads(target.read_text());assert len(data)==1;data=data[0]
                assert data['params']=={k:str(v) for k,v in case['params'].items()}
                assert data['jvmArgs']==flags and Path(data['jvm']).resolve()==java.resolve()
                assert data['forks']==1 and data['warmupIterations']==args.warmup and data['measurementIterations']==args.samples
                metric=data['primaryMetric'];raw=metric['rawData'];assert len(raw)==1 and len(raw[0])==args.samples and metric['scoreUnit']=='ns/op'
                assert all(math.isfinite(v) and v>0 for v in raw[0])
                group[name]={'median':statistics.median(raw[0]),'mean':metric['score'],'error':metric['scoreError'],'samples':raw[0],'file':target.name,'sha256':digest(target),'command':argv}
            rounds.append(group)
        reference='candidate' if 'candidate' in names else names[-1]
        ratios={n:[r[n]['median']/r[reference]['median'] for r in rounds] for n in names if n!=reference}
        result={'case':case,'reference':reference,'rounds':rounds,'medians':{n:statistics.median(r[n]['median'] for r in rounds) for n in names},'paired':{n:{'median':statistics.median(v),'min':min(v),'max':max(v),'ratios':v} for n,v in ratios.items()}}
        results.append(result);write('results.json',results)
        print(json.dumps({k:v for k,v in result.items() if k!='rounds'}),flush=True)
    for name,data in controls.items():
        assert support.image(Path(data['image']))['files']==inventories[name]['files'],name
    assert digest(args.manifest)==provenance['manifest_sha256']
    write('complete.json',{'cases':len(results),'rounds':args.rounds,'jmh_files':len(results)*args.rounds*len(names),'samples':len(results)*args.rounds*len(names)*args.samples,'images_unchanged':True,'completed':time.time()})


if __name__=='__main__':
    main()
