package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaScans_Whitespace_jmhType extends StringZillaScans_Whitespace_jmhType_B3 {
}

