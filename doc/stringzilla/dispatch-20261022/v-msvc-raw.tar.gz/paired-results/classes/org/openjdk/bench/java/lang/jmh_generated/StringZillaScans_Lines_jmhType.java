package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaScans_Lines_jmhType extends StringZillaScans_Lines_jmhType_B3 {
}

