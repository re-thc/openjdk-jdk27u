package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaScans_jmhType extends StringZillaScans_jmhType_B3 {
}

