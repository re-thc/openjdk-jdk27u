package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaSearch_jmhType extends StringZillaSearch_jmhType_B3 {
}

