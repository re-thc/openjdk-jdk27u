package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaLongNeedle_jmhType extends StringZillaLongNeedle_jmhType_B3 {
}

