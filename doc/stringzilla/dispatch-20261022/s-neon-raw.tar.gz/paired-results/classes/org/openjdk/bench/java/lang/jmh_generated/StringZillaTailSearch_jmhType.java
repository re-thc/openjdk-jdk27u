package org.openjdk.bench.java.lang.jmh_generated;
public class StringZillaTailSearch_jmhType extends StringZillaTailSearch_jmhType_B3 {
}

