# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Bind each StringZilla jtreg description to its outer result and CI job."""
from pathlib import Path
import json
import re
import sys

root = Path(__file__).resolve().parent
summary = json.loads((root / 'ci7048-test-summary.json').read_text())
expected = {'linux-x64': ('x64', 14), 'linux-aarch64': ('arm', 11), 'windows-x64': ('windows', 14), 'macos-aarch64': ('macos', 11)}
for platform, (label, count) in expected.items():
    groups = [r for r in summary['records'] if r['name'].startswith(platform + ' / test (')]
    tests = []
    for group in groups:
        assert group['conclusion'] == 'success' and group['checkout_verified']
        current = None
        text = (root / f"ci7048-test-{group['job_id']}.log").read_text()
        for line in text.splitlines():
            start = re.match(r'^\S+Z\s+TEST: (.+)$', line)
            if start:
                current = start[1]
            result = re.match(r'^\S+Z\s+TEST RESULT: (.+)$', line)
            if result:
                if current and 'StringZilla' in current:
                    assert result[1].startswith('Passed.'), (platform, current, result[1])
                    tests.append({'test': current, 'result': result[1], 'job_id': group['job_id']})
                current = None
    assert len({t['test'] for t in tests}) == len(tests), (platform, 'duplicate description')
    complete = len(groups) == 12
    if complete:
        assert len(tests) == count, (platform, len(tests), count)
    if '--require-complete' in sys.argv:
        assert complete, (platform, 'test groups incomplete')
    output = {'merge_checkout': summary['merge_checkout'], 'product_head': summary['product_head'], 'passed_descriptions': len(tests), 'collected_tier1_groups': len(groups), 'platform_tier1_complete': complete, 'tests': tests}
    (root / f'ci7048-stringzilla-{label}.json').write_text(json.dumps(output, indent=2) + '\n')
    print(platform, 'collected groups', len(groups), 'passed StringZilla descriptions', len(tests), 'complete', complete)
