# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Refresh verified local CI metadata and audit already collected logs."""
from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
run = json.loads(max(root.glob('ci7048-app-read-*-run.json')).read_text())
latest_jobs = json.loads(max(root.glob('ci7048-app-read-*-jobs.json')).read_text())
assert run['id'] == 39280914015
assert run['head_sha'] == '7048d6f2c74e25737850789812da063900ec18c0'
assert latest_jobs['total_count'] == len(latest_jobs['jobs']) == 57
jobs = latest_jobs
provenance = []
if run.get('run_attempt', 1) > 1:
    original = json.loads((root / 'ci7048-attempt1-terminal-jobs.json').read_text())
    by_name = {j['name']: j for j in original['jobs']}
    assert len(by_name) == 57 and {j['name'] for j in latest_jobs['jobs']} == set(by_name)
    effective = []
    for job in latest_jobs['jobs']:
        prior = by_name[job['name']]
        carried = prior['conclusion'] == 'success'
        if carried:
            assert job['conclusion'] == 'success'
            for field in ('name', 'started_at', 'completed_at', 'runner_id', 'runner_name', 'steps', 'labels', 'head_sha'):
                assert job.get(field) == prior.get(field), (job['name'], field, 'carried-forward metadata changed')
            record = dict(prior)
        else:
            assert prior['conclusion'] == 'cancelled' and prior['runner_id'] == 0 and not prior['steps']
            record = dict(job)
        record['latest_job_id'] = job['id']
        record['latest_run_attempt'] = run['run_attempt']
        record['evidence_kind'] = 'original successful execution carried forward' if carried else 'recovery execution of unstarted cancelled job'
        effective.append(record)
        provenance.append({'name': job['name'], 'latest_job_id': job['id'], 'evidence_job_id': record['id'], 'evidence_run_attempt': record.get('run_attempt', 1), 'latest_run_attempt': run['run_attempt'], 'evidence_kind': record['evidence_kind'], 'original_job_id': prior['id'], 'original_conclusion': prior['conclusion']})
    assert sum(r['original_conclusion'] == 'success' for r in provenance) == 52
    jobs = {'total_count': 57, 'view': 'Execution-provenance view; original successful job IDs retain their original logs. Raw latest API data is ci7048-latest-jobs.json.', 'jobs': effective}
for name, data in (('ci7048-current-run.json', run), ('ci7048-latest-jobs.json', latest_jobs), ('ci7048-progress-jobs.json', jobs), ('ci7048-job-provenance.json', {'run_id': run['id'], 'run_attempt': run.get('run_attempt', 1), 'carried_forward_successful_jobs': 52 if provenance else 0, 'recovery_jobs': 5 if provenance else 0, 'records': provenance})):
    (root / name).write_text(json.dumps(data, indent=2) + '\n')
for script in ('audit-ci7048.py', 'audit-ci7048-stringzilla.py'):
    subprocess.run([sys.executable, str(root / script)], check=True, stdout=subprocess.DEVNULL)
summary = json.loads((root / 'ci7048-test-summary.json').read_text())
print(json.dumps({'verified_tier1_groups': summary['collected_test_groups'], 'counts': summary['collected_jtreg_counts']}))
selected = {int(value) for value in sys.argv[1:]}
for record in summary['records']:
    if record['job_id'] in selected:
        print(json.dumps(record, indent=2))
