CI recovery checkpoint: seven successful macOS tier1 job logs and combined execution metadata.
Attempt 1 ended with 52 successful jobs and five cancellations before runner assignment.
GitHub accepted recovery of failed jobs in the same run after the original attempt completed.
The latest view assigns the 52 carried-forward successes new IDs with unchanged execution times,
runners and steps; the provenance ledger binds them to the original logs. Only the five missing
macOS jobs are queued. Carried-forward successes are not represented as new executions.
Logs are decoded UTF-8 with LF endings. Verify saved bytes using sha256sum -c SHA256SUMS.
