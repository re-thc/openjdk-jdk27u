Ordinary CI 39280914015: terminal outcome, not a passing qualification

Product source: 7048d6f2c74e25737850789812da063900ec18c0
Tested merge: 7223ef030b1de2e72bbf7eb7db81e48e2f79c965
Eight builds and 43 tier1 groups passed. Five macOS groups were cancelled with
no runners or executed steps in attempt 1 and again in the bounded recovery.
They remain unqualified. No test failure was observed in an executed group.

The latest API assigns the 52 carried-forward successes new IDs with unchanged
original execution times, runners and steps. The provenance ledger maps these
statuses to their original logs; none is counted as a new execution. Both raw
terminal attempts, the accepted recovery and the earlier state-gated refusal
are retained. No measurement campaign or successful CI job was repeated.

Verify saved bytes after extraction:
    sha256sum -c SHA256SUMS
Audit the actual executed groups using the supplied flat-directory auditors:
    cp logs/*.log metadata/
    cd metadata
    python3 audit-ci7048.py
    python3 audit-ci7048-stringzilla.py
The result must retain five missing groups and incomplete macOS qualification.
Audit reruns refresh derived timestamps; check saved checksums first.
CI logs are decoded UTF-8 text with LF endings. Original JMH bytes are retained
separately without normalization. No build, timing run or network is needed.
