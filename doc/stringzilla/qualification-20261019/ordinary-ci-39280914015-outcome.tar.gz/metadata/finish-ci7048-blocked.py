# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Retain terminal CI evidence when the bounded Mac recovery cannot allocate runners."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(root / 'refresh-ci7048.py')], check=True, stdout=subprocess.DEVNULL)
run = json.loads((root / 'ci7048-current-run.json').read_text())
latest = json.loads((root / 'ci7048-latest-jobs.json').read_text())
effective = json.loads((root / 'ci7048-progress-jobs.json').read_text())
assert run['id'] == 39280914015 and run['run_attempt'] == 2
assert run['head_sha'] == '7048d6f2c74e25737850789812da063900ec18c0'
assert run['status'] == 'completed' and run['conclusion'] == 'failure', 'Recovery is not terminal failure'
assert latest['total_count'] == effective['total_count'] == 57
assert all(j['status'] == 'completed' for j in latest['jobs'])
cancelled = [j for j in latest['jobs'] if j['conclusion'] != 'success']
assert len(cancelled) == 5
assert all(j['conclusion'] == 'cancelled' and j['runner_id'] == 0 and not j['steps'] for j in cancelled)
assert all(j['name'].startswith('macos-aarch64 / test (') for j in cancelled)
original = json.loads((root / 'ci7048-attempt1-terminal-jobs.json').read_text())
prior_cancelled = [j for j in original['jobs'] if j['conclusion'] != 'success']
assert {j['name'] for j in prior_cancelled} == {j['name'] for j in cancelled}
assert all(j['conclusion'] == 'cancelled' and j['runner_id'] == 0 and not j['steps'] for j in prior_cancelled)
summary = json.loads((root / 'ci7048-test-summary.json').read_text())
assert summary['collected_test_groups'] == 43 and len(summary['missing']) == 5
assert summary['collected_jtreg_counts']['fail'] == summary['collected_jtreg_counts']['error'] == 0
builds = json.loads((root / 'ci7048-builds-verified.json').read_text())
assert len(builds) == 8
old_linux = {118259521768: 'x64-debug', 118259521790: 'x64-release', 118259521858: 'arm-release', 118259522111: 'arm-debug'}
members = {}
logs = []
checkout = '7223ef030b1de2e72bbf7eb7db81e48e2f79c965'
for job in effective['jobs']:
    if job['conclusion'] != 'success':
        continue
    if job['name'] == 'Prepare the run':
        filename = 'ci7048-prepare.log'
    elif ' / test (' in job['name']:
        filename = f"ci7048-test-{job['id']}.log"
    elif job['id'] in old_linux:
        filename = f"ci7048-{old_linux[job['id']]}.log"
    else:
        filename = f"ci7048-build-{job['id']}.log"
    raw = (root / filename).read_bytes()
    text = raw.decode('utf-8')
    assert re.search(r'log -1 --format=%H\r?\n[^\r\n]*' + checkout + r'(?:\r?\n|$)', text), filename
    assert all(s['conclusion'] in ('success', 'skipped') for s in job['steps']), filename
    digest = hashlib.sha256(raw).hexdigest()
    if ' / build (' in job['name']:
        receipt = next(v for v in builds.values() if v['job_id'] == job['id'])
        assert receipt['checkout'] == checkout and receipt['log_sha256'] == digest
        assert receipt['bundles_passed'] and receipt['development_profile_passed']
    members['logs/' + filename] = raw
    logs.append({'name': job['name'], 'evidence_job_id': job['id'], 'latest_job_id': job['latest_job_id'], 'file_name': filename, 'bytes': len(raw), 'sha256': digest})
assert len(logs) == 52
per_platform = {}
for platform in ('linux-x64', 'linux-aarch64', 'windows-x64', 'macos-aarch64'):
    records = [r for r in summary['records'] if r['name'].startswith(platform + ' / test (')]
    per_platform[platform] = {'groups': len(records), **{k: sum(t[k] for r in records for t in r['test_tables']) for k in ('total', 'pass', 'fail', 'error', 'skip')}}
outcome = {'run_id': run['id'], 'run_attempt': 2, 'url': run['html_url'], 'status': run['status'], 'conclusion': run['conclusion'], 'product_head': run['head_sha'], 'merge_checkout': checkout, 'decision': 'NOT READY TO MERGE: five required macOS groups were cancelled without execution in both attempts. Retain the corrected implementation and measured tradeoffs, but require actual execution of these groups before readiness.', 'successful_builds': 8, 'verified_tier1_groups': 43, 'planned_tier1_groups': 48, 'successful_executions_carried_forward': 52, 'new_successful_executions_in_recovery': 0, 'cancelled_without_execution_each_attempt': 5, 'missing_groups': [{'job_id': j['id'], 'name': j['name'], 'runner_id': j['runner_id'], 'steps': j['steps'], 'completed_at': j['completed_at']} for j in cancelled], 'collected_jtreg_counts': summary['collected_jtreg_counts'], 'per_platform_jtreg_counts': per_platform, 'log_encoding': 'Decoded UTF-8 CI text saved with LF endings; digests bind saved bytes, not GitHub log ZIP bytes. Original JMH files remain separately preserved without normalization.', 'logs': logs}
for filename, value in (('ci7048-attempt2-terminal-run.json', run), ('ci7048-attempt2-terminal-jobs.json', latest), ('ci7048-outcome.json', outcome)):
    (root / filename).write_text(json.dumps(value, indent=2) + '\n')
metadata = ('ci7048-attempt1-terminal-run.json', 'ci7048-attempt1-terminal-jobs.json', 'ci7048-attempt2-terminal-run.json', 'ci7048-attempt2-terminal-jobs.json', 'ci7048-outcome.json', 'ci7048-current-run.json', 'ci7048-latest-jobs.json', 'ci7048-progress-jobs.json', 'ci7048-job-provenance.json', 'ci7048-recovery-request.json', 'ci7048-compiler1-rerun-block.json', 'ci7048-builds-verified.json', 'ci7048-test-summary.json', 'ci7048-source-provenance.json', 'ci7048-workflow-scope.json', 'ci7048-stringzilla-x64.json', 'ci7048-stringzilla-arm.json', 'ci7048-stringzilla-windows.json', 'ci7048-stringzilla-macos.json', 'audit-ci7048.py', 'audit-ci7048-stringzilla.py', 'refresh-ci7048.py', 'finish-ci7048.py', 'finish-ci7048-blocked.py')
for filename in metadata:
    members['metadata/' + filename] = (root / filename).read_bytes()
members['README.txt'] = b'''Ordinary CI 39280914015: terminal outcome, not a passing qualification

Product source: 7048d6f2c74e25737850789812da063900ec18c0
Tested merge: 7223ef030b1de2e72bbf7eb7db81e48e2f79c965
Eight builds and 43 tier1 groups passed. Five macOS groups were cancelled with
no runners or executed steps in attempt 1 and again in the bounded recovery.
They remain unqualified. No test failure was observed in an executed group.

The latest API assigns the 52 carried-forward successes new IDs with unchanged
original execution times, runners and steps. The provenance ledger maps these
statuses to their original logs; none is counted as a new execution. Both raw
terminal attempts, the accepted recovery and the earlier state-gated refusal
are retained. No measurement campaign or successful CI job was repeated.

Verify saved bytes after extraction:
    sha256sum -c SHA256SUMS
Audit the actual executed groups using the supplied flat-directory auditors:
    cp logs/*.log metadata/
    cd metadata
    python3 audit-ci7048.py
    python3 audit-ci7048-stringzilla.py
The result must retain five missing groups and incomplete macOS qualification.
Audit reruns refresh derived timestamps; check saved checksums first.
CI logs are decoded UTF-8 text with LF endings. Original JMH bytes are retained
separately without normalization. No build, timing run or network is needed.
'''
members['SHA256SUMS'] = ''.join(f'{hashlib.sha256(raw).hexdigest()}  {name}\n' for name, raw in sorted(members.items())).encode()
assert not any(re.search(rb'libfile_[0-9a-f]{32}', raw) for raw in members.values())
filename = 'ordinary-ci-39280914015-outcome.tar.gz'
with (root / filename).open('wb') as destination:
    with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(raw)
                entry.mode = 0o644
                archive.addfile(entry, io.BytesIO(raw))
raw = (root / filename).read_bytes()
receipt = {'file_name': filename, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'state': 'Terminal incomplete qualification after two allocation failures', 'run_id': run['id'], 'run_attempts': 2, 'product_head': run['head_sha'], 'merge_checkout': checkout, 'successful_builds': 8, 'verified_tier1_groups': 43, 'missing_tier1_groups': 5, 'successful_execution_log_files': 52, 'retention': 'Existing evidence branch; public GitHub CI logs and metadata only'}
(root / 'ordinary-ci-outcome-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({**receipt, 'jtreg_counts': outcome['collected_jtreg_counts'], 'per_platform': per_platform}, indent=2))
