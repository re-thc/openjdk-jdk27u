# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Audit and retain the existing ordinary CI after every planned job finishes."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
run = json.loads((root / 'ci7048-current-run.json').read_text())
jobs_document = json.loads((root / 'ci7048-progress-jobs.json').read_text())
jobs = jobs_document['jobs']
product = '7048d6f2c74e25737850789812da063900ec18c0'
checkout = '7223ef030b1de2e72bbf7eb7db81e48e2f79c965'
assert run['id'] == 39280914015 and run['head_sha'] == product
assert run['status'] == 'completed' and run['conclusion'] == 'success', 'CI is not terminal success'
assert jobs_document['total_count'] == len(jobs) == 57
assert len({j['id'] for j in jobs}) == 57
assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
platforms = ('linux-x64', 'linux-aarch64', 'macos-aarch64', 'windows-x64')
for platform in platforms:
    assert sum(j['name'].startswith(platform + ' / build (') for j in jobs) == 2
    assert sum(j['name'].startswith(platform + ' / test (') for j in jobs) == 12
assert sum(j['name'] == 'Prepare the run' for j in jobs) == 1
subprocess.run([sys.executable, str(root / 'audit-ci7048.py')], check=True, stdout=subprocess.DEVNULL)
summary = json.loads((root / 'ci7048-test-summary.json').read_text())
assert summary['collected_test_groups'] == 48 and not summary['missing']
assert not summary['test_matrices_not_yet_created']
subprocess.run([sys.executable, str(root / 'audit-ci7048-stringzilla.py'), '--require-complete'], check=True, stdout=subprocess.DEVNULL)
builds = json.loads((root / 'ci7048-builds-verified.json').read_text())
assert len(builds) == 8 and {v['job_id'] for v in builds.values()} == {j['id'] for j in jobs if ' / build (' in j['name']}
old_linux = {118259521768: 'x64-debug', 118259521790: 'x64-release', 118259521858: 'arm-release', 118259522111: 'arm-debug'}
members = {}
log_receipts = []
for job in jobs:
    if job['name'] == 'Prepare the run':
        filename = 'ci7048-prepare.log'
    elif ' / test (' in job['name']:
        filename = f"ci7048-test-{job['id']}.log"
    elif job['id'] in old_linux:
        filename = f"ci7048-{old_linux[job['id']]}.log"
    else:
        filename = f"ci7048-build-{job['id']}.log"
    raw = (root / filename).read_bytes()
    text = raw.decode('utf-8')
    assert re.search(r'log -1 --format=%H\r?\n[^\r\n]*' + checkout + r'(?:\r?\n|$)', text), filename
    assert all(s['conclusion'] in ('success', 'skipped') for s in job['steps']), filename
    digest = hashlib.sha256(raw).hexdigest()
    if ' / build (' in job['name']:
        receipt = next(v for v in builds.values() if v['job_id'] == job['id'])
        assert receipt['checkout'] == checkout and receipt['log_sha256'] == digest
        assert receipt['bundles_passed'] and receipt['development_profile_passed']
    members['logs/' + filename] = raw
    log_receipts.append({'job_id': job['id'], 'name': job['name'], 'file_name': filename, 'bytes': len(raw), 'sha256': digest, 'conclusion': job['conclusion']})
per_platform = {}
for platform in platforms:
    records = [r for r in summary['records'] if r['name'].startswith(platform + ' / test (')]
    per_platform[platform] = {k: sum(t[k] for r in records for t in r['test_tables']) for k in ('total', 'pass', 'fail', 'error', 'skip')}
verified = {'run_id': run['id'], 'url': run['html_url'], 'status': run['status'], 'conclusion': run['conclusion'], 'product_head': product, 'merge_checkout': checkout, 'merge_tree': '24902b9f60588f92eae068395545e40d9440f78d', 'successful_jobs': 57, 'successful_builds': 8, 'successful_tier1_groups': 48, 'collected_jtreg_counts': summary['collected_jtreg_counts'], 'per_platform_jtreg_counts': per_platform, 'log_encoding': 'Decoded UTF-8 job-log text from the connected GitHub action, with LF line endings after patch materialization. Digests bind these saved log bytes, not the downloadable GitHub log ZIP. Original JMH measurement file bytes are retained separately without normalization.', 'logs': log_receipts}
final_files = {'ci7048-final-run.json': run, 'ci7048-final-jobs.json': jobs_document, 'ci7048-final-verified.json': verified}
for filename, data in final_files.items():
    (root / filename).write_text(json.dumps(data, indent=2) + '\n')
metadata = ('ci7048-final-run.json', 'ci7048-final-jobs.json', 'ci7048-final-verified.json', 'ci7048-current-run.json', 'ci7048-progress-jobs.json', 'ci7048-latest-jobs.json', 'ci7048-job-provenance.json', 'ci7048-attempt1-terminal-run.json', 'ci7048-attempt1-terminal-jobs.json', 'ci7048-recovery-request.json', 'ci7048-compiler1-rerun-block.json', 'ci7048-builds-verified.json', 'ci7048-test-summary.json', 'ci7048-source-provenance.json', 'ci7048-workflow-scope.json', 'ci7048-stringzilla-x64.json', 'ci7048-stringzilla-arm.json', 'ci7048-stringzilla-windows.json', 'ci7048-stringzilla-macos.json', 'audit-ci7048.py', 'audit-ci7048-stringzilla.py', 'refresh-ci7048.py', 'finish-ci7048.py')
for filename in metadata:
    members['metadata/' + filename] = (root / filename).read_bytes()
members['README.txt'] = b'''Ordinary CI 39280914015: saved evidence and independent audit

Product source: 7048d6f2c74e25737850789812da063900ec18c0
Tested PR merge: 7223ef030b1de2e72bbf7eb7db81e48e2f79c965
This archive contains all 57 successful job logs, run/job metadata, source
bindings and derived test tables. CI logs are decoded UTF-8 text saved with LF
line endings; their digests do not represent GitHub's downloadable log ZIP.
Original JMH measurement file bytes are retained separately without normalization.

Attempt 1 supplied 52 successful executions. Five macOS jobs were cancelled
before runner assignment. After that attempt completed, GitHub accepted a
failed-job-only recovery in the same run. Its latest view gives carried-forward
successes new job IDs with unchanged original execution times, runners and steps.
ci7048-job-provenance.json binds those 52 statuses to their original logs and the
five recovered jobs to their actual executions. No carried-forward job is
represented as newly executed. Raw latest API jobs and the original terminal
attempt are both retained; ci7048-progress-jobs.json is the explicit execution
provenance view used for auditing. Head and tested merge remain unchanged.

After extracting this archive into an empty directory, verify its saved bytes:
    sha256sum -c SHA256SUMS
Then copy the logs beside the metadata for the supplied flat-directory auditors:
    cp logs/*.log metadata/
    cd metadata
    python3 audit-ci7048.py
    python3 audit-ci7048-stringzilla.py --require-complete
The first audit checks full checkout SHAs, completed job/step conclusions,
test-success markers, canonical failed results and make test-table invariants.
The second binds every StringZilla test description to its outer passed result.
Audit reruns refresh derived summary timestamps; verify saved checksums first.
No network access, build, timing run or additional dependency is required.
'''
members['SHA256SUMS'] = ''.join(f'{hashlib.sha256(raw).hexdigest()}  {name}\n' for name, raw in sorted(members.items())).encode()
filename = 'ordinary-ci-39280914015-complete.tar.gz'
with (root / filename).open('wb') as destination:
    with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(raw)
                entry.mode = 0o644
                archive.addfile(entry, io.BytesIO(raw))
raw = (root / filename).read_bytes()
receipt = {'file_name': filename, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'state': 'Complete successful ordinary merge-integration CI', 'run_id': run['id'], 'product_head': product, 'merge_checkout': checkout, 'completed_builds': 8, 'completed_tier1_groups': 48, 'log_files': 57, 'retention': 'Existing evidence branch; public GitHub CI decoded logs and validation metadata only'}
(root / 'ordinary-ci-complete-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({**receipt, 'jtreg_counts': verified['collected_jtreg_counts'], 'per_platform': per_platform}, indent=2))
