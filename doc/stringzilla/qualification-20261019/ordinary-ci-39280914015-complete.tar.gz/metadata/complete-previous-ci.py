# Copyright (c) 2026, Teamoffy Pte. Ltd. All rights reserved.
"""Reconcile the original 52 successful executions with five actual attempt-3 runs."""
from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile,gzip

root=Path(__file__).resolve().parent
prior=root.parent
raw=json.loads((root/'ci7048-attempt3-jobs.json').read_text())
run=json.loads((root/'ci7048-attempt3-run.json').read_text())
old=json.loads((prior/'ci7048-attempt1-terminal-jobs.json').read_text())
assert run['run_attempt']==3 and run['conclusion']=='success' and run['status']=='completed'
assert len(raw['jobs'])==57 and all(j['conclusion']=='success' for j in raw['jobs'])
by_name={j['name']:j for j in old['jobs']}
view=[]; ledger=[]
for job in raw['jobs']:
    old_job=by_name[job['name']]
    if old_job['conclusion']=='success':
        for field in ('started_at','completed_at','runner_id','runner_name','steps','head_sha','labels'):
            assert old_job[field]==job[field],(job['name'],field)
        evidence=dict(old_job);kind='carried original execution'
    else:
        assert job['runner_id']>0 and len(job['steps'])>0
        evidence=dict(job);kind='new execution in attempt 3'
    evidence['latest_job_id']=job['id'];evidence['evidence_kind']=kind
    view.append(evidence);ledger.append({'name':job['name'],'evidence_job_id':evidence['id'],'latest_job_id':job['id'],'kind':kind})
assert sum(r['kind']=='carried original execution' for r in ledger)==52
receipt=json.loads((prior/'ordinary-ci-outcome-archive.json').read_text())
archive=prior/receipt['file_name'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['sha256']
with tarfile.open(archive) as t:
    for member in t.getmembers():
        if member.name.startswith('logs/') and member.isfile():
            (root/Path(member.name).name).write_bytes(t.extractfile(member).read())
for script in ('audit-ci7048.py','audit-ci7048-stringzilla.py'):
    shutil.copyfile(prior/script,root/script)
(root/'ci7048-progress-jobs.json').write_text(json.dumps({'total_count':57,'view':'Attempt 3 execution provenance; original successful IDs retain original logs','jobs':view},indent=2)+'\n')
(root/'ci7048-attempt3-provenance.json').write_text(json.dumps(ledger,indent=2)+'\n')
for command in (['python3','audit-ci7048.py'],['python3','audit-ci7048-stringzilla.py','--require-complete']):
    subprocess.run(command,cwd=root,check=True,stdout=subprocess.DEVNULL)
summary=json.loads((root/'ci7048-test-summary.json').read_text())
assert summary['collected_test_groups']==48 and summary['missing']==[]
outcome={'run_id':run['id'],'run_attempt':3,'status':run['status'],'conclusion':run['conclusion'],'product_head':run['head_sha'],'merge_checkout':summary['merge_checkout'],'successful_builds':8,'verified_tier1_groups':48,'missing_tier1_groups':0,'carried_original_successful_executions':52,'newly_executed_groups':5,'counts':summary['collected_jtreg_counts'],'decision':'Previous five-group execution blocker is removed for product7048. Later combined implementations require their own qualification.','log_encoding':'Saved decoded UTF-8 CI logs with LF endings, not original GitHub ZIP bytes.'}
(root/'ci7048-attempt3-success.json').write_text(json.dumps(outcome,indent=2)+'\n')
members={}
for log in root.glob('ci7048-*.log'):members['logs/'+log.name]=log.read_bytes()
assert len(members)==57
for name in ('ci7048-attempt3-run.json','ci7048-attempt3-jobs.json','ci7048-progress-jobs.json','ci7048-attempt3-provenance.json','ci7048-test-summary.json','ci7048-attempt3-success.json','ci7048-stringzilla-x64.json','ci7048-stringzilla-arm.json','ci7048-stringzilla-windows.json','ci7048-stringzilla-macos.json','audit-ci7048.py','audit-ci7048-stringzilla.py','complete-previous-ci.py'):
    members['metadata/'+name]=(root/name).read_bytes()
members['README.txt']=b'Product7048 ordinary CI succeeds in attempt 3. All 8 builds and 48 tier1 groups pass.\n52 original successful executions are carried forward; five Mac groups actually execute in attempt 3.\nVerify SHA256SUMS before running auditors. To audit: copy logs/*.log to metadata/, then run\npython3 audit-ci7048.py and python3 audit-ci7048-stringzilla.py --require-complete in metadata/.\nCI log digests bind saved decoded UTF-8 text with LF endings. JMH data remains separately retained.\nThis qualifies merge7223 of product7048, not any later PR63 integration or fixes.\n'
members['SHA256SUMS']=''.join(f'{hashlib.sha256(data).hexdigest()}  {name}\n' for name,data in sorted(members.items())).encode()
target=root/'ordinary-ci-39280914015-complete.tar.gz'
with target.open('wb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as z:
        with tarfile.open(fileobj=z,mode='w') as t:
            for name,data in sorted(members.items()):
                entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;t.addfile(entry,io.BytesIO(data))
receipt={'file_name':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'successful_logs':57,'verified_groups':48,'attempt':3}
(root/'ordinary-ci-complete-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'outcome':outcome,'archive':receipt},indent=2))
