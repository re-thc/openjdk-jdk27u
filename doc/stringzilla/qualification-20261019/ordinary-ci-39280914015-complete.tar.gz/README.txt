Product7048 ordinary CI succeeds in attempt 3. All 8 builds and 48 tier1 groups pass.
52 original successful executions are carried forward; five Mac groups actually execute in attempt 3.
Verify SHA256SUMS before running auditors. To audit: copy logs/*.log to metadata/, then run
python3 audit-ci7048.py and python3 audit-ci7048-stringzilla.py --require-complete in metadata/.
CI log digests bind saved decoded UTF-8 text with LF endings. JMH data remains separately retained.
This qualifies merge7223 of product7048, not any later PR63 integration or fixes.
