from pathlib import Path
import datetime,hashlib,json,re
root=Path(__file__).resolve().parent
jobs=json.loads((root/'ci7048-progress-jobs.json').read_text())['jobs']
records=[]
missing=[]
for job in jobs:
    if ' / test (' not in job['name']:
        continue
    logfile=root/f"ci7048-test-{job['id']}.log"
    if not logfile.exists():
        missing.append({'job_id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion']})
        continue
    raw=logfile.read_bytes()
    text=raw.decode('utf-8')
    tables=[]
    for m in re.finditer(r'^\S+Z\s+(jtreg:\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$',text,re.M):
        row=dict(zip(('suite','total','pass','fail','error','skip'),[m[1]]+[int(m[i]) for i in range(2,7)]))
        assert row['total']==sum(row[k] for k in ('pass','fail','error','skip'))
        assert row not in tables, 'Duplicate table; inspect before summing'
        tables.append(row)
    records.append({'job_id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'started_at':job['started_at'],'completed_at':job['completed_at'],'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest(),'checkout_verified':bool(re.search(r'log -1 --format=%H\r?\n[^\r\n]*7223ef030b1de2e72bbf7eb7db81e48e2f79c965(?:\r?\n|$)',text)),'test_result_summaries':re.findall(r'Test results: ([^\r\n]+)',text),'test_tables':tables,'test_success_marker':'TEST SUCCESS' in text,'canonical_failed_results':re.findall(r'TEST RESULT: ((?:Failed|Error)[^\r\n]*)',text),'step_failures':[v for v in job['steps'] if v['conclusion'] not in ('success','skipped',None)]})
for r in records:
    if r['conclusion']=='success':
        assert r['checkout_verified'] and r['test_success_marker'] and r['test_tables'] and not r['canonical_failed_results'] and not r['step_failures']
        assert all(t['fail']==t['error']==0 for t in r['test_tables'])
totals={k:sum(t[k] for r in records for t in r['test_tables']) for k in ('total','pass','fail','error','skip')}
result={'job_metadata_observed_at':datetime.datetime.fromtimestamp((root/'ci7048-progress-jobs.json').stat().st_mtime,datetime.timezone.utc).isoformat(),'run_id':39280914015,'product_head':'7048d6f2c74e25737850789812da063900ec18c0','merge_checkout':'7223ef030b1de2e72bbf7eb7db81e48e2f79c965','planned_linux_test_groups':24,'planned_total_test_groups':48,'created_build_jobs':sum(' / build (' in x['name'] for x in jobs),'test_matrices_not_yet_created':[n for n in ('linux-x64','linux-aarch64','macos-aarch64','windows-x64') if not any(x['name'].startswith(n+' / test (') for x in jobs)],'configured_stage_gate':'macOS/Windows builds follow successful Linux matrices;their tests follow their builds','created_test_groups':len(records)+len(missing),'collected_test_groups':len(records),'missing':missing,'collected_jtreg_counts':totals,'records':records}
(root/'ci7048-test-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('records','missing')},indent=2))
for r in records: print(r['job_id'],r['name'],r['conclusion'],r['test_result_summaries'])
