#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/archive-mirrors
while [[ ! -f $root/release-native-build.finished ]]; do sleep 5; done
[[ $(cat "$root/release-native-build.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
python3 - <<'PYIMAGE'
from pathlib import Path
import shutil
root=Path('/workspace/work/archive-mirrors')
shutil.copytree(Path('/workspace/work/final-default/release-image'),root/'hypothesis-image',symlinks=True)
shutil.copy2(Path('build/cloud-gcc16/support/modules_libs/java.base/server/libjvm.so'),root/'hypothesis-image/lib/server/libjvm.so')
PYIMAGE
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$root/hypothesis-image" -w:"$root/after/work" -r:"$root/after/report" -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:-Xmx512m test/hotspot/jtreg/runtime/cds/FourByteHeaderArchiveDeterminism.java test/hotspot/jtreg/runtime/cds/DeterministicDump.java > "$root/after.log" 2>&1
printf '0\n' > "$root/after.finished"
