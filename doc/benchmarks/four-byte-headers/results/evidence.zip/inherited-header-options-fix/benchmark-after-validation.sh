#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-options
while [[ ! -f $root/build-and-validate.finished ]]; do sleep 5; done
[[ $(cat "$root/build-and-validate.finished") == 0 ]]
while [[ ! -f $root/jdk-ci-followup.finished ]]; do sleep 5; done
[[ $(cat "$root/jdk-ci-followup.finished") == 0 ]]
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('/workspace/work/final-options')
for flavor in ['release','fastdebug']:
 p=root/(flavor+'-objects.tar.gz')
 assert p.is_file() and p.stat().st_size > 100_000_000
 Path('/workspace/work/final-copy', flavor+'-objects.tar.gz').unlink()
free=shutil.disk_usage('/workspace').free
if free < 9_000_000_000:
 # The superseded immutable images have finished all their runs. Preserve
 # their manifests and logs; keep only the validated latest runtime images.
 for flavor in ['release','fastdebug']:
  p=Path('/workspace/work/final-copy', flavor+'-image')
  if p.exists():shutil.rmtree(p)
 free=shutil.disk_usage('/workspace').free
print('Free bytes before final benchmarks:', free)
assert free >= 9_000_000_000, 'Clean completed generated artifacts before starting timings'
PY
bash "$root/run-final-benchmarks.sh" > "$root/benchmark-driver.log" 2>&1
printf '0\n' > "$root/benchmark-driver.finished"
