#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-options
while [[ ! -f $root/build-and-validate.finished ]]; do sleep 5; done
[[ $(cat "$root/build-and-validate.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
for layout in baseline8 default4; do
  image=/workspace/work/baseline/image
  [[ $layout != default4 ]] || image=$root/release-image
  set +e
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
    /workspace/toolchains/jtreg83/bin/jtreg \
    -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
    -jdk:"$image" -w:"$root/jdk-ci-before-$layout/work" \
    -r:"$root/jdk-ci-before-$layout/report" -automatic -conc:1 \
    -timeoutFactor:4 -verbose:summary \
    test/jdk/jdk/jfr/event/oldobject/TestDFSWithSmallStack.java \
    test/jdk/java/lang/String/CompactString/MaxSizeUTF16String.java \
    test/jdk/tools/jlink/plugins/CDSPluginTest.java \
    > "$root/jdk-ci-before-$layout.log" 2>&1
  result=$?
  set -e
  printf '%s\n' "$result" > "$root/jdk-ci-before-$layout.finished"
  set +e
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
    /workspace/toolchains/jtreg83/bin/jtreg \
    -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
    -jdk:"$image" -w:"$root/hotspot-ci-before-$layout/work" \
    -r:"$root/hotspot-ci-before-$layout/report" -automatic -conc:1 \
    -timeoutFactor:4 -verbose:summary \
    test/hotspot/jtreg/runtime/cds/appcds/dynamicArchive/TestAutoCreateSharedArchiveNoDefaultArchive.java \
    > "$root/hotspot-ci-before-$layout.log" 2>&1
  result=$?
  set -e
  printf '%s\n' "$result" > "$root/hotspot-ci-before-$layout.finished"
done
printf '0\n' > "$root/jdk-ci-controls.finished"
