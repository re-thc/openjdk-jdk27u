#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-options
[[ $(cat "$root/build-and-validate.finished") == 0 ]]
[[ $(cat "$root/jdk-ci-controls.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
source /workspace/toolchains/activate.sh
for flavor in release fastdebug; do
  conf=cloud-gcc16
  [[ $flavor != fastdebug ]] || conf=fourbyte-fastdebug
  for target in jdk.jlink-java-only jdk.jlink-jmod-only java.base-jmod-only jdk-image-only; do
    JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
      make CONF="$conf" JOBS=4 "$target" >> "$root/$flavor-jlink-build.log" 2>&1
  done
  python3 - "$conf" "$flavor" <<'PY'
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
conf,flavor=sys.argv[1:]
root=Path('/workspace/work/final-options')
source=Path('build')/conf/'images/jdk';dest=root/(flavor+'-image')
p=root/'manifest.json';data=json.loads(p.read_text())
key='default4-'+flavor
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source/'lib/server/libjvm.so') == data['images'][key]['libjvm_sha256']
shutil.rmtree(dest)
shutil.copytree(source,dest,symlinks=True,ignore=shutil.ignore_patterns('*.debuginfo'))
assert sha(dest/'lib/server/libjvm.so') == data['images'][key]['libjvm_sha256']
data['native_revision']='de7be9cb9954b58b07e5405b6410a8451c8acee0'
data['source_revision']=data['validation_revision']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
data['images'][key]['modules_sha256']=sha(dest/'lib/modules')
data['jlink_archive_fix']='Generate and force-load all six header/oop variants, including explicit eight-byte opt-out archives.'
p.write_text(json.dumps(data,indent=2)+'\n')
shutil.rmtree(source)
PY
done
printf '0\n' > "$root/jlink-images.finished"
