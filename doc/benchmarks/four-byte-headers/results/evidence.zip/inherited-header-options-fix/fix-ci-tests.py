from pathlib import Path

root = Path('/workspace/work/final-options')
assert (root / 'jdk-ci-controls.finished').read_text().strip() == '0'
repo = Path('/workspace/openjdk-jdk27u')

p = repo / 'test/jdk/java/lang/String/CompactString/MaxSizeUTF16String.java'
s = p.read_text().replace('2023, 2025', '2023, 2026')
s = s.replace('import java.nio.charset.StandardCharsets;',
              'import java.nio.charset.StandardCharsets;\nimport jdk.internal.misc.Unsafe;')
s = s.replace(' * @requires vm.flagless\n',
              ' * @requires vm.flagless\n * @modules java.base/jdk.internal.misc\n')
s = s.replace('        int min = Integer.MAX_VALUE / bytes1.length - 1;',
'''        // With the default eight-byte object alignment, the VM reserves the
        // byte-array header rounded up to a machine word from its length limit.
        // Four-byte object headers permit one more byte than other layouts.
        int headerWords = (Unsafe.ARRAY_BYTE_BASE_OFFSET + Unsafe.ADDRESS_SIZE - 1)
                          / Unsafe.ADDRESS_SIZE;
        int maxByteArrayLength = Integer.MAX_VALUE - headerWords;
        int min = maxByteArrayLength / bytes1.length;''')
s = s.replace('        int remaining = Integer.MAX_VALUE - bytes.length;\n        assertTrue(remaining >= bytes1.length, "remainder too large: " + remaining);',
'''        assertEquals(min * bytes1.length, bytes.length);
        int remaining = maxByteArrayLength - bytes.length;
        assertTrue(remaining >= 0 && remaining < bytes1.length,
                   "unexpected remainder: " + remaining);''')
p.write_text(s)

p = repo / 'test/hotspot/jtreg/runtime/cds/appcds/dynamicArchive/TestAutoCreateSharedArchiveNoDefaultArchive.java'
s = p.read_text().replace('2022, 2025', '2022, 2026')
s = s.replace('''        removeDefaultArchive(java_home_dst, variant, "");
        removeDefaultArchive(java_home_dst, variant, "_nocoops");
        removeDefaultArchive(java_home_dst, variant, "_coh");''',
'''        for (String suffix : new String[] { "", "_nocoops", "_nocoh", "_nocoops_nocoh",
                                           "_fourbyte", "_nocoops_fourbyte" }) {
            removeDefaultArchive(java_home_dst, variant, suffix);
        }''')
p.write_text(s)

p = repo / 'test/jdk/tools/jlink/plugins/CDSPluginTest.java'
s = p.read_text().replace('import java.io.File;',
                          'import java.io.File;\nimport java.util.ArrayList;\nimport java.util.List;')
s = s.replace('''                      new String[] { subDir + "classes" + suffix, subDir + "classes_nocoops" + suffix});''',
'''                      new String[] { subDir + "classes.jsa", subDir + "classes_nocoops.jsa",
                                     subDir + "classes_nocoh.jsa", subDir + "classes_nocoops_nocoh.jsa",
                                     subDir + "classes_fourbyte.jsa", subDir + "classes_nocoops_fourbyte.jsa" });
            // Force archive loading for every supported header/oop combination.
            // Merely finding files would miss archives that cannot be mapped.
            for (String layout : new String[] { "eight", "legacy", "four" }) {
                for (boolean coops : new boolean[] { true, false }) {
                    List<String> command = new ArrayList<>();
                    command.add(image.resolve("bin").resolve(Platform.isWindows() ? "java.exe" : "java").toString());
                    command.add("-Xshare:on");
                    command.add("-XX:" + (layout.equals("four") ? "+" : "-") + "UseFourByteObjectHeaders");
                    command.add("-XX:" + (layout.equals("legacy") ? "-" : "+") + "UseCompactObjectHeaders");
                    command.add("-XX:" + (coops ? "+" : "-") + "UseCompressedOops");
                    command.add("-version");
                    ProcessTools.executeProcess(new ProcessBuilder(command))
                                .shouldHaveExitValue(0)
                                .shouldContain("sharing");
                }
            }''')
p.write_text(s)
