"""Publish measurements with exact-image validation and honest broad-run status."""
import csv
import json
from pathlib import Path
import re
import shutil

root = Path('/workspace/work/final-options')
dest = Path('/workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/results')
for name in ['build-and-validate.finished', 'final-validation.finished',
             'ci-followup.finished', 'jcstress.finished', 'benchmarks.finished']:
    assert (root / name).read_text().strip() == '0', name
with (root / 'default-focused-results.csv').open() as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 117 and all(r['status'].startswith('Passed.') for r in rows)
followup = []
for flavor in ['release', 'fastdebug']:
    for layout in ['default4', 'eight8', 'legacy12']:
        reports = sorted((root / f'ci-followup-{flavor}-{layout}/work').rglob('*.jtr'))
        assert len(reports) == 5, (flavor, layout, len(reports))
        for report in reports:
            fields = {}
            for line in report.read_text(errors='replace').splitlines():
                if line.startswith(('test=', 'execStatus=', 'totalTime=')):
                    key, value = line.split('=', 1)
                    fields[key] = re.sub(r'\\(.)', r'\1', value)
            assert fields['execStatus'].startswith('Passed.'), (report, fields)
            followup.append([flavor, layout, fields['test'], fields['execStatus'], fields.get('totalTime', '')])
with (root / 'ci-followup-results.csv').open('w') as f:
    w = csv.writer(f, lineterminator='\n')
    w.writerow(['flavor', 'layout', 'test', 'status', 'total_time'])
    w.writerows(followup)
p = root / 'manifest.json'
data = json.loads(p.read_text())
assert data['source_revision'] == 'de7be9cb9954b58b07e5405b6410a8451c8acee0'
data['additional_ci_regression_cases_passed'] = len(followup)
data['broad_validation'] = 'Final x64/AArch64, three-layout tier1/tier2 GitHub Actions matrix; superseded local 4d9 run retained as incomplete diagnostic evidence.'
p.write_text(json.dumps(data, indent=2) + '\n')
applications = dest / 'applications'
applications.mkdir(parents=True, exist_ok=True)
for path in sorted((root / 'results').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.csv', '.sql'}:
        shutil.copy2(path, applications / path.name)
for name in ['manifest.json', 'ci-followup-results.csv']:
    shutil.copy2(root / name, applications / name)
shutil.copy2(root / 'typical-tables.md', applications / 'summary.md')
shutil.copy2(root / 'default-focused-results.csv', dest / 'default-on-focused-results.csv')
shutil.copy2(Path('/workspace/work/final-copy/partial-tier12-results.csv'),
             dest / 'default-on-superseded-partial-tier12.csv')
shutil.copy2(Path('/workspace/work/final-copy/superseded-completed-after-retries.csv'),
             dest / 'default-on-superseded-after-retries.csv')
print('Staged final application results, 117 focused cases and 30 CI regression cases')
