#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/final-options
for flavor in release fastdebug; do
  for layout in default4 eight8 legacy12; do
    flags='-Xmx512m'
    [[ $layout != eight8 ]] || flags="$flags -XX:-UseFourByteObjectHeaders"
    [[ $layout != legacy12 ]] || flags="$flags -XX:-UseCompactObjectHeaders"
    JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
      /workspace/toolchains/jtreg83/bin/jtreg \
      -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
      -jdk:"$root/$flavor-image" -w:"$root/ci-followup-$flavor-$layout/work" \
      -r:"$root/ci-followup-$flavor-$layout/report" -automatic -conc:1 \
      -timeoutFactor:4 -verbose:summary -javaoptions:"$flags" \
      test/hotspot/jtreg/gc/arguments/TestUseCompressedOopsErgo.java \
      test/hotspot/jtreg/runtime/cds/appcds/aotCache/SpecialCacheNames.java \
      > "$root/ci-followup-$flavor-$layout.log" 2>&1
  done
done
printf '0\n' > "$root/ci-followup.finished"
