#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-copy
while [[ ! -f $root/debug-image.ready ]]; do sleep 5; done
[[ $(cat "$root/debug-image.ready") == 0 ]]
cd /workspace/openjdk-jdk27u
mkdir -p build/cloud-gcc16/hotspot/variant-server/libjvm/objs
tar -xzf /workspace/work/final-stable/release-objects.tar.gz -C build/cloud-gcc16/hotspot/variant-server/libjvm/objs
python3 - <<'PYSYMBOLS'
from pathlib import Path
p=Path('build/cloud-gcc16/support/modules_libs/java.base/server/libjvm.debuginfo')
if p.exists():p.unlink()
PYSYMBOLS
source /workspace/toolchains/activate.sh
set +e
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py make CONF=cloud-gcc16 JOBS=4 jdk-image > "$root/release-build.log" 2>&1
result=$?
printf '%s\n' "$result" > "$root/release-build.finished"
exit "$result"
