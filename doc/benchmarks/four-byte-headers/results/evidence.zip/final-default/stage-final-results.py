"""Stage final default-on measurements only after every required local run passes."""
import csv
import json
from pathlib import Path
import shutil

root = Path('/workspace/work/final-copy')
dest = Path('/workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/results')
for name in ['final-validation.finished', 'jcstress.finished',
             'benchmarks.finished', 'default-tier12.finished']:
    assert (root / name).read_text().strip() == '0', name
for name in ['default-focused-results.csv', 'default-tier12-selected.csv']:
    with (root / name).open() as stream:
        rows = list(csv.DictReader(stream))
    assert rows and all(x['status'].startswith('Passed.') for x in rows), name
applications = dest / 'applications'
applications.mkdir(parents=True, exist_ok=True)
assert json.loads((root / 'manifest.json').read_text())['source_revision'] == \
    '4d9f101b0e274aec19336e5ddb4c0ded875c2ecb'
for path in sorted((root / 'results').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.csv', '.sql'}:
        shutil.copy2(path, applications / path.name)
shutil.copy2(root / 'manifest.json', applications / 'manifest.json')
shutil.copy2(root / 'typical-tables.md', applications / 'summary.md')
for src, target in [
    ('default-focused-results.csv', 'default-on-focused-results.csv'),
    ('default-tier12-selected.csv', 'default-on-selected-tier12.csv'),
]:
    shutil.copy2(root / src, dest / target)
print('Staged final measurements, manifest and per-case validation')
