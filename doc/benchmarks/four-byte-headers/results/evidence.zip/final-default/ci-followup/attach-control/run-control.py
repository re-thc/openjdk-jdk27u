from pathlib import Path
import subprocess, json

root=Path('/workspace/work/final-copy/ci-followup/attach-control')
baseline=Path('/workspace/work/baseline/image')
candidate=Path('/workspace/work/final-copy/release-image')
subprocess.run([str(baseline/'bin/javac'), '-J-XX:ActiveProcessorCount=2',str(root/'AttachControl.java')],check=True)
rows=[]
for name,image in [('baseline8',baseline),('default4',candidate)]:
    p=subprocess.Popen([str(image/'bin/java'),'-XX:ActiveProcessorCount=2','-Xmx128m','-cp',str(root),'AttachControl'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        assert p.stdout.readline().strip()=='READY'
        command=[str(image/'bin/jcmd'),'-J-XX:ActiveProcessorCount=2',str(p.pid),'VM.version']
        r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=25)
        rows.append({'layout':name,'returncode':r.returncode,'output':r.stdout})
        (root/(name+'.log')).write_text(r.stdout)
    finally:
        p.terminate()
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:p.kill();p.wait()
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
