public class AttachControl {
    public static void main(String[] args) throws Exception {
        System.out.println("READY");
        System.out.flush();
        Thread.sleep(30000);
    }
}
