#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-copy
[[ $(cat /workspace/work/archive-forwarded/debug-native-build.finished) == 0 ]]
[[ $(cat /workspace/work/archive-forwarded/after-regression.finished) == 0 ]]
cd /workspace/openjdk-jdk27u
source /workspace/toolchains/activate.sh
set +e
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py make CONF=fourbyte-fastdebug JOBS=4 jdk-image test-image-hotspot-gtest > "$root/fastdebug-build.log" 2>&1
result=$?
printf '%s\n' "$result" > "$root/fastdebug-build.finished"
exit "$result"
