#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-copy
[[ $(cat "$root/final-validation.finished") == 0 ]]
[[ $(cat "$root/jcstress.finished") == 0 ]]
bash "$root/run-final-benchmarks.sh" > "$root/benchmark-driver.log" 2>&1
printf '0\n' > "$root/benchmark-driver.finished"
set +e
bash "$root/run-final-tier12.sh"
result=$?
set -e
[[ $result == 0 || $result == 2 ]]
bash "$root/finish-tier12-serial.sh"
printf '0\n' > "$root/pipeline.finished"
