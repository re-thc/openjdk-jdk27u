| Workload | Metric | Original 8 bytes | Fork default 4 bytes | Change (95% interval) |
| --- | --- | ---: | ---: | ---: |
| db-shootout | duration (ms) | 4589.60 | 4605.47 | +0.3% [-5.9, +6.8] |
| db-shootout | post-GC heap (MiB) | 105.91 | 44.41 | -58.1% [-65.0, -50.0] |
| db-shootout | post-GC RSS (MiB) | 1096.80 | 1098.13 | +0.1% [-1.9, +2.1] |
| Spring Petclinic | throughput (requests/s) | 157.38 | 161.15 | +2.2% [-5.5, +10.6] |
| Spring Petclinic | p50 latency (ms) | 8.60 | 8.57 | -0.5% [-7.0, +6.5] |
| Spring Petclinic | p95 latency (ms) | 183.51 | 179.12 | -2.5% [-9.3, +4.7] |
| Spring Petclinic | p99 latency (ms) | 224.71 | 216.89 | -3.5% [-9.2, +2.5] |
| Spring Petclinic | post-GC heap (MiB) | 40.12 | 35.76 | -10.9% [-11.0, -10.7] |
| Spring Petclinic | RSS after load (MiB) | 706.71 | 704.95 | -0.3% [-2.4, +2.0] |
| Spring Petclinic | post-GC RSS (MiB) | 710.32 | 708.27 | -0.3% [-2.5, +1.9] |
| Spring Petclinic | ready startup (seconds) | 6.16 | 6.33 | +2.5% [-6.0, +11.8] |
| Spring Petclinic | busy heap (MiB) | 209.14 | 192.12 | -8.6% [-22.3, +7.4] |

Validated measured HTTP responses: 114,823; errors: zero.
Maximum load-driver CPU use: 0.07 CPU cores.
Database benchmark uses its upstream dummy validator; normal termination does not establish result correctness.
