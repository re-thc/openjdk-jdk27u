#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/final-stable
while [[ ! -f /workspace/work/final-stable/fastdebug-build.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/final-stable/fastdebug-build.finished) == 0 ]] || exit 1
tar -I 'gzip -1' -cf "$root/fastdebug-objects.tar.gz" -C build/fourbyte-fastdebug/hotspot/variant-server/libjvm/objs .
python3 - <<'PY'
from pathlib import Path
import shutil
shutil.rmtree(Path('build/fourbyte-fastdebug/hotspot/variant-server/libjvm/objs'))
source=Path('build/fourbyte-fastdebug/images/jdk')
destination=Path('/workspace/work/final-stable/fastdebug-image')
assert not destination.exists()
shutil.copytree(source,destination,symlinks=True,ignore=shutil.ignore_patterns('*.debuginfo'))
for p in destination.rglob('*'):
 if p.is_file(): assert p.stat().st_size==(source/p.relative_to(destination)).stat().st_size
shutil.rmtree(source)
PY
python3 - <<'PYMANIFEST'
from pathlib import Path
import hashlib,json
root=Path('/workspace/work/final-stable')
p=root/'manifest.json'
data=json.loads(p.read_text())
lib=root/'fastdebug-image/lib/server/libjvm.so'
data['images']['default4-fastdebug']={'path':str(root/'fastdebug-image'),'libjvm_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'libjvm_bytes':lib.stat().st_size}
p.write_text(json.dumps(data,indent=2)+'\n')
PYMANIFEST
printf '0\n' > /workspace/work/final-stable/debug-image.ready
while [[ ! -f /workspace/work/final-stable/release-validation-driver.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/final-stable/release-validation-driver.finished) == 0 ]]
bash /workspace/work/final-stable/validate-final.sh > /workspace/work/final-stable/validation-driver.log 2>&1
printf '0\n' > /workspace/work/final-stable/after-fastdebug.finished
