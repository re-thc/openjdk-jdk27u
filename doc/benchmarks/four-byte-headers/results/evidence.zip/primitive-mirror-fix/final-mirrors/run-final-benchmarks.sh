#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
[[ $(cat /workspace/work/final-mirrors/final-validation.finished) == 0 ]]
while [[ ! -f /workspace/work/final-mirrors/jcstress.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/final-mirrors/jcstress.finished) == 0 ]]
python3 - <<'PY'
import os
from pathlib import Path
assert not any(k in os.environ for k in ['JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS'])
assert Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java').read_bytes()==Path('/workspace/work/typical-use/CustomRunTest.java.original').read_bytes()
PY
export BASELINE_JDK=/workspace/work/baseline/image
export CANDIDATE_JDK=/workspace/work/final-mirrors/release-image
export RESULTS_DIR=/workspace/work/final-mirrors/results
export RENAISSANCE_JAR=/workspace/work/renaissance-gpl-0.16.1.jar
mkdir -p "$RESULTS_DIR"
python3 - <<'PYMANIFEST'
from pathlib import Path
import datetime,json
p=Path('/workspace/work/final-mirrors/manifest.json');data=json.loads(p.read_text())
import csv,re
with (p.parent/'default-focused-results.csv').open() as f:
    rows=list(csv.DictReader(f))
assert rows and all(r['status'].startswith('Passed.') for r in rows)
data['focused_cases_passed']=len(rows)
data['native_passes_by_layout']={}
for layout in ['default4','eight8','legacy12']:
    log=(p.parent/f'gtest-{layout}.log').read_text()
    passes=re.search(r'\[  PASSED  \] (\d+) tests',log)
    assert passes and '[  FAILED  ]' not in log
    data['native_passes_by_layout'][layout]=int(passes.group(1))
data['jcstress_passes_by_collector']={}
for gc in ['Serial','G1','Z']:
    log=(p.parent/f'jcstress-{gc}.log').read_text()
    counts=re.findall(r'Results: (\d+) planned; (\d+) passed, (\d+) failed, (\d+) soft errs, (\d+) hard errs',log)
    assert counts
    planned,passed,failed,soft,hard=map(int,counts[-1])
    assert planned==passed and failed==soft==hard==0
    data['jcstress_passes_by_collector'][gc]=passed
data['timing_started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
p.write_text(json.dumps(data,indent=2)+'\n')
PYMANIFEST
printf 'Timing starts %s\n' "$(date -u +%FT%TZ)"
python3 /workspace/work/subreaper.py env DATABASE_FORKS=12 DATABASE_REPEATS=16 bash doc/benchmarks/four-byte-headers/database.sh timing
python3 /workspace/work/subreaper.py python3 doc/benchmarks/four-byte-headers/petclinic-load.py "$BASELINE_JDK" "$CANDIDATE_JDK" /workspace/work/typical-use/petclinic/target/spring-petclinic-3.5.0-SNAPSHOT.jar "$RESULTS_DIR"
python3 /workspace/work/subreaper.py bash doc/benchmarks/four-byte-headers/database.sh memory
python3 doc/benchmarks/four-byte-headers/summarize-typical.py "$RESULTS_DIR" --database-forks 12 --database-repeats 16 > /workspace/work/final-mirrors/typical-tables.md
python3 - <<'PYMANIFEST'
from pathlib import Path
import datetime,json
root=Path('/workspace/work/final-mirrors');p=root/'manifest.json';data=json.loads(p.read_text())
data['timing_completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['timing_complete']=True
p.write_text(json.dumps(data,indent=2)+'\n')
PYMANIFEST
printf '0\n' > /workspace/work/final-mirrors/benchmarks.finished
