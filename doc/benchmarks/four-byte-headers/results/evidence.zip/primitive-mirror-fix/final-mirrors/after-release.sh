#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-mirrors
while [[ ! -f $root/release-build.finished ]]; do sleep 5; done
[[ $(cat "$root/release-build.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
python3 - <<'PYIMAGE'
from pathlib import Path
import shutil,json,hashlib
root=Path('/workspace/work/final-mirrors');source=Path('build/cloud-gcc16/images/jdk');destination=root/'release-image'
assert not destination.exists();shutil.copytree(source,destination,symlinks=True)
for p in source.rglob('*'):
 if p.is_file():assert p.stat().st_size==(destination/p.relative_to(source)).stat().st_size
lib=destination/'lib/server/libjvm.so';p=root/'manifest.json';data=json.loads(p.read_text())
data['images']['default4-release']={'path':str(destination),'libjvm_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'libjvm_bytes':lib.stat().st_size}
p.write_text(json.dumps(data,indent=2)+'\n')
PYIMAGE
tar -I 'gzip -1' -cf "$root/release-objects.tar.gz" -C build/cloud-gcc16/hotspot/variant-server/libjvm/objs .
python3 - <<'PYCACHE'
from pathlib import Path
import shutil
shutil.rmtree(Path('build/cloud-gcc16/hotspot/variant-server/libjvm/objs'))
PYCACHE
printf '0\n' > "$root/release-image.ready"
bash "$root/validate-release.sh" > "$root/release-validation-driver.log" 2>&1
printf '0\n' > "$root/release-validation-driver.finished"
