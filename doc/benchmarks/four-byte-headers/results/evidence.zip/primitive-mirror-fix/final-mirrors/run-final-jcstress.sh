#!/usr/bin/env bash
set -euo pipefail
while [[ ! -f /workspace/work/final-mirrors/final-validation.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/final-mirrors/final-validation.finished) == 0 ]] || exit 1
cd /workspace/work/final-mirrors
image=/workspace/work/final-mirrors/release-image
mkdir -p jcstress-classes
"$image/bin/javac" -J-XX:ActiveProcessorCount=2 -cp '/workspace/work/jcstress/*' -processor org.openjdk.jcstress.infra.processors.JCStressTestProcessor -d jcstress-classes /workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/HashAndLock.java > jcstress-compile.log 2>&1
for gc in Serial G1 Z; do
  python3 /workspace/work/subreaper.py "$image/bin/java" --enable-native-access=ALL-UNNAMED -XX:ActiveProcessorCount=2 -cp '/workspace/work/final-mirrors/jcstress-classes:/workspace/work/jcstress/*' org.openjdk.jcstress.Main -t 'fourbyte.HashAndLock' -m quick -f 3 -iters 5 -time 200 -c 2 -af NONE -r "/workspace/work/final-mirrors/jcstress/$gc" -jvmArgsPrepend "--enable-native-access=ALL-UNNAMED -XX:+Use${gc}GC" > "/workspace/work/final-mirrors/jcstress-$gc.log" 2>&1
done
printf '0\n' > /workspace/work/final-mirrors/jcstress.finished
