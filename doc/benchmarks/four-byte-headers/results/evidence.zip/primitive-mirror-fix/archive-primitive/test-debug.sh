#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/archive-primitive
while [[ ! -f $root/debug-native-build.finished ]]; do sleep 5; done
[[ $(cat "$root/debug-native-build.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('/workspace/work/archive-primitive');dst=root/'hypothesis-debug-image'
shutil.copytree(Path('/workspace/work/final-mirrors/fastdebug-image'),dst,symlinks=True)
shutil.copy2(Path('build/fourbyte-fastdebug/support/modules_libs/java.base/server/libjvm.so'),dst/'lib/server/libjvm.so')
PY
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$root/hypothesis-debug-image" -w:"$root/debug-test/work" -r:"$root/debug-test/report" -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:-Xmx512m test/hotspot/jtreg/runtime/cds/DeterministicDump.java test/hotspot/jtreg/runtime/cds/FourByteHeaderArchiveDeterminism.java > "$root/debug-test.log" 2>&1
printf '0\n' > "$root/debug-test.finished"
