#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/archive-forwarded
while [[ ! -f $root/debug-native-build.finished ]]; do sleep 5; done
[[ $(cat "$root/debug-native-build.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
python3 - <<'PY'
from pathlib import Path
import os, shutil
root=Path('/workspace/work/archive-forwarded')
src=Path('/workspace/work/final-stable/fastdebug-image')
dst=root/'hypothesis-debug-image'
assert not dst.exists()
shutil.copytree(src,dst,symlinks=True,copy_function=os.link)
lib=dst/'lib/server/libjvm.so';lib.unlink()
shutil.copy2(Path('build/fourbyte-fastdebug/support/modules_libs/java.base/server/libjvm.so'),lib)
PY
ulimit -c 0
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$root/hypothesis-debug-image" -w:"$root/after-regression/work" -r:"$root/after-regression/report" -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:-Xmx512m test/hotspot/jtreg/runtime/cds/DeterministicDump.java test/hotspot/jtreg/runtime/cds/FourByteHeaderArchiveDeterminism.java 'test/hotspot/jtreg/runtime/CompressedOops/CompressedClassSpaceSize.java#valid_large_cds' > "$root/after-regression.log" 2>&1
printf '0\n' > "$root/after-regression.finished"
