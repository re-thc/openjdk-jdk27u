#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/archive-determinism
while [[ ! -f $root/relative-hash-build.finished ]]; do sleep 5; done
[[ $(cat "$root/relative-hash-build.finished") == 0 ]]
python3 - <<'PY'
from pathlib import Path
import shutil
src=Path('/workspace/work/monitor-fix/full-lookup-image')
dst=Path('/workspace/work/archive-determinism/relative-hash-image')
assert not dst.exists()
shutil.copytree(src,dst,symlinks=True)
lib=Path('/workspace/openjdk-jdk27u/build/cloud-gcc16/support/modules_libs/java.base/server/libjvm.so')
assert lib.exists()
shutil.copy2(lib,dst/'lib/server/libjvm.so')
PY
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
  /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 \
  -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$root/relative-hash-image" \
  -w:"$root/relative-hash-test/work" -r:"$root/relative-hash-test/report" \
  -automatic -conc:1 -timeoutFactor:4 -retain:all -verbose:summary \
  -javaoptions:-Xmx512m test/hotspot/jtreg/runtime/cds/DeterministicDump.java \
  > "$root/relative-hash-test.log" 2>&1
printf '0\n' > "$root/relative-hash-test.finished"
