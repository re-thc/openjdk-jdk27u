#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
while [[ ! -f /workspace/work/typical-use/benchmark-driver.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/typical-use/benchmark-driver.finished) == 0 ]] || exit 1
if [[ ! -f /workspace/work/typical-use/profile-results/petclinic-default4-default-1.json ]]; then
  python3 /workspace/work/subreaper.py python3 doc/benchmarks/four-byte-headers/petclinic-load.py /workspace/work/baseline/image /workspace/work/typical-use/release-image /workspace/work/typical-use/petclinic/target/spring-petclinic-3.5.0-SNAPSHOT.jar /workspace/work/typical-use/profile-results --control --forks 1 --profile-library /workspace/work/async-profiler/lib/libasyncProfiler.so > /workspace/work/typical-use/profile-driver.log 2>&1
fi
python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
assert p.read_text()==original
p.write_text(original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));'))
PY
set +e
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:/workspace/work/typical-use/release-image -nativepath:$PWD/build/cloud-gcc16/images/test/hotspot/jtreg/native -w:/workspace/work/typical-use/jtreg-tier12/work -r:/workspace/work/typical-use/jtreg-tier12/report -automatic -conc:2 -timeoutFactor:4 -verbose:summary -status:fail,error,notRun -exclude:test/hotspot/jtreg/ProblemList.txt -exclude:/workspace/work/container-core-problems.txt -javaoptions:'-Xmx512m' test/hotspot/jtreg/:tier1 test/hotspot/jtreg/:tier2 > /workspace/work/typical-use/default-tier12-resumed.log 2>&1
result=$?
printf '%s\n' "$result" > /workspace/work/typical-use/default-tier12.finished
python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
bounded=original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));')
assert p.read_text()==bounded
p.write_text(original)
PY
exit "$result"
