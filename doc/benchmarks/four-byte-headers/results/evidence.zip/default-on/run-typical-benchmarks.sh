#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
for name in default-validation-driver; do
 while [[ ! -f /workspace/work/typical-use/$name.finished ]]; do sleep 5; done
 [[ $(cat /workspace/work/typical-use/$name.finished) == 0 ]] || exit 1
done
python3 - <<'RESTORE'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
o=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
n=o.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());','ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));')
assert p.read_text() in (n, o)
p.write_text(o)
RESTORE
export BASELINE_JDK=/workspace/work/baseline/image
export CANDIDATE_JDK=/workspace/work/typical-use/release-image
export RESULTS_DIR=/workspace/work/typical-use/results
export RENAISSANCE_JAR=/workspace/work/renaissance-gpl-0.16.1.jar
mkdir -p "$RESULTS_DIR"
python3 - <<'CLEAN'
import os
assert not any(k in os.environ for k in ['JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS'])
CLEAN
printf 'Timing starts %s\n' "$(date -u +%FT%TZ)"
python3 /workspace/work/subreaper.py bash doc/benchmarks/four-byte-headers/database.sh timing
python3 /workspace/work/subreaper.py python3 doc/benchmarks/four-byte-headers/petclinic-load.py "$BASELINE_JDK" "$CANDIDATE_JDK" /workspace/work/typical-use/petclinic/target/spring-petclinic-3.5.0-SNAPSHOT.jar "$RESULTS_DIR"
python3 /workspace/work/subreaper.py bash doc/benchmarks/four-byte-headers/database.sh memory
python3 doc/benchmarks/four-byte-headers/summarize-typical.py "$RESULTS_DIR" > /workspace/work/typical-use/typical-tables.md
python3 /workspace/work/subreaper.py python3 doc/benchmarks/four-byte-headers/petclinic-load.py "$BASELINE_JDK" "$CANDIDATE_JDK" /workspace/work/typical-use/petclinic/target/spring-petclinic-3.5.0-SNAPSHOT.jar /workspace/work/typical-use/profile-results --control --forks 1 --profile-library /workspace/work/async-profiler/lib/libasyncProfiler.so
printf '0\n' > /workspace/work/typical-use/benchmarks.finished
