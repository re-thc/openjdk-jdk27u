#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
ulimit -c unlimited
for flavor in release fastdebug; do
  image=/workspace/work/typical-use/$flavor-image
  options='-Xmx512m'
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/hotspot/jtreg/native -w:/workspace/work/typical-use/jtreg-$flavor/work -r:/workspace/work/typical-use/jtreg-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:"$options" test/hotspot/jtreg/runtime/CompactObjectHeaders test/hotspot/jtreg/gc/stress/ihash test/hotspot/jtreg/runtime/CompressedOops > /workspace/work/typical-use/default-$flavor-focus.log 2>&1
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/jdk/jtreg/native -w:/workspace/work/typical-use/jtreg-size-$flavor/work -r:/workspace/work/typical-use/jtreg-size-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:"$options" test/jdk/java/lang/instrument/FourByteHeaderObjectSize.java 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id0' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id1' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id2' > /workspace/work/typical-use/default-$flavor-size.log 2>&1
done
image=/workspace/work/typical-use/fastdebug-image
gtest_dir=$PWD/build/fourbyte-fastdebug/hotspot/variant-server/libjvm/gtest
for layout in default4 eight8 legacy12; do
 flags=(-XX:ActiveProcessorCount=2)
 [[ $layout != eight8 ]] || flags+=(-XX:-UseFourByteObjectHeaders)
 [[ $layout != legacy12 ]] || flags+=(-XX:-UseCompactObjectHeaders)
 LD_LIBRARY_PATH=$gtest_dir python3 /workspace/work/subreaper.py "$gtest_dir/gtestLauncher" -jdk "$image" "${flags[@]}" > /workspace/work/typical-use/gtest-$layout.log 2>&1
done
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/fourbyte-fastdebug/images/test/hotspot/gtest -w:/workspace/work/typical-use/jtreg-common/work -r:/workspace/work/typical-use/jtreg-common/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/hotspot/jtreg/:tier1_common > /workspace/work/typical-use/default-common.log 2>&1
printf '0\n' > /workspace/work/typical-use/default-validation.finished
