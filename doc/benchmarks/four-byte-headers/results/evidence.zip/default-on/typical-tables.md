| Workload | Metric | Original 8 bytes | Fork default 4 bytes | Change (95% interval) |
| --- | --- | ---: | ---: | ---: |
| db-shootout | duration (ms) | 4618.31 | 4677.27 | +1.2% [-6.5, +9.4] |
| db-shootout | post-GC heap (MiB) | 75.84 | 74.18 | -2.3% [-62.9, +157.5] |
| db-shootout | post-GC RSS (MiB) | 1094.37 | 1098.27 | +0.4% [-1.4, +2.1] |
| Spring Petclinic | throughput (requests/s) | 165.02 | 119.83 | -27.3% [-32.1, -22.2] |
| Spring Petclinic | p50 latency (ms) | 8.80 | 10.99 | +24.9% [+16.9, +33.5] |
| Spring Petclinic | p95 latency (ms) | 169.17 | 232.85 | +37.9% [+28.2, +48.3] |
| Spring Petclinic | p99 latency (ms) | 208.73 | 285.17 | +36.8% [+28.9, +45.2] |
| Spring Petclinic | post-GC heap (MiB) | 40.20 | 35.78 | -11.0% [-11.3, -10.7] |
| Spring Petclinic | RSS after load (MiB) | 706.90 | 700.28 | -0.9% [-2.2, +0.3] |
| Spring Petclinic | post-GC RSS (MiB) | 710.77 | 703.87 | -1.0% [-2.2, +0.3] |
| Spring Petclinic | ready startup (seconds) | 7.19 | 7.23 | +0.6% [-7.1, +8.9] |
| Spring Petclinic | busy heap (MiB) | 215.48 | 197.55 | -8.3% [-15.2, -0.8] |

Validated measured HTTP responses: 102,674; errors: zero.
Maximum load-driver CPU use: 0.08 CPU cores.
Database benchmark uses its upstream dummy validator; normal termination does not establish result correctness.
