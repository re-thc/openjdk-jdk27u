public class LargeArrayProbe {
    static volatile Object prefix;
    static volatile int[] retained;
    static int hash(Object value) { return System.identityHashCode(value); }
    public static void main(String[] args) {
        prefix = new byte[1024 * 1024 * 1024];
        int length = (1 << 29) + 65;
        retained = new int[length];
        for (int i = 0; i < 32; i++) retained[(int)((long)i * (length - 1) / 31)] = 0x600d0000 + i;
        int expected = hash(retained);
        long before = FootprintAgent.instrumentation.getObjectSize(retained);
        prefix = null;
        for (int gc = 0; gc < 3; gc++) System.gc();
        for (int i = 0; i < 2000000; i++) {
            if (hash(retained) != expected) throw new AssertionError("Hash changed after GC");
        }
        if (retained.length != length) throw new AssertionError("Length changed");
        for (int i = 0; i < 32; i++) {
            if (retained[(int)((long)i * (length - 1) / 31)] != 0x600d0000 + i) throw new AssertionError("Payload changed");
        }
        long after = FootprintAgent.instrumentation.getObjectSize(retained);
        if (before <= Integer.MAX_VALUE || after < before) throw new AssertionError("Invalid large-object size");
        System.out.printf("PASS length=%d before=%d after=%d hash=%d%n", length, before, after, expected);
    }
}
