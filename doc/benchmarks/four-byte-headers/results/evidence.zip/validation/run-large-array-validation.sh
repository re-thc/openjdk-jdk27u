#!/usr/bin/env bash
set -eu
while [[ ! -f /workspace/work/local-suite-matrix.finished ]]; do sleep 10; done
jdk=/workspace/work/complete-release/image
classes=/workspace/work/validation/large-array-classes
mkdir -p "$classes"
"$jdk/bin/javac" -d "$classes" /workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/FootprintAgent.java /workspace/work/validation/LargeArrayProbe.java
printf 'Premain-Class: FootprintAgent\n' > "$classes/agent-manifest.txt"
"$jdk/bin/jar" cfm "$classes/agent.jar" "$classes/agent-manifest.txt" -C "$classes" FootprintAgent.class
for gc in Serial G1 Z; do
  for compilation in c1 c2; do
    flags=(-Xbatch -XX:CompileThreshold=1000)
    [[ $compilation != c1 ]] || flags+=(-XX:TieredStopAtLevel=1)
    python3 /workspace/work/subreaper.py "$jdk/bin/java" -XX:+UnlockExperimentalVMOptions -XX:+UseFourByteObjectHeaders -XX:+Use${gc}GC -Xms6g -Xmx6g -XX:ActiveProcessorCount=4 "${flags[@]}" -javaagent:"$classes/agent.jar" -cp "$classes" LargeArrayProbe > /workspace/work/validation/large-array-$gc-$compilation.log 2>&1
  done
done
printf '0\n' > /workspace/work/large-array-validation.finished
