
/workspace/work/complete-release/image/lib/server/libjvm.so:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000014c7c00 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc>:
 14c7c00:	55                   	push   %rbp
 14c7c01:	48 89 e5             	mov    %rsp,%rbp
 14c7c04:	41 57                	push   %r15
 14c7c06:	41 56                	push   %r14
 14c7c08:	49 89 f6             	mov    %rsi,%r14
 14c7c0b:	41 55                	push   %r13
 14c7c0d:	49 89 fd             	mov    %rdi,%r13
 14c7c10:	41 54                	push   %r12
 14c7c12:	4c 8d 25 7b 1a 0b ff 	lea    -0xf4e585(%rip),%r12        # 579694 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x254>
 14c7c19:	53                   	push   %rbx
 14c7c1a:	48 83 ec 28          	sub    $0x28,%rsp
 14c7c1e:	48 8d 1d eb f6 33 00 	lea    0x33f6eb(%rip),%rbx        # 1807310 <UseFourByteObjectHeaders>
 14c7c25:	4d 8b 3e             	mov    (%r14),%r15
 14c7c28:	80 3b 00             	cmpb   $0x0,(%rbx)
 14c7c2b:	0f 84 af 00 00 00    	je     14c7ce0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xe0>
 14c7c31:	4c 89 fa             	mov    %r15,%rdx
 14c7c34:	81 e2 00 18 00 00    	and    $0x1800,%edx
 14c7c3a:	41 f7 c7 00 08 00 00 	test   $0x800,%r15d
 14c7c41:	0f 85 e1 03 00 00    	jne    14c8028 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x428>
 14c7c47:	48 8d 05 ea a2 30 00 	lea    0x30a2ea(%rip),%rax        # 17d1f38 <hashCode>
 14c7c4e:	48 8b 00             	mov    (%rax),%rax
 14c7c51:	48 83 f8 04          	cmp    $0x4,%rax
 14c7c55:	0f 87 d1 02 00 00    	ja     14c7f2c <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x32c>
 14c7c5b:	49 63 04 84          	movslq (%r12,%rax,4),%rax
 14c7c5f:	4c 01 e0             	add    %r12,%rax
 14c7c62:	ff e0                	jmp    *%rax
 14c7c64:	0f 1f 40 00          	nopl   0x0(%rax)
 14c7c68:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 14c7c6c:	e8 8f 79 cf ff       	call   11bf600 <_ZN2os6randomEv>
 14c7c71:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 14c7c75:	41 89 c0             	mov    %eax,%r8d
 14c7c78:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7c7f:	80 3b 00             	cmpb   $0x0,(%rbx)
 14c7c82:	0f 85 0d 04 00 00    	jne    14c8095 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x495>
 14c7c88:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 14c7c8d:	41 89 c2             	mov    %eax,%r10d
 14c7c90:	0f 84 6a 02 00 00    	je     14c7f00 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x300>
 14c7c96:	4d 89 f9             	mov    %r15,%r9
 14c7c99:	49 81 c9 00 18 00 00 	or     $0x1800,%r9
 14c7ca0:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
 14c7ca7:	0f 84 09 02 00 00    	je     14c7eb6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2b6>
 14c7cad:	4c 89 f8             	mov    %r15,%rax
 14c7cb0:	80 e4 e7             	and    $0xe7,%ah
 14c7cb3:	80 cc 08             	or     $0x8,%ah
 14c7cb6:	49 89 c1             	mov    %rax,%r9
 14c7cb9:	4c 89 f8             	mov    %r15,%rax
 14c7cbc:	f0 4d 0f b1 0e       	lock cmpxchg %r9,(%r14)
 14c7cc1:	49 39 c7             	cmp    %rax,%r15
 14c7cc4:	0f 85 5b ff ff ff    	jne    14c7c25 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x25>
 14c7cca:	48 83 c4 28          	add    $0x28,%rsp
 14c7cce:	4c 89 c0             	mov    %r8,%rax
 14c7cd1:	5b                   	pop    %rbx
 14c7cd2:	41 5c                	pop    %r12
 14c7cd4:	41 5d                	pop    %r13
 14c7cd6:	41 5e                	pop    %r14
 14c7cd8:	41 5f                	pop    %r15
 14c7cda:	5d                   	pop    %rbp
 14c7cdb:	c3                   	ret
 14c7cdc:	0f 1f 40 00          	nopl   0x0(%rax)
 14c7ce0:	48 8d 05 ad 9f 30 00 	lea    0x309fad(%rip),%rax        # 17d1c94 <UseObjectMonitorTable>
 14c7ce7:	80 38 00             	cmpb   $0x0,(%rax)
 14c7cea:	75 10                	jne    14c7cfc <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xfc>
 14c7cec:	4c 89 f8             	mov    %r15,%rax
 14c7cef:	83 e0 03             	and    $0x3,%eax
 14c7cf2:	48 83 f8 02          	cmp    $0x2,%rax
 14c7cf6:	0f 84 fc 00 00 00    	je     14c7df8 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x1f8>
 14c7cfc:	4d 89 f8             	mov    %r15,%r8
 14c7cff:	49 c1 e8 0b          	shr    $0xb,%r8
 14c7d03:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7d0a:	75 be                	jne    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7d0c:	4c 89 f6             	mov    %r14,%rsi
 14c7d0f:	4c 89 ef             	mov    %r13,%rdi
 14c7d12:	e8 49 fd ff ff       	call   14c7a60 <_ZN18ObjectSynchronizer13get_next_hashEP6ThreadP7oopDesc>
 14c7d17:	49 89 c0             	mov    %rax,%r8
 14c7d1a:	48 b8 ff 07 00 00 00 	movabs $0xfffffc00000007ff,%rax
 14c7d21:	fc ff ff 
 14c7d24:	4c 89 c2             	mov    %r8,%rdx
 14c7d27:	4c 21 f8             	and    %r15,%rax
 14c7d2a:	48 c1 e2 0b          	shl    $0xb,%rdx
 14c7d2e:	48 09 c2             	or     %rax,%rdx
 14c7d31:	4c 89 f8             	mov    %r15,%rax
 14c7d34:	f0 49 0f b1 16       	lock cmpxchg %rdx,(%r14)
 14c7d39:	49 39 c7             	cmp    %rax,%r15
 14c7d3c:	0f 85 e3 fe ff ff    	jne    14c7c25 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x25>
 14c7d42:	eb 86                	jmp    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7d44:	0f 1f 40 00          	nopl   0x0(%rax)
 14c7d48:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 14c7d4e:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
 14c7d55:	0f 85 52 ff ff ff    	jne    14c7cad <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xad>
 14c7d5b:	4d 89 f9             	mov    %r15,%r9
 14c7d5e:	45 89 c2             	mov    %r8d,%r10d
 14c7d61:	49 81 c9 00 18 00 00 	or     $0x1800,%r9
 14c7d68:	eb 38                	jmp    14c7da2 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x1a2>
 14c7d6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 14c7d70:	4d 89 f0             	mov    %r14,%r8
 14c7d73:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7d7a:	4d 85 c0             	test   %r8,%r8
 14c7d7d:	75 cf                	jne    14c7d4e <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x14e>
 14c7d7f:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
 14c7d86:	0f 85 7d 01 00 00    	jne    14c7f09 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x309>
 14c7d8c:	4d 89 f9             	mov    %r15,%r9
 14c7d8f:	41 ba ad 0b 00 00    	mov    $0xbad,%r10d
 14c7d95:	41 b8 ad 0b 00 00    	mov    $0xbad,%r8d
 14c7d9b:	49 81 c9 00 18 00 00 	or     $0x1800,%r9
 14c7da2:	44 89 ff             	mov    %r15d,%edi
 14c7da5:	c1 ef 0d             	shr    $0xd,%edi
 14c7da8:	e9 10 01 00 00       	jmp    14c7ebd <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2bd>
 14c7dad:	0f 1f 00             	nopl   (%rax)
 14c7db0:	44 8b 05 49 74 38 00 	mov    0x387449(%rip),%r8d        # 184f200 <_ZL5GVars+0x80>
 14c7db7:	41 83 c0 01          	add    $0x1,%r8d
 14c7dbb:	44 89 05 3e 74 38 00 	mov    %r8d,0x38743e(%rip)        # 184f200 <_ZL5GVars+0x80>
 14c7dc2:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7dc9:	eb af                	jmp    14c7d7a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x17a>
 14c7dcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 14c7dd0:	4d 89 f0             	mov    %r14,%r8
 14c7dd3:	4c 89 f0             	mov    %r14,%rax
 14c7dd6:	48 c1 f8 03          	sar    $0x3,%rax
 14c7dda:	49 c1 f8 08          	sar    $0x8,%r8
 14c7dde:	49 31 c0             	xor    %rax,%r8
 14c7de1:	48 63 05 d8 73 38 00 	movslq 0x3873d8(%rip),%rax        # 184f1c0 <_ZL5GVars+0x40>
 14c7de8:	49 31 c0             	xor    %rax,%r8
 14c7deb:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7df2:	eb 86                	jmp    14c7d7a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x17a>
 14c7df4:	0f 1f 40 00          	nopl   0x0(%rax)
 14c7df8:	49 83 f7 02          	xor    $0x2,%r15
 14c7dfc:	4d 8b 07             	mov    (%r15),%r8
 14c7dff:	49 c1 e8 0b          	shr    $0xb,%r8
 14c7e03:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7e0a:	0f 85 08 01 00 00    	jne    14c7f18 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x318>
 14c7e10:	49 8b 0f             	mov    (%r15),%rcx
 14c7e13:	49 89 c8             	mov    %rcx,%r8
 14c7e16:	49 c1 e8 0b          	shr    $0xb,%r8
 14c7e1a:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7e21:	0f 85 a3 fe ff ff    	jne    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7e27:	4c 89 ef             	mov    %r13,%rdi
 14c7e2a:	4c 89 f6             	mov    %r14,%rsi
 14c7e2d:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 14c7e31:	e8 2a fc ff ff       	call   14c7a60 <_ZN18ObjectSynchronizer13get_next_hashEP6ThreadP7oopDesc>
 14c7e36:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 14c7e3a:	48 ba ff 07 00 00 00 	movabs $0xfffffc00000007ff,%rdx
 14c7e41:	fc ff ff 
 14c7e44:	48 89 c7             	mov    %rax,%rdi
 14c7e47:	48 c1 e0 0b          	shl    $0xb,%rax
 14c7e4b:	48 21 ca             	and    %rcx,%rdx
 14c7e4e:	48 09 c2             	or     %rax,%rdx
 14c7e51:	48 89 c8             	mov    %rcx,%rax
 14c7e54:	f0 49 0f b1 17       	lock cmpxchg %rdx,(%r15)
 14c7e59:	49 89 c0             	mov    %rax,%r8
 14c7e5c:	49 c1 e8 0b          	shr    $0xb,%r8
 14c7e60:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7e67:	48 39 c1             	cmp    %rax,%rcx
 14c7e6a:	41 8b 87 ac 00 00 00 	mov    0xac(%r15),%eax
 14c7e71:	4c 0f 44 c7          	cmove  %rdi,%r8
 14c7e75:	85 c0                	test   %eax,%eax
 14c7e77:	0f 89 4d fe ff ff    	jns    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7e7d:	48 8d 05 10 9e 30 00 	lea    0x309e10(%rip),%rax        # 17d1c94 <UseObjectMonitorTable>
 14c7e84:	80 38 00             	cmpb   $0x0,(%rax)
 14c7e87:	0f 85 3d fe ff ff    	jne    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7e8d:	4c 89 f6             	mov    %r14,%rsi
 14c7e90:	4c 89 ff             	mov    %r15,%rdi
 14c7e93:	e8 b8 f9 cc ff       	call   1197850 <_ZN13ObjectMonitor36install_displaced_markword_in_objectEP7oopDesc>
 14c7e98:	e9 88 fd ff ff       	jmp    14c7c25 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x25>
 14c7e9d:	0f 1f 00             	nopl   (%rax)
 14c7ea0:	4d 89 f9             	mov    %r15,%r9
 14c7ea3:	41 ba ad 0b 00 00    	mov    $0xbad,%r10d
 14c7ea9:	41 b8 ad 0b 00 00    	mov    $0xbad,%r8d
 14c7eaf:	49 81 c9 00 18 00 00 	or     $0x1800,%r9
 14c7eb6:	4c 89 ff             	mov    %r15,%rdi
 14c7eb9:	48 c1 ef 2a          	shr    $0x2a,%rdi
 14c7ebd:	48 8d 05 1c 8e 30 00 	lea    0x308e1c(%rip),%rax        # 17d0ce0 <_ZN23CompressedKlassPointers6_shiftE>
 14c7ec4:	48 8d 15 e5 cc 31 ff 	lea    -0xce331b(%rip),%rdx        # 7e4bb0 <_ZNK13InstanceKlass20hash_offset_in_bytesEP7oopDesc8markWord>
 14c7ecb:	8b 08                	mov    (%rax),%ecx
 14c7ecd:	48 8d 05 14 8e 30 00 	lea    0x308e14(%rip),%rax        # 17d0ce8 <_ZN23CompressedKlassPointers5_baseE>
 14c7ed4:	48 d3 e7             	shl    %cl,%rdi
 14c7ed7:	48 03 38             	add    (%rax),%rdi
 14c7eda:	48 8b 07             	mov    (%rdi),%rax
 14c7edd:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
 14c7ee4:	48 39 d0             	cmp    %rdx,%rax
 14c7ee7:	0f 85 13 01 00 00    	jne    14c8000 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x400>
 14c7eed:	48 63 87 40 01 00 00 	movslq 0x140(%rdi),%rax
 14c7ef4:	45 89 14 06          	mov    %r10d,(%r14,%rax,1)
 14c7ef8:	e9 bc fd ff ff       	jmp    14c7cb9 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xb9>
 14c7efd:	0f 1f 00             	nopl   (%rax)
 14c7f00:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
 14c7f07:	74 97                	je     14c7ea0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2a0>
 14c7f09:	41 b8 ad 0b 00 00    	mov    $0xbad,%r8d
 14c7f0f:	e9 99 fd ff ff       	jmp    14c7cad <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xad>
 14c7f14:	0f 1f 40 00          	nopl   0x0(%rax)
 14c7f18:	41 8b 97 ac 00 00 00 	mov    0xac(%r15),%edx
 14c7f1f:	85 d2                	test   %edx,%edx
 14c7f21:	0f 89 a3 fd ff ff    	jns    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c7f27:	e9 61 ff ff ff       	jmp    14c7e8d <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x28d>
 14c7f2c:	48 83 f8 05          	cmp    $0x5,%rax
 14c7f30:	74 66                	je     14c7f98 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x398>
 14c7f32:	44 89 f7             	mov    %r14d,%edi
 14c7f35:	4c 89 f1             	mov    %r14,%rcx
 14c7f38:	81 f7 aa aa aa aa    	xor    $0xaaaaaaaa,%edi
 14c7f3e:	48 c1 e9 20          	shr    $0x20,%rcx
 14c7f42:	48 69 ff d5 54 79 33 	imul   $0x337954d5,%rdi,%rdi
 14c7f49:	44 31 f1             	xor    %r14d,%ecx
 14c7f4c:	69 c9 d5 54 79 33    	imul   $0x337954d5,%ecx,%ecx
 14c7f52:	49 89 f8             	mov    %rdi,%r8
 14c7f55:	81 f7 d5 54 79 33    	xor    $0x337954d5,%edi
 14c7f5b:	49 c1 e8 20          	shr    $0x20,%r8
 14c7f5f:	44 31 c1             	xor    %r8d,%ecx
 14c7f62:	41 89 c9             	mov    %ecx,%r9d
 14c7f65:	d3 cf                	ror    %cl,%edi
 14c7f67:	4d 69 c9 d5 54 79 33 	imul   $0x337954d5,%r9,%r9
 14c7f6e:	44 31 cf             	xor    %r9d,%edi
 14c7f71:	49 c1 e9 20          	shr    $0x20,%r9
 14c7f75:	41 89 f8             	mov    %edi,%r8d
 14c7f78:	45 31 c8             	xor    %r9d,%r8d
 14c7f7b:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7f82:	48 83 f8 06          	cmp    $0x6,%rax
 14c7f86:	0f 84 c2 fd ff ff    	je     14c7d4e <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x14e>
 14c7f8c:	e9 e9 fd ff ff       	jmp    14c7d7a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x17a>
 14c7f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 14c7f98:	66 41 0f 6e 85 2c 04 	movd   0x42c(%r13),%xmm0
 14c7f9f:	00 00 
 14c7fa1:	45 8b 85 24 04 00 00 	mov    0x424(%r13),%r8d
 14c7fa8:	66 41 0f 6e 9d 28 04 	movd   0x428(%r13),%xmm3
 14c7faf:	00 00 
 14c7fb1:	44 89 c0             	mov    %r8d,%eax
 14c7fb4:	c1 e0 0b             	shl    $0xb,%eax
 14c7fb7:	41 31 c0             	xor    %eax,%r8d
 14c7fba:	41 8b 85 20 04 00 00 	mov    0x420(%r13),%eax
 14c7fc1:	89 c1                	mov    %eax,%ecx
 14c7fc3:	66 0f 6e d0          	movd   %eax,%xmm2
 14c7fc7:	c1 e9 13             	shr    $0x13,%ecx
 14c7fca:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
 14c7fce:	31 c1                	xor    %eax,%ecx
 14c7fd0:	44 31 c1             	xor    %r8d,%ecx
 14c7fd3:	41 c1 e8 08          	shr    $0x8,%r8d
 14c7fd7:	41 31 c8             	xor    %ecx,%r8d
 14c7fda:	66 41 0f 6e c8       	movd   %r8d,%xmm1
 14c7fdf:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
 14c7fe6:	66 0f 62 cb          	punpckldq %xmm3,%xmm1
 14c7fea:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
 14c7fee:	41 0f 11 8d 20 04 00 	movups %xmm1,0x420(%r13)
 14c7ff5:	00 
 14c7ff6:	e9 7f fd ff ff       	jmp    14c7d7a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x17a>
 14c7ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 14c8000:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 14c8004:	4c 89 fa             	mov    %r15,%rdx
 14c8007:	4c 89 f6             	mov    %r14,%rsi
 14c800a:	44 89 55 c4          	mov    %r10d,-0x3c(%rbp)
 14c800e:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 14c8012:	ff d0                	call   *%rax
 14c8014:	4c 8b 45 b8          	mov    -0x48(%rbp),%r8
 14c8018:	44 8b 55 c4          	mov    -0x3c(%rbp),%r10d
 14c801c:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 14c8020:	e9 cf fe ff ff       	jmp    14c7ef4 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2f4>
 14c8025:	0f 1f 00             	nopl   (%rax)
 14c8028:	48 81 fa 00 18 00 00 	cmp    $0x1800,%rdx
 14c802f:	75 42                	jne    14c8073 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x473>
 14c8031:	48 8d 05 a8 8c 30 00 	lea    0x308ca8(%rip),%rax        # 17d0ce0 <_ZN23CompressedKlassPointers6_shiftE>
 14c8038:	44 89 ff             	mov    %r15d,%edi
 14c803b:	48 8d 15 6e cb 31 ff 	lea    -0xce3492(%rip),%rdx        # 7e4bb0 <_ZNK13InstanceKlass20hash_offset_in_bytesEP7oopDesc8markWord>
 14c8042:	c1 ef 0d             	shr    $0xd,%edi
 14c8045:	8b 08                	mov    (%rax),%ecx
 14c8047:	48 8d 05 9a 8c 30 00 	lea    0x308c9a(%rip),%rax        # 17d0ce8 <_ZN23CompressedKlassPointers5_baseE>
 14c804e:	48 d3 e7             	shl    %cl,%rdi
 14c8051:	48 03 38             	add    (%rax),%rdi
 14c8054:	48 8b 07             	mov    (%rdi),%rax
 14c8057:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
 14c805e:	48 39 d0             	cmp    %rdx,%rax
 14c8061:	75 28                	jne    14c808b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x48b>
 14c8063:	48 63 87 40 01 00 00 	movslq 0x140(%rdi),%rax
 14c806a:	45 8b 04 06          	mov    (%r14,%rax,1),%r8d
 14c806e:	e9 57 fc ff ff       	jmp    14c7cca <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xca>
 14c8073:	48 83 c4 28          	add    $0x28,%rsp
 14c8077:	4c 89 f6             	mov    %r14,%rsi
 14c807a:	31 ff                	xor    %edi,%edi
 14c807c:	5b                   	pop    %rbx
 14c807d:	41 5c                	pop    %r12
 14c807f:	41 5d                	pop    %r13
 14c8081:	41 5e                	pop    %r14
 14c8083:	41 5f                	pop    %r15
 14c8085:	5d                   	pop    %rbp
 14c8086:	e9 d5 f9 ff ff       	jmp    14c7a60 <_ZN18ObjectSynchronizer13get_next_hashEP6ThreadP7oopDesc>
 14c808b:	4c 89 fa             	mov    %r15,%rdx
 14c808e:	4c 89 f6             	mov    %r14,%rsi
 14c8091:	ff d0                	call   *%rax
 14c8093:	eb d5                	jmp    14c806a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x46a>
 14c8095:	48 8d 05 9c 9e 30 00 	lea    0x309e9c(%rip),%rax        # 17d1f38 <hashCode>
 14c809c:	48 8b 00             	mov    (%rax),%rax
 14c809f:	e9 de fe ff ff       	jmp    14c7f82 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x382>
