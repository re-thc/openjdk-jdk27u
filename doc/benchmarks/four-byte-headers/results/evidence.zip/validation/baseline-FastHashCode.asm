
/workspace/work/baseline/image/lib/server/libjvm.so:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000014868a0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc>:
 14868a0:	55                   	push   %rbp
 14868a1:	49 89 f9             	mov    %rdi,%r9
 14868a4:	49 b8 ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r8
 14868ab:	fc ff ff 
 14868ae:	48 8d 15 cb f9 0e ff 	lea    -0xf10635(%rip),%rdx        # 576280 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x240>
 14868b5:	48 89 e5             	mov    %rsp,%rbp
 14868b8:	53                   	push   %rbx
 14868b9:	48 83 ec 28          	sub    $0x28,%rsp
 14868bd:	48 8d 1d 50 71 30 00 	lea    0x307150(%rip),%rbx        # 178da14 <UseObjectMonitorTable>
 14868c4:	48 8b 3e             	mov    (%rsi),%rdi
 14868c7:	80 3b 00             	cmpb   $0x0,(%rbx)
 14868ca:	75 10                	jne    14868dc <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x3c>
 14868cc:	48 89 f8             	mov    %rdi,%rax
 14868cf:	83 e0 03             	and    $0x3,%eax
 14868d2:	48 83 f8 02          	cmp    $0x2,%rax
 14868d6:	0f 84 04 01 00 00    	je     14869e0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x140>
 14868dc:	48 89 f8             	mov    %rdi,%rax
 14868df:	48 c1 e8 0b          	shr    $0xb,%rax
 14868e3:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 14868e8:	0f 85 da 02 00 00    	jne    1486bc8 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x328>
 14868ee:	48 8d 05 c3 73 30 00 	lea    0x3073c3(%rip),%rax        # 178dcb8 <hashCode>
 14868f5:	48 83 38 04          	cmpq   $0x4,(%rax)
 14868f9:	0f 87 32 01 00 00    	ja     1486a31 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x191>
 14868ff:	48 8b 00             	mov    (%rax),%rax
 1486902:	48 63 04 82          	movslq (%rdx,%rax,4),%rax
 1486906:	48 01 d0             	add    %rdx,%rax
 1486909:	ff e0                	jmp    *%rax
 148690b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1486910:	b8 00 08 00 00       	mov    $0x800,%eax
 1486915:	41 bb 01 00 00 00    	mov    $0x1,%r11d
 148691b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1486920:	49 89 fa             	mov    %rdi,%r10
 1486923:	4d 21 c2             	and    %r8,%r10
 1486926:	49 09 c2             	or     %rax,%r10
 1486929:	48 89 f8             	mov    %rdi,%rax
 148692c:	f0 4c 0f b1 16       	lock cmpxchg %r10,(%rsi)
 1486931:	48 39 c7             	cmp    %rax,%rdi
 1486934:	75 8e                	jne    14868c4 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x24>
 1486936:	48 8b 5d f8          	mov    -0x8(%rbp),%rbx
 148693a:	4c 89 d8             	mov    %r11,%rax
 148693d:	c9                   	leave
 148693e:	c3                   	ret
 148693f:	90                   	nop
 1486940:	48 89 f0             	mov    %rsi,%rax
 1486943:	49 89 f2             	mov    %rsi,%r10
 1486946:	49 c1 fa 08          	sar    $0x8,%r10
 148694a:	48 c1 f8 03          	sar    $0x3,%rax
 148694e:	4c 31 d0             	xor    %r10,%rax
 1486951:	4c 63 15 68 42 38 00 	movslq 0x384268(%rip),%r10        # 180abc0 <_ZL5GVars+0x40>
 1486958:	4c 31 d0             	xor    %r10,%rax
 148695b:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 1486960:	49 89 c3             	mov    %rax,%r11
 1486963:	74 4b                	je     14869b0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x110>
 1486965:	48 c1 e0 0b          	shl    $0xb,%rax
 1486969:	eb b5                	jmp    1486920 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x80>
 148696b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1486970:	48 89 75 d8          	mov    %rsi,-0x28(%rbp)
 1486974:	4c 89 4d e0          	mov    %r9,-0x20(%rbp)
 1486978:	48 89 7d e8          	mov    %rdi,-0x18(%rbp)
 148697c:	e8 9f ab d1 ff       	call   11a1520 <_ZN2os6randomEv>
 1486981:	48 8b 7d e8          	mov    -0x18(%rbp),%rdi
 1486985:	4c 8b 4d e0          	mov    -0x20(%rbp),%r9
 1486989:	49 b8 ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r8
 1486990:	fc ff ff 
 1486993:	48 98                	cltq
 1486995:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
 1486999:	48 8d 15 e0 f8 0e ff 	lea    -0xf10720(%rip),%rdx        # 576280 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x240>
 14869a0:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 14869a5:	49 89 c3             	mov    %rax,%r11
 14869a8:	75 bb                	jne    1486965 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xc5>
 14869aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 14869b0:	b8 00 68 5d 00       	mov    $0x5d6800,%eax
 14869b5:	41 bb ad 0b 00 00    	mov    $0xbad,%r11d
 14869bb:	e9 60 ff ff ff       	jmp    1486920 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x80>
 14869c0:	48 89 f0             	mov    %rsi,%rax
 14869c3:	eb 96                	jmp    148695b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xbb>
 14869c5:	0f 1f 00             	nopl   (%rax)
 14869c8:	8b 05 32 42 38 00    	mov    0x384232(%rip),%eax        # 180ac00 <_ZL5GVars+0x80>
 14869ce:	83 c0 01             	add    $0x1,%eax
 14869d1:	89 05 29 42 38 00    	mov    %eax,0x384229(%rip)        # 180ac00 <_ZL5GVars+0x80>
 14869d7:	48 98                	cltq
 14869d9:	eb 80                	jmp    148695b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xbb>
 14869db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 14869e0:	48 83 f7 02          	xor    $0x2,%rdi
 14869e4:	4c 8b 1f             	mov    (%rdi),%r11
 14869e7:	49 c1 eb 0b          	shr    $0xb,%r11
 14869eb:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
 14869f2:	0f 85 98 00 00 00    	jne    1486a90 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x1f0>
 14869f8:	48 8b 0f             	mov    (%rdi),%rcx
 14869fb:	48 89 c8             	mov    %rcx,%rax
 14869fe:	48 c1 e8 0b          	shr    $0xb,%rax
 1486a02:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 1486a07:	0f 85 bb 01 00 00    	jne    1486bc8 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x328>
 1486a0d:	48 8d 05 a4 72 30 00 	lea    0x3072a4(%rip),%rax        # 178dcb8 <hashCode>
 1486a14:	48 83 38 04          	cmpq   $0x4,(%rax)
 1486a18:	0f 87 b2 01 00 00    	ja     1486bd0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x330>
 1486a1e:	48 8b 00             	mov    (%rax),%rax
 1486a21:	4c 8d 15 6c f8 0e ff 	lea    -0xf10794(%rip),%r10        # 576294 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x254>
 1486a28:	49 63 04 82          	movslq (%r10,%rax,4),%rax
 1486a2c:	4c 01 d0             	add    %r10,%rax
 1486a2f:	ff e0                	jmp    *%rax
 1486a31:	66 41 0f 6e 81 2c 04 	movd   0x42c(%r9),%xmm0
 1486a38:	00 00 
 1486a3a:	41 8b 81 24 04 00 00 	mov    0x424(%r9),%eax
 1486a41:	66 41 0f 6e 99 28 04 	movd   0x428(%r9),%xmm3
 1486a48:	00 00 
 1486a4a:	41 89 c2             	mov    %eax,%r10d
 1486a4d:	41 c1 e2 0b          	shl    $0xb,%r10d
 1486a51:	44 31 d0             	xor    %r10d,%eax
 1486a54:	45 8b 91 20 04 00 00 	mov    0x420(%r9),%r10d
 1486a5b:	45 89 d3             	mov    %r10d,%r11d
 1486a5e:	66 41 0f 6e d2       	movd   %r10d,%xmm2
 1486a63:	41 c1 eb 13          	shr    $0x13,%r11d
 1486a67:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
 1486a6b:	45 31 d3             	xor    %r10d,%r11d
 1486a6e:	41 31 c3             	xor    %eax,%r11d
 1486a71:	c1 e8 08             	shr    $0x8,%eax
 1486a74:	44 31 d8             	xor    %r11d,%eax
 1486a77:	66 0f 6e c8          	movd   %eax,%xmm1
 1486a7b:	66 0f 62 cb          	punpckldq %xmm3,%xmm1
 1486a7f:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
 1486a83:	41 0f 11 89 20 04 00 	movups %xmm1,0x420(%r9)
 1486a8a:	00 
 1486a8b:	e9 cb fe ff ff       	jmp    148695b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xbb>
 1486a90:	8b 97 ac 00 00 00    	mov    0xac(%rdi),%edx
 1486a96:	85 d2                	test   %edx,%edx
 1486a98:	0f 89 98 fe ff ff    	jns    1486936 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x96>
 1486a9e:	4c 89 4d e0          	mov    %r9,-0x20(%rbp)
 1486aa2:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 1486aa6:	e8 45 30 cf ff       	call   1179af0 <_ZN13ObjectMonitor36install_displaced_markword_in_objectEP7oopDesc>
 1486aab:	48 8b 75 e8          	mov    -0x18(%rbp),%rsi
 1486aaf:	4c 8b 4d e0          	mov    -0x20(%rbp),%r9
 1486ab3:	49 b8 ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r8
 1486aba:	fc ff ff 
 1486abd:	48 8d 15 bc f7 0e ff 	lea    -0xf10844(%rip),%rdx        # 576280 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x240>
 1486ac4:	e9 fb fd ff ff       	jmp    14868c4 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x24>
 1486ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1486ad0:	41 ba 00 08 00 00    	mov    $0x800,%r10d
 1486ad6:	41 bb 01 00 00 00    	mov    $0x1,%r11d
 1486adc:	0f 1f 40 00          	nopl   0x0(%rax)
 1486ae0:	48 b8 ff 07 00 00 00 	movabs $0xfffffc00000007ff,%rax
 1486ae7:	fc ff ff 
 1486aea:	48 21 c8             	and    %rcx,%rax
 1486aed:	49 09 c2             	or     %rax,%r10
 1486af0:	48 89 c8             	mov    %rcx,%rax
 1486af3:	f0 4c 0f b1 17       	lock cmpxchg %r10,(%rdi)
 1486af8:	49 89 c2             	mov    %rax,%r10
 1486afb:	49 c1 ea 0b          	shr    $0xb,%r10
 1486aff:	41 81 e2 ff ff ff 7f 	and    $0x7fffffff,%r10d
 1486b06:	48 39 c1             	cmp    %rax,%rcx
 1486b09:	8b 87 ac 00 00 00    	mov    0xac(%rdi),%eax
 1486b0f:	4d 0f 45 da          	cmovne %r10,%r11
 1486b13:	85 c0                	test   %eax,%eax
 1486b15:	0f 89 1b fe ff ff    	jns    1486936 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x96>
 1486b1b:	80 3b 00             	cmpb   $0x0,(%rbx)
 1486b1e:	0f 84 7a ff ff ff    	je     1486a9e <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x1fe>
 1486b24:	48 8b 5d f8          	mov    -0x8(%rbp),%rbx
 1486b28:	4c 89 d8             	mov    %r11,%rax
 1486b2b:	c9                   	leave
 1486b2c:	c3                   	ret
 1486b2d:	0f 1f 00             	nopl   (%rax)
 1486b30:	48 89 f0             	mov    %rsi,%rax
 1486b33:	49 89 f2             	mov    %rsi,%r10
 1486b36:	49 c1 fa 08          	sar    $0x8,%r10
 1486b3a:	48 c1 f8 03          	sar    $0x3,%rax
 1486b3e:	4c 31 d0             	xor    %r10,%rax
 1486b41:	4c 63 15 78 40 38 00 	movslq 0x384078(%rip),%r10        # 180abc0 <_ZL5GVars+0x40>
 1486b48:	4c 31 d0             	xor    %r10,%rax
 1486b4b:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
 1486b50:	49 89 c3             	mov    %rax,%r11
 1486b53:	74 5b                	je     1486bb0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x310>
 1486b55:	49 89 c2             	mov    %rax,%r10
 1486b58:	49 c1 e2 0b          	shl    $0xb,%r10
 1486b5c:	eb 82                	jmp    1486ae0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x240>
 1486b5e:	66 90                	xchg   %ax,%ax
 1486b60:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 1486b64:	4c 89 4d d8          	mov    %r9,-0x28(%rbp)
 1486b68:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
 1486b6c:	48 89 7d e8          	mov    %rdi,-0x18(%rbp)
 1486b70:	e8 ab a9 d1 ff       	call   11a1520 <_ZN2os6randomEv>
 1486b75:	48 8b 7d e8          	mov    -0x18(%rbp),%rdi
 1486b79:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
 1486b7d:	4c 8b 4d d8          	mov    -0x28(%rbp),%r9
 1486b81:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1486b85:	48 98                	cltq
 1486b87:	eb c2                	jmp    1486b4b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2ab>
 1486b89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1486b90:	48 89 f0             	mov    %rsi,%rax
 1486b93:	eb b6                	jmp    1486b4b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2ab>
 1486b95:	0f 1f 00             	nopl   (%rax)
 1486b98:	8b 05 62 40 38 00    	mov    0x384062(%rip),%eax        # 180ac00 <_ZL5GVars+0x80>
 1486b9e:	83 c0 01             	add    $0x1,%eax
 1486ba1:	89 05 59 40 38 00    	mov    %eax,0x384059(%rip)        # 180ac00 <_ZL5GVars+0x80>
 1486ba7:	48 98                	cltq
 1486ba9:	eb a0                	jmp    1486b4b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2ab>
 1486bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1486bb0:	41 ba 00 68 5d 00    	mov    $0x5d6800,%r10d
 1486bb6:	41 bb ad 0b 00 00    	mov    $0xbad,%r11d
 1486bbc:	e9 1f ff ff ff       	jmp    1486ae0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x240>
 1486bc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1486bc8:	49 89 c3             	mov    %rax,%r11
 1486bcb:	e9 66 fd ff ff       	jmp    1486936 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x96>
 1486bd0:	66 41 0f 6e 81 2c 04 	movd   0x42c(%r9),%xmm0
 1486bd7:	00 00 
 1486bd9:	41 8b 81 24 04 00 00 	mov    0x424(%r9),%eax
 1486be0:	66 41 0f 6e a9 28 04 	movd   0x428(%r9),%xmm5
 1486be7:	00 00 
 1486be9:	41 89 c2             	mov    %eax,%r10d
 1486bec:	41 c1 e2 0b          	shl    $0xb,%r10d
 1486bf0:	44 31 d0             	xor    %r10d,%eax
 1486bf3:	45 8b 91 20 04 00 00 	mov    0x420(%r9),%r10d
 1486bfa:	45 89 d3             	mov    %r10d,%r11d
 1486bfd:	66 41 0f 6e e2       	movd   %r10d,%xmm4
 1486c02:	41 c1 eb 13          	shr    $0x13,%r11d
 1486c06:	66 0f 62 c4          	punpckldq %xmm4,%xmm0
 1486c0a:	45 31 d3             	xor    %r10d,%r11d
 1486c0d:	41 31 c3             	xor    %eax,%r11d
 1486c10:	c1 e8 08             	shr    $0x8,%eax
 1486c13:	44 31 d8             	xor    %r11d,%eax
 1486c16:	66 0f 6e c8          	movd   %eax,%xmm1
 1486c1a:	66 0f 62 cd          	punpckldq %xmm5,%xmm1
 1486c1e:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
 1486c22:	41 0f 11 89 20 04 00 	movups %xmm1,0x420(%r9)
 1486c29:	00 
 1486c2a:	e9 1c ff ff ff       	jmp    1486b4b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2ab>
