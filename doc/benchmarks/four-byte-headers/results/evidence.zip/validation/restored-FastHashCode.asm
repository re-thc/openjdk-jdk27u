
/workspace/openjdk-jdk27u/build/cloud-gcc16/support/modules_libs/java.base/server/libjvm.so:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000014c8010 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc>:
 14c8010:	48 8d 05 b9 f3 33 00 	lea    0x33f3b9(%rip),%rax        # 18073d0 <UseFourByteObjectHeaders>
 14c8017:	80 38 00             	cmpb   $0x0,(%rax)
 14c801a:	0f 85 40 01 00 00    	jne    14c8160 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x150>
 14c8020:	55                   	push   %rbp
 14c8021:	48 89 f9             	mov    %rdi,%rcx
 14c8024:	49 ba ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r10
 14c802b:	fc ff ff 
 14c802e:	4c 8d 05 b3 16 0b ff 	lea    -0xf4e94d(%rip),%r8        # 5796e8 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x268>
 14c8035:	48 89 e5             	mov    %rsp,%rbp
 14c8038:	48 83 ec 20          	sub    $0x20,%rsp
 14c803c:	48 8b 3e             	mov    (%rsi),%rdi
 14c803f:	48 8d 05 0e 9d 30 00 	lea    0x309d0e(%rip),%rax        # 17d1d54 <UseObjectMonitorTable>
 14c8046:	80 38 00             	cmpb   $0x0,(%rax)
 14c8049:	75 10                	jne    14c805b <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x4b>
 14c804b:	48 89 f8             	mov    %rdi,%rax
 14c804e:	83 e0 03             	and    $0x3,%eax
 14c8051:	48 83 f8 02          	cmp    $0x2,%rax
 14c8055:	0f 84 15 01 00 00    	je     14c8170 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x160>
 14c805b:	48 89 fa             	mov    %rdi,%rdx
 14c805e:	48 c1 ea 0b          	shr    $0xb,%rdx
 14c8062:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c8068:	75 4c                	jne    14c80b6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xa6>
 14c806a:	48 8d 05 87 9f 30 00 	lea    0x309f87(%rip),%rax        # 17d1ff8 <hashCode>
 14c8071:	48 83 38 04          	cmpq   $0x4,(%rax)
 14c8075:	0f 87 cd 01 00 00    	ja     14c8248 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x238>
 14c807b:	48 8b 00             	mov    (%rax),%rax
 14c807e:	49 63 04 80          	movslq (%r8,%rax,4),%rax
 14c8082:	4c 01 c0             	add    %r8,%rax
 14c8085:	ff e0                	jmp    *%rax
 14c8087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 14c808e:	00 00 
 14c8090:	b8 00 08 00 00       	mov    $0x800,%eax
 14c8095:	ba 01 00 00 00       	mov    $0x1,%edx
 14c809a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 14c80a0:	49 89 fb             	mov    %rdi,%r11
 14c80a3:	4d 21 d3             	and    %r10,%r11
 14c80a6:	49 09 c3             	or     %rax,%r11
 14c80a9:	48 89 f8             	mov    %rdi,%rax
 14c80ac:	f0 4c 0f b1 1e       	lock cmpxchg %r11,(%rsi)
 14c80b1:	48 39 c7             	cmp    %rax,%rdi
 14c80b4:	75 86                	jne    14c803c <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2c>
 14c80b6:	c9                   	leave
 14c80b7:	48 89 d0             	mov    %rdx,%rax
 14c80ba:	c3                   	ret
 14c80bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 14c80c0:	48 89 f2             	mov    %rsi,%rdx
 14c80c3:	48 89 f0             	mov    %rsi,%rax
 14c80c6:	48 c1 f8 08          	sar    $0x8,%rax
 14c80ca:	48 c1 fa 03          	sar    $0x3,%rdx
 14c80ce:	48 31 c2             	xor    %rax,%rdx
 14c80d1:	48 63 05 a8 71 38 00 	movslq 0x3871a8(%rip),%rax        # 184f280 <_ZL5GVars+0x40>
 14c80d8:	48 31 c2             	xor    %rax,%rdx
 14c80db:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c80e1:	74 4d                	je     14c8130 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x120>
 14c80e3:	48 89 d0             	mov    %rdx,%rax
 14c80e6:	48 c1 e0 0b          	shl    $0xb,%rax
 14c80ea:	eb b4                	jmp    14c80a0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x90>
 14c80ec:	0f 1f 40 00          	nopl   0x0(%rax)
 14c80f0:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 14c80f4:	48 89 4d f0          	mov    %rcx,-0x10(%rbp)
 14c80f8:	48 89 7d f8          	mov    %rdi,-0x8(%rbp)
 14c80fc:	e8 3f 75 cf ff       	call   11bf640 <_ZN2os6randomEv>
 14c8101:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
 14c8105:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 14c8109:	49 ba ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r10
 14c8110:	fc ff ff 
 14c8113:	48 63 d0             	movslq %eax,%rdx
 14c8116:	48 8b 75 e8          	mov    -0x18(%rbp),%rsi
 14c811a:	4c 8d 05 c7 15 0b ff 	lea    -0xf4ea39(%rip),%r8        # 5796e8 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x268>
 14c8121:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c8127:	75 ba                	jne    14c80e3 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xd3>
 14c8129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 14c8130:	b8 00 68 5d 00       	mov    $0x5d6800,%eax
 14c8135:	ba ad 0b 00 00       	mov    $0xbad,%edx
 14c813a:	e9 61 ff ff ff       	jmp    14c80a0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x90>
 14c813f:	90                   	nop
 14c8140:	48 89 f2             	mov    %rsi,%rdx
 14c8143:	eb 96                	jmp    14c80db <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xcb>
 14c8145:	0f 1f 00             	nopl   (%rax)
 14c8148:	8b 15 72 71 38 00    	mov    0x387172(%rip),%edx        # 184f2c0 <_ZL5GVars+0x80>
 14c814e:	83 c2 01             	add    $0x1,%edx
 14c8151:	89 15 69 71 38 00    	mov    %edx,0x387169(%rip)        # 184f2c0 <_ZL5GVars+0x80>
 14c8157:	48 63 d2             	movslq %edx,%rdx
 14c815a:	e9 7c ff ff ff       	jmp    14c80db <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xcb>
 14c815f:	90                   	nop
 14c8160:	48 89 f7             	mov    %rsi,%rdi
 14c8163:	e9 38 fd ff ff       	jmp    14c7ea0 <_ZL19four_byte_hash_codeP7oopDesc>
 14c8168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 14c816f:	00 
 14c8170:	48 83 f7 02          	xor    $0x2,%rdi
 14c8174:	48 8b 17             	mov    (%rdi),%rdx
 14c8177:	49 89 fb             	mov    %rdi,%r11
 14c817a:	48 c1 ea 0b          	shr    $0xb,%rdx
 14c817e:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c8184:	0f 85 16 01 00 00    	jne    14c82a0 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x290>
 14c818a:	4c 8b 0f             	mov    (%rdi),%r9
 14c818d:	4c 89 ca             	mov    %r9,%rdx
 14c8190:	48 c1 ea 0b          	shr    $0xb,%rdx
 14c8194:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c819a:	0f 85 16 ff ff ff    	jne    14c80b6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xa6>
 14c81a0:	48 89 7d f8          	mov    %rdi,-0x8(%rbp)
 14c81a4:	48 89 cf             	mov    %rcx,%rdi
 14c81a7:	4c 89 4d f0          	mov    %r9,-0x10(%rbp)
 14c81ab:	48 89 75 e0          	mov    %rsi,-0x20(%rbp)
 14c81af:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
 14c81b3:	e8 e8 f0 ff ff       	call   14c72a0 <_ZL20get_next_hash_legacyP6ThreadP7oopDesc>
 14c81b8:	4c 8b 4d f0          	mov    -0x10(%rbp),%r9
 14c81bc:	4c 8b 5d f8          	mov    -0x8(%rbp),%r11
 14c81c0:	48 ba ff 07 00 00 00 	movabs $0xfffffc00000007ff,%rdx
 14c81c7:	fc ff ff 
 14c81ca:	48 89 c7             	mov    %rax,%rdi
 14c81cd:	48 c1 e0 0b          	shl    $0xb,%rax
 14c81d1:	4c 21 ca             	and    %r9,%rdx
 14c81d4:	48 09 c2             	or     %rax,%rdx
 14c81d7:	4c 89 c8             	mov    %r9,%rax
 14c81da:	f0 49 0f b1 13       	lock cmpxchg %rdx,(%r11)
 14c81df:	48 89 c2             	mov    %rax,%rdx
 14c81e2:	48 c1 ea 0b          	shr    $0xb,%rdx
 14c81e6:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
 14c81ec:	49 39 c1             	cmp    %rax,%r9
 14c81ef:	41 8b 83 ac 00 00 00 	mov    0xac(%r11),%eax
 14c81f6:	48 0f 44 d7          	cmove  %rdi,%rdx
 14c81fa:	85 c0                	test   %eax,%eax
 14c81fc:	0f 89 b4 fe ff ff    	jns    14c80b6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xa6>
 14c8202:	48 8d 05 4b 9b 30 00 	lea    0x309b4b(%rip),%rax        # 17d1d54 <UseObjectMonitorTable>
 14c8209:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
 14c820d:	48 8b 75 e0          	mov    -0x20(%rbp),%rsi
 14c8211:	80 38 00             	cmpb   $0x0,(%rax)
 14c8214:	0f 85 9c fe ff ff    	jne    14c80b6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xa6>
 14c821a:	4c 89 df             	mov    %r11,%rdi
 14c821d:	48 89 4d f0          	mov    %rcx,-0x10(%rbp)
 14c8221:	48 89 75 f8          	mov    %rsi,-0x8(%rbp)
 14c8225:	e8 66 f6 cc ff       	call   1197890 <_ZN13ObjectMonitor36install_displaced_markword_in_objectEP7oopDesc>
 14c822a:	48 8b 75 f8          	mov    -0x8(%rbp),%rsi
 14c822e:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 14c8232:	49 ba ff 07 00 00 00 	movabs $0xfffffc00000007ff,%r10
 14c8239:	fc ff ff 
 14c823c:	4c 8d 05 a5 14 0b ff 	lea    -0xf4eb5b(%rip),%r8        # 5796e8 <_ZN12StubRoutines3x8616_crc_by128_masksE+0x268>
 14c8243:	e9 f4 fd ff ff       	jmp    14c803c <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x2c>
 14c8248:	8b 91 24 04 00 00    	mov    0x424(%rcx),%edx
 14c824e:	66 0f 6e 81 2c 04 00 	movd   0x42c(%rcx),%xmm0
 14c8255:	00 
 14c8256:	66 0f 6e 99 28 04 00 	movd   0x428(%rcx),%xmm3
 14c825d:	00 
 14c825e:	89 d0                	mov    %edx,%eax
 14c8260:	c1 e0 0b             	shl    $0xb,%eax
 14c8263:	31 c2                	xor    %eax,%edx
 14c8265:	8b 81 20 04 00 00    	mov    0x420(%rcx),%eax
 14c826b:	41 89 c3             	mov    %eax,%r11d
 14c826e:	66 0f 6e d0          	movd   %eax,%xmm2
 14c8272:	41 c1 eb 13          	shr    $0x13,%r11d
 14c8276:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
 14c827a:	41 31 c3             	xor    %eax,%r11d
 14c827d:	41 31 d3             	xor    %edx,%r11d
 14c8280:	c1 ea 08             	shr    $0x8,%edx
 14c8283:	44 31 da             	xor    %r11d,%edx
 14c8286:	66 0f 6e ca          	movd   %edx,%xmm1
 14c828a:	66 0f 62 cb          	punpckldq %xmm3,%xmm1
 14c828e:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
 14c8292:	0f 11 89 20 04 00 00 	movups %xmm1,0x420(%rcx)
 14c8299:	e9 3d fe ff ff       	jmp    14c80db <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xcb>
 14c829e:	66 90                	xchg   %ax,%ax
 14c82a0:	8b bf ac 00 00 00    	mov    0xac(%rdi),%edi
 14c82a6:	85 ff                	test   %edi,%edi
 14c82a8:	0f 89 08 fe ff ff    	jns    14c80b6 <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0xa6>
 14c82ae:	e9 67 ff ff ff       	jmp    14c821a <_ZN18ObjectSynchronizer12FastHashCodeEP6ThreadP7oopDesc+0x20a>
