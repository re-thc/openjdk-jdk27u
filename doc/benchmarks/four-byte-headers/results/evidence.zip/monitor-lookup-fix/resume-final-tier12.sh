#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/monitor-fix
[[ $(cat "$root/benchmarks.finished") == 0 ]]
python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
assert p.read_text()==original
p.write_text(original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));'))
PY
restore_helper() {
  python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
p.write_bytes(Path('/workspace/work/typical-use/CustomRunTest.java.original').read_bytes())
PY
}
trap restore_helper EXIT
export JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2'
command=(python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg
  -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m
  -jdk:"$root/full-lookup-image"
  -nativepath:"$root/native-test-image/hotspot/jtreg/native"
  -w:"$root/jtreg-tier12/work" -r:"$root/jtreg-tier12/report"
  -automatic -timeoutFactor:4 -verbose:summary
  -exclude:test/hotspot/jtreg/ProblemList.txt -exclude:/workspace/work/container-core-problems.txt
  -javaoptions:-Xmx512m -status:fail,error,notRun)
"${command[@]}" -conc:1 test/hotspot/jtreg/applications/ctw > "$root/tier12-ctw-retry.log" 2>&1
set +e
"${command[@]}" -conc:2 test/hotspot/jtreg/:tier1 test/hotspot/jtreg/:tier2 > "$root/tier12-resume.log" 2>&1
result=$?
printf '%s\n' "$result" > "$root/default-tier12.finished"
exit "$result"
