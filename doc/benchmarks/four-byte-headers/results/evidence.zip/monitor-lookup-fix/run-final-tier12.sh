#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
while [[ ! -f /workspace/work/monitor-fix/benchmark-driver.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/monitor-fix/benchmark-driver.finished) == 0 ]] || exit 1
python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
assert p.read_text()==original
p.write_text(original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));'))
PY
restore_helper() {
  python3 - <<'PY'
from pathlib import Path
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
bounded=original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));')
assert p.read_text() in (original,bounded)
p.write_text(original)
PY
}
trap restore_helper EXIT
export JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2'
command=(python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg
  -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m
  -jdk:/workspace/work/monitor-fix/full-lookup-image
  -nativepath:/workspace/work/monitor-fix/native-test-image/hotspot/jtreg/native
  -w:/workspace/work/monitor-fix/jtreg-tier12/work
  -r:/workspace/work/monitor-fix/jtreg-tier12/report
  -automatic -timeoutFactor:4 -verbose:summary
  -exclude:test/hotspot/jtreg/ProblemList.txt -exclude:/workspace/work/container-core-problems.txt
  -javaoptions:-Xmx512m)
"${command[@]}" -listTests test/hotspot/jtreg/:tier1 test/hotspot/jtreg/:tier2 > /workspace/work/monitor-fix/default-tier12-selected.txt 2>&1
set +e
"${command[@]}" -conc:4 test/hotspot/jtreg/:tier1 test/hotspot/jtreg/:tier2 > /workspace/work/monitor-fix/default-tier12.log 2>&1
result=$?
printf '%s\n' "$result" > /workspace/work/monitor-fix/default-tier12.finished
exit "$result"
