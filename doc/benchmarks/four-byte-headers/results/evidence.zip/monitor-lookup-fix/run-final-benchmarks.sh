#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
[[ $(cat /workspace/work/monitor-fix/final-validation.finished) == 0 ]]
while [[ ! -f /workspace/work/monitor-fix/jcstress.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/monitor-fix/jcstress.finished) == 0 ]]
python3 - <<'PY'
import os
from pathlib import Path
assert not any(k in os.environ for k in ['JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS'])
assert Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java').read_bytes()==Path('/workspace/work/typical-use/CustomRunTest.java.original').read_bytes()
PY
export BASELINE_JDK=/workspace/work/baseline/image
export CANDIDATE_JDK=/workspace/work/monitor-fix/full-lookup-image
export RESULTS_DIR=/workspace/work/monitor-fix/results
export RENAISSANCE_JAR=/workspace/work/renaissance-gpl-0.16.1.jar
mkdir -p "$RESULTS_DIR"
printf 'Timing starts %s\n' "$(date -u +%FT%TZ)"
python3 /workspace/work/subreaper.py bash doc/benchmarks/four-byte-headers/database.sh timing
python3 /workspace/work/subreaper.py python3 doc/benchmarks/four-byte-headers/petclinic-load.py "$BASELINE_JDK" "$CANDIDATE_JDK" /workspace/work/typical-use/petclinic/target/spring-petclinic-3.5.0-SNAPSHOT.jar "$RESULTS_DIR"
python3 /workspace/work/subreaper.py bash doc/benchmarks/four-byte-headers/database.sh memory
python3 doc/benchmarks/four-byte-headers/summarize-typical.py "$RESULTS_DIR" > /workspace/work/monitor-fix/typical-tables.md
printf '0\n' > /workspace/work/monitor-fix/benchmarks.finished
