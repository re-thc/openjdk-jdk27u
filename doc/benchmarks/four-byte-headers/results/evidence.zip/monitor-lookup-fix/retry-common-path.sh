#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/monitor-fix
while [[ ! -f $root/after-fastdebug-driver.finished ]]; do sleep 5; done
[[ $(cat "$root/after-fastdebug-driver.finished") == 2 ]]
for layout in default4 eight8 legacy12; do
  rg -q '\[  PASSED  \] 1398 tests\.' "$root/gtest-$layout.log"
done
mkdir -p "$root/before-common-path-adjustment"
mv "$root/jtreg-common" "$root/before-common-path-adjustment/jtreg-common"
mv "$root/final-common.log" "$root/before-common-path-adjustment/final-common.log"
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
  /workspace/toolchains/jtreg83/bin/jtreg \
  -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
  -jdk:"$root/fastdebug-image" \
  -nativepath:"$root/native-test-image/hotspot/gtest" \
  -w:"$root/jtreg-common/work" -r:"$root/jtreg-common/report" \
  -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' \
  test/hotspot/jtreg/:tier1_common > "$root/final-common.log" 2>&1
printf '0\n' > "$root/final-validation.finished"
