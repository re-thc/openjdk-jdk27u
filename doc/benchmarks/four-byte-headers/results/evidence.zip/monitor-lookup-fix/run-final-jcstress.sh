#!/usr/bin/env bash
set -euo pipefail
while [[ ! -f /workspace/work/monitor-fix/final-validation.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/monitor-fix/final-validation.finished) == 0 ]] || exit 1
cd /workspace/work/monitor-fix
image=/workspace/work/monitor-fix/full-lookup-image
mkdir -p jcstress-classes
"$image/bin/javac" -J-XX:ActiveProcessorCount=2 -cp '/workspace/work/jcstress/*' -processor org.openjdk.jcstress.infra.processors.JCStressTestProcessor -d jcstress-classes /workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/HashAndLock.java > jcstress-compile.log 2>&1
for gc in Serial G1 Z; do
  python3 /workspace/work/subreaper.py "$image/bin/java" --enable-native-access=ALL-UNNAMED -XX:ActiveProcessorCount=2 -cp '/workspace/work/monitor-fix/jcstress-classes:/workspace/work/jcstress/*' org.openjdk.jcstress.Main -t 'fourbyte.HashAndLock' -m quick -f 3 -iters 5 -time 200 -c 2 -af NONE -r "/workspace/work/monitor-fix/jcstress/$gc" -jvmArgsPrepend "--enable-native-access=ALL-UNNAMED -XX:+Use${gc}GC" > "/workspace/work/monitor-fix/jcstress-$gc.log" 2>&1
done
printf '0\n' > /workspace/work/monitor-fix/jcstress.finished
