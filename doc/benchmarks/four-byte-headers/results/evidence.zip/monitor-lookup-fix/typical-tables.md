| Workload | Metric | Original 8 bytes | Fork default 4 bytes | Change (95% interval) |
| --- | --- | ---: | ---: | ---: |
| db-shootout | duration (ms) | 4501.85 | 4750.15 | +5.4% [-6.7, +19.1] |
| db-shootout | post-GC heap (MiB) | 77.74 | 57.89 | -23.4% [-67.4, +79.9] |
| db-shootout | post-GC RSS (MiB) | 1099.03 | 1101.32 | +0.2% [-2.1, +2.6] |
| Spring Petclinic | throughput (requests/s) | 161.32 | 161.57 | +0.1% [-4.4, +4.9] |
| Spring Petclinic | p50 latency (ms) | 9.05 | 8.80 | -2.7% [-6.6, +1.2] |
| Spring Petclinic | p95 latency (ms) | 175.51 | 175.07 | -0.3% [-5.2, +4.9] |
| Spring Petclinic | p99 latency (ms) | 217.98 | 215.76 | -1.0% [-5.9, +4.2] |
| Spring Petclinic | post-GC heap (MiB) | 40.18 | 35.70 | -11.1% [-11.4, -10.9] |
| Spring Petclinic | RSS after load (MiB) | 724.86 | 704.75 | -2.7% [-7.8, +2.8] |
| Spring Petclinic | post-GC RSS (MiB) | 728.51 | 708.09 | -2.7% [-7.8, +2.7] |
| Spring Petclinic | ready startup (seconds) | 6.53 | 6.68 | +2.2% [-3.8, +8.7] |
| Spring Petclinic | busy heap (MiB) | 215.78 | 174.10 | -19.5% [-30.3, -7.1] |

Validated measured HTTP responses: 116,411; errors: zero.
Maximum load-driver CPU use: 0.08 CPU cores.
Database benchmark uses its upstream dummy validator; normal termination does not establish result correctness.
