#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/monitor-fix
while [[ ! -f $root/tier12-resume-driver.finished ]]; do sleep 5; done
result=$(cat "$root/tier12-resume-driver.finished")
[[ $result == 0 || $result == 2 ]]
if [[ $result == 2 ]]; then
  python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('/workspace/work/monitor-fix')
dest=root/'before-tier12-isolated-retries'
dest.mkdir(exist_ok=False)
shutil.copy2(root/'tier12-resume.log', dest/'tier12-resume.log')
failures=[]
for p in (root/'jtreg-tier12/work').rglob('*.jtr'):
    text=p.read_text(errors='replace')
    status=next((l for l in text.splitlines() if l.startswith('execStatus=')), 'Missing')
    if status.startswith('execStatus=Passed.'):
        continue
    assert any(s in text for s in ['unable to create native thread',
        'Resource temporarily unavailable', 'pthread_create failed (EAGAIN)']), (p,status)
    out=dest/'work'/p.relative_to(root/'jtreg-tier12/work')
    out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,out)
    failures.append(str(p.relative_to(root/'jtreg-tier12/work')))
assert failures
(root/'isolated-resource-retries.txt').write_text('\n'.join(failures)+'\n')
print('Preserved resource failures for serial retry:',len(failures))
p=Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java')
original=Path('/workspace/work/typical-use/CustomRunTest.java.original').read_text()
assert p.read_text()==original
p.write_text(original.replace('ExecutorService executor = Executors.newFixedThreadPool(tests.size());',
    'ExecutorService executor = Executors.newFixedThreadPool(\n                Math.min(tests.size(), Runtime.getRuntime().availableProcessors()));'))
PY
  restore_helper() {
    python3 - <<'PY'
from pathlib import Path
Path('test/hotspot/jtreg/compiler/lib/ir_framework/test/CustomRunTest.java').write_bytes(
    Path('/workspace/work/typical-use/CustomRunTest.java.original').read_bytes())
PY
  }
  trap restore_helper EXIT
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
    /workspace/toolchains/jtreg83/bin/jtreg \
    -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
    -jdk:"$root/full-lookup-image" \
    -nativepath:"$root/native-test-image/hotspot/jtreg/native" \
    -w:"$root/jtreg-tier12/work" -r:"$root/jtreg-tier12/report" \
    -automatic -conc:1 -timeoutFactor:4 -verbose:summary \
    -exclude:test/hotspot/jtreg/ProblemList.txt -exclude:/workspace/work/container-core-problems.txt \
    -javaoptions:-Xmx512m -status:fail,error,notRun \
    test/hotspot/jtreg/:tier1 test/hotspot/jtreg/:tier2 > "$root/tier12-serial-final.log" 2>&1
fi
python3 /workspace/work/validation/collect-jtreg.py \
  "$root/default-tier12-selected.txt" "$root/jtreg-tier12/work" \
  "$root/default-tier12-selected.csv"
python3 - <<'PY'
from pathlib import Path
p=Path('/workspace/work/monitor-fix/default-tier12-selected.csv')
p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
PY
printf '0\n' > "$root/default-tier12.finished"
