#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
ulimit -c unlimited
for flavor in release fastdebug; do
  image=/workspace/work/monitor-fix/full-lookup-image
  [[ $flavor != fastdebug ]] || image=/workspace/work/monitor-fix/fastdebug-image
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/hotspot/jtreg/native -w:/workspace/work/monitor-fix/jtreg-$flavor/work -r:/workspace/work/monitor-fix/jtreg-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/hotspot/jtreg/runtime/CompactObjectHeaders test/hotspot/jtreg/gc/stress/ihash test/hotspot/jtreg/runtime/CompressedOops > /workspace/work/monitor-fix/final-$flavor-focus.log 2>&1
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/jdk/jtreg/native -w:/workspace/work/monitor-fix/jtreg-size-$flavor/work -r:/workspace/work/monitor-fix/jtreg-size-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/jdk/java/lang/instrument/FourByteHeaderObjectSize.java 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id0' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id1' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id2' > /workspace/work/monitor-fix/final-$flavor-size.log 2>&1
done
image=/workspace/work/monitor-fix/fastdebug-image
gtest_dir=$PWD/build/fourbyte-fastdebug/hotspot/variant-server/libjvm/gtest
for layout in default4 eight8 legacy12; do
  flags=(-XX:ActiveProcessorCount=2)
  [[ $layout != eight8 ]] || flags+=(-XX:-UseFourByteObjectHeaders)
  [[ $layout != legacy12 ]] || flags+=(-XX:-UseCompactObjectHeaders)
  LD_LIBRARY_PATH=$gtest_dir python3 /workspace/work/subreaper.py "$gtest_dir/gtestLauncher" -jdk "$image" "${flags[@]}" > /workspace/work/monitor-fix/gtest-$layout.log 2>&1
done
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:/workspace/work/monitor-fix/native-test-image/hotspot/gtest -w:/workspace/work/monitor-fix/jtreg-common/work -r:/workspace/work/monitor-fix/jtreg-common/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/hotspot/jtreg/:tier1_common > /workspace/work/monitor-fix/final-common.log 2>&1
printf '0\n' > /workspace/work/monitor-fix/final-validation.finished
