"""Publish measurements with exact-image validation and honest broad-run status."""
import csv
import json
from pathlib import Path
import re
import shutil
import sys

root = Path('/workspace/work/final-jdk')
dest = Path('/workspace/openjdk-jdk27u/doc/benchmarks/four-byte-headers/results')
pending_ci = '--allow-pending-ci' in sys.argv[1:]
for name in ['build-and-validate.finished', 'final-validation.finished',
             'ci-followup.finished', 'jcstress.finished', 'jdk-ci-followup.finished', 'benchmarks.finished', 'memory-confirmation.finished']:
    assert (root / name).read_text().strip() == '0', name
if not pending_ci:
    assert (root / 'ci-final-passed.finished').read_text().strip() == '0'
with (root / 'default-focused-results.csv').open() as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 117 and all(r['status'].startswith('Passed.') for r in rows)
followup = []
for flavor in ['release', 'fastdebug']:
    for layout in ['default4', 'eight8', 'legacy12']:
        reports = sorted((root / f'ci-followup-{flavor}-{layout}/work').rglob('*.jtr'))
        assert len(reports) == 5, (flavor, layout, len(reports))
        for report in reports:
            fields = {}
            for line in report.read_text(errors='replace').splitlines():
                if line.startswith(('test=', 'execStatus=', 'totalTime=')):
                    key, value = line.split('=', 1)
                    fields[key] = re.sub(r'\\(.)', r'\1', value)
            assert fields['execStatus'].startswith('Passed.'), (report, fields)
            followup.append([flavor, layout, fields['test'], fields['execStatus'], fields.get('totalTime', '')])
with (root / 'ci-followup-results.csv').open('w') as f:
    w = csv.writer(f, lineterminator='\n')
    w.writerow(['flavor', 'layout', 'test', 'status', 'total_time'])
    w.writerows(followup)
p = root / 'manifest.json'
data = json.loads(p.read_text())
assert data['source_revision'] == '9b75f196c2a03528cd458957dcc4228c9be69ba3'
assert data['validation_revision'] == '9bf17e9327f79d5d13fe2e3ff9952b826f4aedf7'
ci = json.loads((root / 'final-ci-snapshot.json').read_text())
assert ci['run_id'] == 37560701755
assert ci['commit_sha'] == data['validation_revision']
assert len(ci['jobs']) == 29
assert all(j['status'] != 'completed' or j['conclusion'] == 'success' for j in ci['jobs'])
assert all(a['tests'] and not a['failures'] for a in ci['audit'])
if not pending_ci:
    assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in ci['jobs'])
    assert len(ci['audit']) == 24
    assert sum(a['native_passes'] > 0 for a in ci['audit']) == 6
    assert sum(a['job'].startswith('tier12 ') for a in ci['audit']) == 18
data['ci_publication_status'] = 'pending' if pending_ci else 'passed'
data['final_ci_run_id'] = ci['run_id']
data['final_ci_jobs_successful'] = sum(j['conclusion'] == 'success' for j in ci['jobs'])
data['final_ci_jtreg_passes'] = sum(a['jtreg_passes'] for a in ci['audit'])
data['final_ci_native_passes'] = sum(a['native_passes'] for a in ci['audit'])
data['additional_ci_regression_cases_passed'] = len(followup)
jdk_followup=[]
for flavor in ['release','fastdebug']:
 for prefix in ['jdk','hotspot','jfr']:
  reports=sorted((root/f'{prefix}-ci-after-{flavor}/work').rglob('*.jtr'))
  assert reports, (prefix,flavor)
  for report in reports:
   fields={}
   for line in report.read_text(errors='replace').splitlines():
    if line.startswith(('test=','execStatus=','totalTime=')):
     key,value=line.split('=',1);fields[key]=re.sub(r'\\(.)',r'\1',value)
   assert fields['execStatus'].startswith('Passed.'), (report,fields)
   jdk_followup.append([flavor,prefix,fields['test'],fields['execStatus'],fields.get('totalTime','')])
with (root/'jdk-ci-followup-results.csv').open('w') as f:
 w=csv.writer(f,lineterminator='\n');w.writerow(['flavor','suite','test','status','total_time']);w.writerows(jdk_followup)
data['jdk_followup_cases_passed']=len(jdk_followup)
for directory,key,expected in [('jfr-reproducer-after','immediate_jfr_reproducer_cases_passed',2),('jlink-eight-optout-after','jlink_eight_optout_cases_passed',1),('jdk-ci-after-baseline8','corrected_stock_array_boundary_cases_passed',1)]:
 reports=sorted((root/directory/'work').rglob('*.jtr'))
 assert len(reports)==expected,(directory,len(reports))
 for report in reports:
  assert any(line.startswith('execStatus=Passed.') for line in report.read_text(errors='replace').splitlines()),report
 data[key]=len(reports)
data['broad_validation'] = ('Final x64/AArch64 three-layout CI test jobs remain pending; all four builds passed. ' if pending_ci else 'Final x64/AArch64 three-layout tier1/tier2 GitHub Actions matrix passed. ') + 'Superseded local 4d9 run retained as incomplete diagnostic evidence.'
p.write_text(json.dumps(data, indent=2) + '\n')
applications = dest / 'applications'
applications.mkdir(parents=True, exist_ok=True)
for path in sorted((root / 'results').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.csv', '.sql'}:
        shutil.copy2(path, applications / path.name)
for name in ['manifest.json', 'ci-followup-results.csv','jdk-ci-followup-results.csv', 'final-ci-snapshot.json']:
    shutil.copy2(root / name, applications / name)
shutil.copy2(root / 'typical-tables.md', applications / 'summary.md')
shutil.copy2(root / 'default-focused-results.csv', dest / 'default-on-focused-results.csv')
shutil.copy2(Path('/workspace/work/final-copy/partial-tier12-results.csv'),
             dest / 'default-on-superseded-partial-tier12.csv')
shutil.copy2(Path('/workspace/work/final-copy/superseded-completed-after-retries.csv'),
             dest / 'default-on-superseded-after-retries.csv')
print('Staged final application results, 117 focused cases and 30 CI regression cases')
