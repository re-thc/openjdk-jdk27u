#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-jdk
cd /workspace/openjdk-jdk27u
[[ $(cat "$root/final-validation.finished") == 0 ]]
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
 /workspace/toolchains/jtreg83/bin/jtreg \
 -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
 -jdk:"$root/fastdebug-image" -w:"$root/ci-followup-fastdebug-legacy12/work" \
 -r:"$root/ci-followup-fastdebug-legacy12/report" -automatic -conc:1 \
 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m -XX:-UseCompactObjectHeaders' \
 'test/hotspot/jtreg/gc/arguments/TestUseCompressedOopsErgo.java#id2' \
 'test/hotspot/jtreg/gc/arguments/TestUseCompressedOopsErgo.java#id3' \
 test/hotspot/jtreg/runtime/cds/appcds/aotCache/SpecialCacheNames.java \
 >> "$root/ci-followup-fastdebug-legacy12.log" 2>&1
python3 - <<'PY'
from pathlib import Path
root=Path('/workspace/work/final-jdk')
for flavor in ['release','fastdebug']:
 for layout in ['default4','eight8','legacy12']:
  reports=sorted((root/f'ci-followup-{flavor}-{layout}/work').rglob('*.jtr'))
  assert len(reports)==5,(flavor,layout,len(reports))
  for p in reports:
   assert any(l.startswith('execStatus=Passed.') for l in p.read_text(errors='replace').splitlines()),p
(root/'ci-followup.finished').write_text('0\n')
PY
bash "$root/run-final-jcstress.sh" > "$root/jcstress-driver.log" 2>&1
printf '0\n' > "$root/build-and-validate.finished"
bash "$root/validate-jdk-followup.sh" > "$root/jdk-ci-followup-driver.log" 2>&1
