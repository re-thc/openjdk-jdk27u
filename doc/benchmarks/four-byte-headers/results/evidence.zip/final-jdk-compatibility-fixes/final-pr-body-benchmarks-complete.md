Use four-byte Lilliput 2 object headers by default in this JDK 27u fork on x64 and AArch64. Ordinary `java` runs need no enabling flag or experimental unlock. Serial, G1 and ZGC are supported; Parallel and Shenandoah are also adapted. Select eight bytes with `-XX:-UseFourByteObjectHeaders`, or twelve bytes with `-XX:-UseCompactObjectHeaders`.

**Draft pending the final x64/AArch64 test matrix. The complete final-code benchmark study and all final local checks have passed their validation. All four CI builds have passed.** Production source and immutable release/debug images are `9b75f196c2a`; test-only correction `9bf17e9327f` is the [final-source CI target](https://github.com/re-thc/openjdk-jdk27u/actions/runs/37560701755). Every final local check described below has completed.

## Changes and failures resolved

Port object/array/field layouts, interpreter/C1/C2 operations, collector hash preservation and object growth, ZGC relocation, CDS/AOT compatibility and Serviceability Agent decoding. Package six matching CDS archives for the three layouts, with and without compressed oops; jlink explicitly generates and force-loads all six variants.

The first Spring benchmark exposed a 27.3% throughput regression despite lower retained heap. Direct C2 monitor-table lookup now covers ordinary address-derived and stored hashes after a two-entry cache miss. Tests cover concurrent/recursive compiled locking, zero hashes, collisions and special layouts under Serial/G1/ZGC.

Default-on testing found nondeterministic static archives and debug GC assertion crashes. Dump-only hashing now uses deterministic heap-relative/class-name inputs; copy-time hashing uses captured class metadata and destination fields. The crashes and archive differences reproduce before these fixes and pass afterward with assertions intact.

Inherited JVM option opt-outs now work for AOT children. JFR old-object sampling is restored: JDK 27 already keeps leak-context edge indices in a side table, making the imported Lilliput restriction obsolete. Unchanged event/reference-chain tests pass. Array-boundary and missing-archive tests account for the new layout and six archive filenames while retaining their success/failure assertions. Matched stock-eight controls passed all five affected JDK/CDS cases; the preceding default-four image failed them.

## Completed final-image local validation

- **181 jtreg cases passed**: 117 focused/common/instrumentation, 30 option/AOT, 30 additional JDK/JFR, and four immediate/control cases. Release/debug and three-layout eligibility are recorded per case.
- **4,194 enabled native tests passed**: 1,398 in each of default four-byte, explicit eight-byte and legacy twelve-byte modes; 15 upstream disabled tests per layout.
- **126 JCStress configurations passed**: 42 each under Serial, G1 and ZGC, zero failures, soft errors or hard errors.
- The maximum-string boundary case also passes all nine JUnit executions in each of release, fastdebug and stock-eight modes. The initial test compile error and corrected test-only commit are retained.
- A superseded local 3,959-case broad selection completed 1,001 passing cases after unchanged resource retries; it remains **incomplete** and is preserved as diagnostic evidence. The final cross-platform matrix above supplies broad validation when complete.

## Final application measurements: stock JDK 27 default eight bytes versus fork default four bytes

Baseline `33e539f2d4a` versus candidate `9b75f196c2a`, immutable release images, ergonomic G1, fixed 512 MiB heap and four processors on one x64 host. The candidate uses **no enabling option**. No local tests/builds or profiler run during timings. Database: twelve JVMs per layout × sixteen operations, first eight discarded. Spring: six JVMs per layout, thirty-second warmup and sixty-second measured load. Layout order alternates.

| Workload | Metric | Stock default 8 bytes | Fork default 4 bytes | Change (95% interval) |
| --- | --- | ---: | ---: | ---: |
| db-shootout | Duration (ms) | 4434.45 | 4535.91 | +2.6% [−4.0, +9.6] |
| db-shootout | Post-GC heap (MiB) | 71.74 | 65.48 | −7.7% [−33.6, +28.3] |
| db-shootout | Post-GC RSS (MiB) | 1096.67 | 1099.18 | +0.2% [−0.6, +1.1] |
| Spring Petclinic | Throughput (requests/s) | 161.84 | 159.29 | −1.6% [−5.6, +2.5] |
| Spring Petclinic | p95 latency (ms) | 178.41 | 179.84 | +0.8% [−2.8, +4.5] |
| Spring Petclinic | Post-GC heap (MiB) | 40.19 | 35.70 | **−11.2% [−11.3, −11.0]** |
| Spring Petclinic | RSS after load (MiB) | 719.61 | 705.27 | −1.9% [−5.5, +1.8] |

**Spring retained heap is clearly lower. Database heap and both workloads' RSS remain inconclusive.** Timing intervals include zero: these runs establish no speedup and do not rule out smaller costs, including up to 9.6% longer database duration or 5.6% lower Spring throughput in these intervals. The initial 27.3% Spring regression no longer persists. Table values are arithmetic fork means; changes/intervals use exploratory log ratios without multiplicity adjustment.

**115,741 measured Spring responses validated; zero errors.** Maximum load-driver CPU: 0.07 cores. The pinned Boot 3.5.0 Petclinic jar uses Hibernate, Thymeleaf, Tomcat, embedded H2 and 10,000 owners. Renaissance 0.16.1 db-shootout uses its ordinary 500,000-entry MapDB/Chronicle Map/H2 MVStore workload. All 24 timing JVMs completed all 16 operations normally. Its upstream validator is a dummy; completion alone does not establish database result correctness.

Database memory initially used three independent JVMs per layout. The very wide heap interval prompted an exploratory expansion to twelve per layout, adding nine forks while keeping every original result. Both original and expanded summaries are retained; neither establishes a database heap reduction. Collection/cache effects contribute to this measurement. Memory runs remain separate from timings.

The continuous timing study ran **2026-10-07T02:52:19Z–03:46:31Z**. The earlier interrupted final-image attempt is entirely excluded and retained separately; no benchmark exception or JVM crash was recorded. Native images remained unchanged.

## Tradeoffs and evidence

Earlier native revision `eac09d4f179`, measured against stock eight-byte headers, reduced the exact unhashed one-int-object graph by 40.0% under Serial/G1 and 33.3% under ZGC. Hashing and moving every object erases nearly all that initial saving. Balanced confirmations measured first-hash costs of 16–19%, Serial identity-map lookup +6.7%, and ZGC stored-hash reads +6.3%. These costs are retained; this is not a universal speedup or a universal regression-free claim.

Four-byte mode caps compressed class space at 512 MiB with no fallback encoding. Recreate custom CDS/AOT caches. Instrumentation native sizing includes hidden hash slots.

[Historical layout report](https://github.com/re-thc/openjdk-jdk27u/blob/lilliput2-four-byte-headers/doc/benchmarks/four-byte-headers/results/validation.md) · [Reproduction instructions](https://github.com/re-thc/openjdk-jdk27u/blob/lilliput2-four-byte-headers/doc/benchmarks/four-byte-headers/README.md) · [Results directory](https://github.com/re-thc/openjdk-jdk27u/tree/lilliput2-four-byte-headers/doc/benchmarks/four-byte-headers/results)

Final report, benchmark raw data, exact image fingerprints, per-case local/CI statuses and updated evidence ZIP will be committed after the remaining CI test matrix completes. Before/after failures, profiles, resource retries and excluded timing attempts remain separately identified.
