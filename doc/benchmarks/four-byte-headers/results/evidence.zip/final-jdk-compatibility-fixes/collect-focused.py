"""Collect final focused jtreg statuses from each exact image's work directory."""
import csv
from collections import Counter
from pathlib import Path
import re

root = Path('/workspace/work/final-jdk')
assert (root / 'final-validation.finished').read_text().strip() == '0'
rows = []
for flavor, suite, work in [
    ('release', 'headers/hash/compressed-oops', 'jtreg-release/work'),
    ('fastdebug', 'headers/hash/compressed-oops', 'jtreg-fastdebug/work'),
    ('release', 'instrumentation', 'jtreg-size-release/work'),
    ('fastdebug', 'instrumentation', 'jtreg-size-fastdebug/work'),
    ('fastdebug', 'tier1-common', 'jtreg-common/work'),
]:
    counts = Counter()
    for report in sorted((root / work).rglob('*.jtr')):
        fields = {}
        for line in report.read_text(errors='replace').splitlines():
            if line.startswith(('test=', 'execStatus=', 'totalTime=')):
                key, value = line.split('=', 1)
                fields[key] = re.sub(r'\\(.)', r'\1', value)
        status = fields.get('execStatus', 'Missing')
        assert status.startswith('Passed.'), (report, status)
        counts['Skipped' if status.startswith('Passed. Skipped') else 'Passed'] += 1
        rows.append([flavor, suite, fields['test'], status,
                     fields.get('totalTime', ''), str(report.relative_to(root))])
    print(flavor, suite, dict(counts))
    expected = {'jtreg-release/work': 48, 'jtreg-fastdebug/work': 50,
                'jtreg-size-release/work': 4, 'jtreg-size-fastdebug/work': 4,
                'jtreg-common/work': 11}[work]
    assert sum(counts.values()) == expected, (work, counts, expected)
with (root / 'default-focused-results.csv').open('w', newline='') as out:
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(['flavor', 'suite', 'test', 'status', 'total_time', 'report'])
    writer.writerows(rows)
