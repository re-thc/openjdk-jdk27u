#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
ulimit -c unlimited
for flavor in release; do
  image=/workspace/work/final-jdk/release-image
  [[ $flavor != fastdebug ]] || image=/workspace/work/final-jdk/fastdebug-image
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/hotspot/jtreg/native -w:/workspace/work/final-jdk/jtreg-$flavor/work -r:/workspace/work/final-jdk/jtreg-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/hotspot/jtreg/runtime/CompactObjectHeaders test/hotspot/jtreg/gc/stress/ihash test/hotspot/jtreg/runtime/CompressedOops test/hotspot/jtreg/runtime/cds/FourByteHeaderArchiveDeterminism.java test/hotspot/jtreg/runtime/cds/DeterministicDump.java > /workspace/work/final-jdk/final-$flavor-focus.log 2>&1
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py /workspace/toolchains/jtreg83/bin/jtreg -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m -jdk:"$image" -nativepath:$PWD/build/cloud-gcc16/images/test/jdk/jtreg/native -w:/workspace/work/final-jdk/jtreg-size-$flavor/work -r:/workspace/work/final-jdk/jtreg-size-$flavor/report -automatic -conc:1 -timeoutFactor:4 -verbose:summary -javaoptions:'-Xmx512m' test/jdk/java/lang/instrument/FourByteHeaderObjectSize.java 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id0' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id1' 'test/jdk/java/lang/instrument/GetObjectSizeIntrinsicsTest.java#id2' > /workspace/work/final-jdk/final-$flavor-size.log 2>&1
done
printf '0\n' > /workspace/work/final-jdk/release-validation.finished
