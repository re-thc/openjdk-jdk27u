#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-jdk
[[ $(cat "$root/build-and-validate.finished") == 0 ]]
cd /workspace/openjdk-jdk27u
for flavor in release fastdebug; do
 JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
 /workspace/toolchains/jtreg83/bin/jtreg \
 -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
 -jdk:"$root/$flavor-image" -w:"$root/jdk-ci-after-$flavor/work" \
 -r:"$root/jdk-ci-after-$flavor/report" -automatic -conc:1 -status:fail,error,notRun \
 -timeoutFactor:4 -verbose:summary \
 test/jdk/jdk/jfr/event/oldobject/TestDFSWithSmallStack.java \
 test/jdk/java/lang/String/CompactString/MaxSizeUTF16String.java \
 test/jdk/tools/jlink/plugins/CDSPluginTest.java \
 > "$root/jdk-ci-after-$flavor.log" 2>&1
 JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
 /workspace/toolchains/jtreg83/bin/jtreg \
 -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
 -jdk:"$root/$flavor-image" -w:"$root/hotspot-ci-after-$flavor/work" \
 -r:"$root/hotspot-ci-after-$flavor/report" -automatic -conc:1 \
 -timeoutFactor:4 -verbose:summary \
 test/hotspot/jtreg/runtime/cds/appcds/dynamicArchive/TestAutoCreateSharedArchiveNoDefaultArchive.java \
 > "$root/hotspot-ci-after-$flavor.log" 2>&1
 JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
 /workspace/toolchains/jtreg83/bin/jtreg \
 -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
 -jdk:"$root/$flavor-image" -w:"$root/jfr-ci-after-$flavor/work" \
 -r:"$root/jfr-ci-after-$flavor/report" -automatic -conc:1 \
 -timeoutFactor:4 -verbose:summary \
 test/jdk/jdk/jfr/event/oldobject/TestG1.java \
 test/jdk/jdk/jfr/event/oldobject/TestSerial.java \
 test/jdk/jdk/jfr/event/oldobject/TestSanityDefault.java \
 test/jdk/jdk/jfr/event/oldobject/TestObjectSize.java \
 test/jdk/jdk/jfr/event/oldobject/TestArrayInformation.java \
 test/jdk/jdk/jfr/event/oldobject/TestFieldInformation.java \
 test/jdk/jdk/jfr/event/oldobject/TestCircularReference.java \
 test/jdk/jdk/jfr/event/oldobject/TestReferenceChainLimit.java \
 test/jdk/jdk/jfr/event/oldobject/TestHeapDeep.java \
 test/jdk/jdk/jfr/event/oldobject/TestHeapShallow.java \
 > "$root/jfr-ci-after-$flavor.log" 2>&1
done
# Verify the corrected size boundary also passes the unmodified stock-eight VM.
JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
 /workspace/toolchains/jtreg83/bin/jtreg \
 -J-XX:ActiveProcessorCount=1 -J-XX:+UseSerialGC -J-Xmx256m \
 -jdk:/workspace/work/baseline/image -w:"$root/jdk-ci-after-baseline8/work" \
 -r:"$root/jdk-ci-after-baseline8/report" -automatic -conc:1 \
 -timeoutFactor:4 -verbose:summary \
 test/jdk/java/lang/String/CompactString/MaxSizeUTF16String.java \
 > "$root/jdk-ci-after-baseline8.log" 2>&1
printf '0\n' > "$root/jdk-ci-followup.finished"
