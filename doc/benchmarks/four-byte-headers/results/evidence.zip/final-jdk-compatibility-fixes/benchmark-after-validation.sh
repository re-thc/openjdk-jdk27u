#!/usr/bin/env bash
set -euo pipefail
root=/workspace/work/final-jdk
while [[ ! -f $root/build-and-validate.finished ]]; do sleep 5; done
[[ $(cat "$root/build-and-validate.finished") == 0 ]]
while [[ ! -f $root/jdk-ci-followup.finished ]]; do sleep 5; done
[[ $(cat "$root/jdk-ci-followup.finished") == 0 ]]
while [[ ! -f $root/test-fix-committed.finished ]]; do sleep 5; done
[[ $(cat "$root/test-fix-committed.finished") == 0 ]]
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('/workspace/work/final-jdk')
for flavor in ['release','fastdebug']:
 p=root/(flavor+'-objects.tar.gz')
 assert p.is_file() and p.stat().st_size > 100_000_000
 for previous in ['final-copy', 'final-options']:
  Path('/workspace/work', previous, flavor+'-objects.tar.gz').unlink()
free=shutil.disk_usage('/workspace').free
if free < 9_000_000_000:
 # The superseded immutable images have finished all their runs. Preserve
 # their manifests and logs; keep only the validated latest runtime images.
 for flavor in ['release','fastdebug']:
  p=Path('/workspace/work/final-copy', flavor+'-image')
  if p.exists():shutil.rmtree(p)
 free=shutil.disk_usage('/workspace').free
if free < 9_000_000_000:
 # All these tests have completed. Keep reports and diagnostic sources, and
 # remove generated archives, cloned runtime binaries and test classes.
 retained={'.json','.csv','.log','.jtr','.sql','.java','.py','.txt','.collapsed'}
 removed=0
 for previous in ['final-copy','final-options','final-jdk','archive-primitive','archive-mirrors']:
  for scratch in Path('/workspace/work',previous).rglob('scratch'):
   if not scratch.is_dir():continue
   for p in scratch.rglob('*'):
    if p.is_file() and not p.is_symlink() and p.suffix not in retained:
     removed+=p.stat().st_size;p.unlink()
 print('Removed completed generated scratch bytes:',removed)
 free=shutil.disk_usage('/workspace').free
print('Free bytes before final benchmarks:', free)
assert free >= 9_000_000_000, 'Clean completed generated artifacts before starting timings'
PY
bash "$root/run-final-benchmarks.sh" > "$root/benchmark-driver.log" 2>&1
printf '0\n' > "$root/benchmark-driver.finished"
