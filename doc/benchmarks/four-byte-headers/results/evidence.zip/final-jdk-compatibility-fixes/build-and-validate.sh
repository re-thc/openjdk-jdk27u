#!/usr/bin/env bash
set -euo pipefail
cd /workspace/openjdk-jdk27u
root=/workspace/work/final-jdk
while [[ ! -f /workspace/work/final-copy/superseded-local.finished ]]; do sleep 5; done
[[ $(cat /workspace/work/final-copy/superseded-local.finished) == 0 ]]
source /workspace/toolchains/activate.sh
for flavor in fastdebug release; do
  if [[ -f $root/$flavor-build.finished ]]; then
    [[ $(cat "$root/$flavor-build.finished") == 0 ]]
    continue
  fi
  if [[ $flavor == fastdebug ]]; then conf=fourbyte-fastdebug; else conf=cloud-gcc16; fi
  objs=build/$conf/hotspot/variant-server/libjvm/objs
  if [[ ! -f $root/$flavor-cache-restored ]]; then
    mkdir -p "$objs"
    tar -xzf "/workspace/work/final-options/$flavor-objects.tar.gz" -C "$objs"
    printf '0\n' > "$root/$flavor-cache-restored"
  fi
  targets=(jdk-image)
  [[ $flavor != fastdebug ]] || targets+=(test-image-hotspot-gtest)
  JDK_JAVA_OPTIONS='-XX:ActiveProcessorCount=2' python3 /workspace/work/subreaper.py \
    make CONF="$conf" JOBS=4 "${targets[@]}" >> "$root/$flavor-build.log" 2>&1
  tar -I 'gzip -1' -cf "$root/$flavor-objects.tar.gz" -C "$objs" .
  python3 - "$conf" "$flavor" <<'PY'
from pathlib import Path
import json, hashlib, shutil, subprocess, sys
conf,flavor=sys.argv[1:]
root=Path('/workspace/work/final-jdk')
shutil.rmtree(Path('build')/conf/'hotspot/variant-server/libjvm/objs')
source=Path('build')/conf/'images/jdk';dest=root/(flavor+'-image')
assert not dest.exists()
shutil.copytree(source,dest,symlinks=True,ignore=shutil.ignore_patterns('*.debuginfo'))
lib=dest/'lib/server/libjvm.so';p=root/'manifest.json';data=json.loads(p.read_text())
data['source_revision']=data['validation_revision']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
data['images']['default4-'+flavor]={'path':str(dest),'libjvm_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'libjvm_bytes':lib.stat().st_size}
p.write_text(json.dumps(data,indent=2)+'\n')
shutil.rmtree(source)
for p in (Path('build')/conf/'support/modules_libs').rglob('*.debuginfo'):
 p.unlink()
PY
  printf '0\n' > "$root/$flavor-build.finished"
done
mkdir -p "$root/native-test-image/hotspot/gtest"
ln -s /workspace/openjdk-jdk27u/build/fourbyte-fastdebug/hotspot/variant-server/libjvm/gtest "$root/native-test-image/hotspot/gtest/server"
bash "$root/validate-release.sh" > "$root/release-validation-driver.log" 2>&1
bash "$root/validate-final.sh" > "$root/validation-driver.log" 2>&1
python3 "$root/collect-focused.py" > "$root/focused-counts.log"
bash "$root/validate-ci-followup.sh" > "$root/ci-followup-driver.log" 2>&1
bash "$root/run-final-jcstress.sh" > "$root/jcstress-driver.log" 2>&1
printf '0\n' > "$root/build-and-validate.finished"
bash "$root/validate-jdk-followup.sh" > "$root/jdk-ci-followup-driver.log" 2>&1
