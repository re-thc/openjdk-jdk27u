import datetime
import json
import statistics
import sys
import subprocess
import time
from pathlib import Path

root = Path(__file__).parent
spec = json.loads((root / (sys.argv[1] if len(sys.argv)>1 else 'images-final.json')).read_text())
out = root / (sys.argv[2] if len(sys.argv)>2 else 'first-use-final')
out.mkdir(exist_ok=False)
(out / 'images.json').write_text(json.dumps(spec, indent=2) + '\n')
orders = ['OBED', 'DEBO', 'BDOE', 'EODB']
cases = [('UTF-32', '16', 'BMP'), ('Shift_JIS', '32', 'LATIN1'),
         ('UTF-32LE', '65536', 'LATIN1')]
(out / 'plan.json').write_text(json.dumps(dict(orders=orders, cases=cases), indent=2) + '\n')
def host_state():
    return {name: Path(path).read_text() for name,path in [('cpu_stat','/proc/stat'),('cgroup_cpu_stat','/sys/fs/cgroup/cpu.stat')]}

rows = []
with (out / 'commands.jsonl').open('x') as records:
    for order_index, order in enumerate(orders):
        for case_index, case in enumerate(cases):
            for role in order:
                args = ['taskset', '-c', '2,3', spec['images'][role]['path'] + '/bin/java',
                        '-Xms512m', '-Xmx512m', '-XX:ActiveProcessorCount=2']
                if role == 'D':
                    args.append('-XX:-UseSIMDUTFIntrinsics')
                args += ['-cp', str(root / 'smoke-classes'), 'FirstUse', *case]
                row = dict(order_index=order_index, order=order, case=case_index,
                           role=role, args=args,
                           started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
                row["host_before"] = host_state()
                start = time.monotonic()
                result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
                row.update(exit_code=result.returncode, process_seconds=time.monotonic() - start,
                           stderr=result.stderr, stdout=result.stdout)
                row["host_after"] = host_state()
                records.write(json.dumps(row) + '\n')
                records.flush()
                result.check_returncode()
                row.update(json.loads(result.stdout.strip().splitlines()[-1]))
                rows.append(row)
summary = []
for index, case in enumerate(cases):
    report = dict(case=case, variants={}, ratios={})
    observations = [r for r in rows if r['case'] == index]
    for role in 'BOED':
        group = [r for r in observations if r['role'] == role]
        report['variants'][role] = {}
        for metric in ['first_call_nanos', 'allocated_bytes', 'process_seconds']:
            values = [r[metric] for r in group]
            report['variants'][role][metric] = dict(median=statistics.median(values), minimum=min(values), maximum=max(values), samples=len(values))
    for n, d in [('E', 'B'), ('E', 'O'), ('E', 'D'), ('D', 'B')]:
        values = []
        for row in observations:
            if row['role'] != n:
                continue
            other = next(r for r in observations if r['role'] == d and r['order_index'] == row['order_index'])
            values.append(row['first_call_nanos'] / other['first_call_nanos'])
        report['ratios'][n + '/' + d] = dict(median=statistics.median(values), minimum=min(values), maximum=max(values), samples=len(values))
    summary.append(report)
    print(json.dumps(report), flush=True)
(out / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
