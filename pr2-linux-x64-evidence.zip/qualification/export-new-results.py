import csv
import json
import sys
from pathlib import Path

root = Path(__file__).parent
absolute = []
summaries = []
pairs = []
for name in sys.argv[1:]:
    panel = root / name
    plan = json.loads((panel / 'plan.json').read_text())
    images = json.loads((panel / 'images.json').read_text())['images']
    images.setdefault('P', images['E'])
    def identity(role):
        base = images[role]['source']
        if role in plan.get('patch_sources', {}):
            base += ';patched-sources.sha256=' + plan['patch_sources'][role]['sha256']
        return base
    cases = {case['id']: case for case in plan['cases']}
    for line in (panel / 'commands.jsonl').read_text().splitlines():
        row = json.loads(line)
        case = cases[row['case']]
        image = images[row['variant']]
        absolute.append(dict(panel=name, case=row['case'], benchmark=case['benchmark'],
            parameters=json.dumps(case['params'], sort_keys=True), vm_extra=case.get('vm_extra', ''),
            affinity=plan['affinity'], order_index=row.get('order_index'), order=row['order'], position=row['position'], role=row['variant'],
            source=identity(row['variant']), tree=image['tree'], score=row.get('score'),
            unit=row.get('score_unit'), allocation_bytes_per_op=row.get('allocation_bytes_per_op'),
            exit_code=row.get('exit_code'), error=row.get('error', ''), timeout=row.get('timeout', False),
            process_seconds=row.get('elapsed_seconds')))
    raw = [json.loads(line) for line in (panel / 'commands.jsonl').read_text().splitlines()]
    for n in raw:
        if 'score' not in n: continue
        for nr, dr in [('E','B'),('E','O'),('E','D'),('D','B'),('P','E')]:
            if n['variant'] != nr: continue
            ds = [d for d in raw if d['variant'] == dr and d['case'] == n['case'] and d['position'] == n['position'] and d.get('order_index',d['order']) == n.get('order_index',n['order']) and 'score' in d]
            if not ds: continue
            d = ds[0]
            case = cases[n['case']]
            pairs.append(dict(panel=name,case=n['case'],benchmark=case['benchmark'],parameters=json.dumps(case['params'],sort_keys=True),vm_extra=case.get('vm_extra',''),affinity=plan['affinity'],order_index=n.get('order_index'),order=n['order'],position=n['position'],comparison=nr+'/'+dr,numerator_source=identity(nr),denominator_source=identity(dr),numerator_score=n['score'],denominator_score=d['score'],ratio=n['score']/d['score'],unit=n['score_unit']))
    for row in json.loads((panel / 'analysis.json').read_text()):
        case = row['case']
        for ratio, values in row['ratios'].items():
            n, d = ratio.split('/')
            summaries.append(dict(panel=name, case=case['id'], benchmark=case['benchmark'],
                parameters=json.dumps(case['params'], sort_keys=True), vm_extra=case.get('vm_extra', ''),
                comparison=ratio, numerator_source=identity(n), denominator_source=identity(d),
                paired_median=values['median'], minimum=values['minimum'], maximum=values['maximum'],
                pairs=values['samples'], numerator_allocation=row['variants'][n]['allocation'],
                denominator_allocation=row['variants'][d]['allocation']))
for filename, rows in [('absolute-forks.csv', absolute), ('paired-results.csv', summaries), ('paired-observations.csv', pairs)]:
    if not rows:
        continue
    with (root / filename).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(filename, len(rows), 'rows; no timing losses or failed commands filtered')
