import com.sun.management.ThreadMXBean;
import java.lang.management.ManagementFactory;
import java.nio.charset.Charset;

public class FirstUse {
    public static void main(String[] args) {
        String name = args[0];
        int size = Integer.parseInt(args[1]);
        boolean latin = args[2].equals("LATIN1");
        boolean fallback = name.equals("Shift_JIS");
        int cp = fallback ? 'a' : latin ? 0xe9 : 0x6f22;
        Charset charset = Charset.forName(name);
        int width = fallback ? 1 : name.startsWith("UTF-32") ? 4 : 2;
        boolean big = !name.endsWith("LE");
        byte[] bytes = new byte[size * width];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < width; j++) {
                bytes[i * width + (big ? width - 1 - j : j)] = (byte)(cp >>> (8 * j));
            }
        }
        ThreadMXBean bean = (ThreadMXBean)ManagementFactory.getThreadMXBean();
        if (!bean.isThreadAllocatedMemorySupported()) throw new AssertionError("allocation counter unavailable");
        if (!bean.isThreadAllocatedMemoryEnabled()) bean.setThreadAllocatedMemoryEnabled(true);
        long id = Thread.currentThread().threadId();
        for (int i = 0; i < 10; i++) {
            bean.getThreadAllocatedBytes(id);
            System.nanoTime();
        }
        long before = bean.getThreadAllocatedBytes(id);
        long start = System.nanoTime();
        String result = new String(bytes, charset);
        long nanos = System.nanoTime() - start;
        long allocated = bean.getThreadAllocatedBytes(id) - before;
        if (result.length() != size) throw new AssertionError("length");
        for (int i = 0; i < size; i++) {
            if (result.charAt(i) != cp) throw new AssertionError("content");
        }
        System.out.println("{\"charset\":\"" + name + "\",\"size\":" + size
                + ",\"first_call_nanos\":" + nanos + ",\"allocated_bytes\":" + allocated + "}");
    }
}
