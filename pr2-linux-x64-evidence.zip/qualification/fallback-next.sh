#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
for variant in control candidate; do
  images/E3/bin/javac --patch-module "java.base=patches/fallback-$variant-src" -d "patches/fallback-$variant-classes" "patches/fallback-$variant-src/java/lang/Character.java" "patches/fallback-$variant-src/java/lang/StringUTF16.java" > "patches/fallback-$variant-compile.log" 2>&1
  images/E3/bin/java --patch-module "java.base=patches/fallback-$variant-classes" -XX:-UseSIMDUTFIntrinsics -Xmx512m -XX:ActiveProcessorCount=2 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' PanelSmoke count-final-cases.tsv > "patches/fallback-$variant-smoke.log" 2>&1
done
python3 run.py fallback-diagnostic-plan.json fallback-diagnostic > fallback-diagnostic-progress.log 2>&1
python3 analyse.py fallback-diagnostic > fallback-diagnostic-analysis.log
