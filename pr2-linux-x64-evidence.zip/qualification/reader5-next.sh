#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
images/E/bin/javac --patch-module java.base=patches/candidate5-src -d patches/candidate5-classes patches/candidate5-src/java/lang/StringCodingWide.java > patches/candidate5-compile.log 2>&1
images/E/bin/java --patch-module java.base=patches/candidate5-classes -Xms512m -Xmx512m -XX:ActiveProcessorCount=2 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' PanelSmoke qualified-final-cases.tsv > patches/candidate5-smoke.log 2>&1
images/E/bin/java --patch-module java.base=patches/candidate5-classes -Xbatch -XX:-TieredCompilation -XX:CompileThreshold=100 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' HotWideWitness > patches/candidate5-hot.log 2>&1
python3 run.py reader5-diagnostic-plan.json reader5-diagnostic > reader5-diagnostic-progress.log 2>&1
python3 analyse.py reader5-diagnostic > reader5-analysis.log
