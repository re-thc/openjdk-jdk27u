import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PanelSmoke {
    static Object field(Object state, String name) throws Exception {
        for (Class<?> c = state.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(state);
            } catch (NoSuchFieldException e) { }
        }
        throw new NoSuchFieldException(name);
    }

    public static void main(String[] args) throws Exception {
        int checked = 0;
        for (String line : Files.readAllLines(Path.of(args[0]))) {
            String[] columns = line.split("\t");
            String benchmark = columns[0];
            int dot = benchmark.lastIndexOf('.');
            Class<?> type = Class.forName(benchmark.substring(0, dot));
            String name = benchmark.substring(dot + 1);
            if (type.getSimpleName().equals("ArrayCopy") || type.getSimpleName().equals("Integers")) continue;
            Method method = Arrays.stream(type.getMethods()).filter(m -> m.getName().equals(name)).findFirst().orElseThrow();
            boolean wide = type.getSimpleName().equals("SimdUTFWide");
            Object state = (wide ? method.getParameterTypes()[0] : type).getConstructor().newInstance();
            for (int i = 1; i < columns.length; i++) {
                String[] parameter = columns[i].split("=", 2);
                Field f = state.getClass().getField(parameter[0]);
                f.set(state, f.getType() == int.class ? Integer.valueOf(parameter[1]) : parameter[1]);
            }
            try {
                state.getClass().getMethod("setup").invoke(state);
                Object result = wide ? method.invoke(nullSafeReceiver(type), state) : method.invoke(state);
                if (wide) {
                    String text = (String)field(state, "text");
                    byte[] bytes = (byte[])field(state, "bytes");
                    if (result instanceof String s && !s.equals(text)) throw new AssertionError(benchmark);
                    if (result instanceof byte[] b && !Arrays.equals(b, bytes)) throw new AssertionError(benchmark);
                    if (name.equals("decodeBuffer") && !result.equals(text.length())) throw new AssertionError(benchmark);
                    if (name.equals("encodeBuffer") && !result.equals(bytes.length)) throw new AssertionError(benchmark);
                    if (name.equals("setSegmentString")) {
                        var segment = (java.lang.foreign.MemorySegment)result;
                        if (!Arrays.equals(bytes, segment.asSlice(0, bytes.length).toArray(java.lang.foreign.ValueLayout.JAVA_BYTE))) {
                            throw new AssertionError(benchmark);
                        }
                    }
                } else {
                    int size = (int)field(state, "size");
                    Object expected = switch (name) {
                        case "codePointCount", "charArrayCodePointCount" -> size / 2;
                        case "prefixedPairCodePointCount", "prefixedPairCharArrayCodePointCount" -> size - (size - 1) / 2;
                        case "sparsePairCodePointCount", "sparsePairCharArrayCodePointCount" -> size - Math.min(8, size / 2);
                        case "latin1Decode" -> "é".repeat(size);
                        case "charsetDecodeTight" -> size / 3 + size % 3;
                        case "base64Encode" -> ((size + 2) / 3) * 4;
                        case "latin1IndexOfFirst" -> 0;
                        case "utf16IndexOfNear" -> Math.min(15, size - 1);
                        default -> size;
                    };
                    if (!expected.equals(result)) throw new AssertionError(benchmark + ": " + result + " != " + expected);
                }
                checked++;
            } finally {
                if ((state.getClass().getSimpleName().equals("Buffers") || state.getClass().getSimpleName().equals("Segments"))
                        && field(state, "arena") != null) {
                    state.getClass().getMethod("close").invoke(state);
                }
            }
        }
        System.out.println("PASS " + checked + " fixed-panel output checks; " + System.getProperty("java.home"));
    }

    static Object nullSafeReceiver(Class<?> type) throws Exception {
        return type.getConstructor().newInstance();
    }
}
