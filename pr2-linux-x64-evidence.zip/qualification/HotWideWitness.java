import java.nio.charset.Charset;
import org.openjdk.bench.java.lang.SimdUTFWide;
public class HotWideWitness {
    static volatile String sink;
    public static void main(String[] args) throws Exception {
        var state = new SimdUTFWide.Strings();
        state.charsetName = args.length == 0 ? "UTF-32" : args[0];
        state.content = "BMP";
        state.size = 16;
        state.setup();
        var benchmark = new SimdUTFWide();
        String expected = "漢".repeat(16);
        for (int i = 0; i < 300000; i++) {
            String result = benchmark.constructString(state);
            if (!result.equals(expected) || result.charAt(0) != '漢') {
                throw new AssertionError("Hot default UTF32 at iteration " + i);
            }
            sink = result;
        }
        System.out.println("PASS hot default " + state.charsetName);
    }
}
