#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
for role in O E D; do
  image_role=$role
  flags=()
  if [[ $role == D ]]; then
    image_role=E
    flags=(-XX:-UseSIMDUTFIntrinsics)
  fi
  for panel in qualified-final count-final extension; do
    "images/$image_role/bin/java" -Xms512m -Xmx512m -XX:ActiveProcessorCount=2 \
      "${flags[@]}" -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' \
      PanelSmoke "$panel-cases.tsv" > "smoke-$role-$panel.log" 2>&1
  done
done
