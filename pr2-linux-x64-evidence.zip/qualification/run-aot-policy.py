import json, subprocess, datetime
from pathlib import Path
root=Path(__file__).parent
out=root/'aot-policy'
out.mkdir(exist_ok=False)
base=[str(root/'images/E/bin/java'),'-Xms128m','-Xmx256m','-XX:ActiveProcessorCount=2','-Xbatch',
      '--add-exports=java.base/jdk.internal.util=ALL-UNNAMED','-Xlog:aot+codecache+init=debug,aot+codecache+exit=debug',
      '-cp',str(root/'aot-policy-probe.jar')]
with (out/'commands.jsonl').open('x') as records:
    for training in ['enabled','disabled']:
        flag=[] if training=='enabled' else ['-XX:-UseSIMDUTFIntrinsics']
        conf=str(out/(training+'.aotconf'))
        cache=str(out/(training+'.aot'))
        stages=[('record',flag+['-XX:AOTMode=record','-XX:AOTConfiguration='+conf]),
                ('create',flag+['-XX:AOTMode=create','-XX:AOTConfiguration='+conf,'-XX:AOTCache='+cache])]
        for mode in ['on','auto']:
            for production in ['enabled','disabled']:
                args=[] if production=='enabled' else ['-XX:-UseSIMDUTFIntrinsics']
                stages.append((mode+'-'+production,args+['-XX:AOTMode='+mode,'-XX:AOTCache='+cache]))
        for name,extra in stages:
            args=base+extra+['AOTPolicyProbe']
            with (out/(training+'-'+name+'.log')).open('x') as log:
                result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=120)
            row=dict(training=training,stage=name,args=args,exit_code=result.returncode,
                     source='7c20b8177effdacde2be69f8a35aece998271d4d',utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            records.write(json.dumps(row)+'\n');records.flush()
            print(training,name,result.returncode,flush=True)
            if name in ['record','create'] and result.returncode: raise SystemExit('AOT probe setup failed; logs retained')
