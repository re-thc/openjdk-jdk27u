import datetime
import json
import math
import os
import resource
import subprocess
import sys
import time
from pathlib import Path

OUT=Path(__file__).parent
plan=json.loads((OUT/sys.argv[1]).read_text())
manifest_path=OUT/plan.get('image_manifest','images.json')
directory=OUT/sys.argv[2]
directory.mkdir(exist_ok=False)
(directory/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(directory/'images.json').write_text(manifest_path.read_text())
images={role:Path(spec['path']) for role,spec in json.loads(manifest_path.read_text())['images'].items()}
images.setdefault('P',images['E'])
controls=[c for c in plan['cases'] if '.ArrayCopy.' in c['benchmark'] or '.Integers.' in c['benchmark']]
workloads=[c for c in plan['cases'] if c not in controls]
sequence=controls+workloads+controls if plan.get('bookend_controls',True) else plan['cases']
cp=str(OUT/plan['benchmark_jar'])+':/workspace/work/pr2/build/jmh/jars/*'
def host_state():
    state=dict(load_average=os.getloadavg())
    for name,path in [('cpu_stat','/proc/stat'),('cgroup_cpu_stat','/sys/fs/cgroup/cpu.stat'),('cpu_max','/sys/fs/cgroup/cpu.max')]:
        p=Path(path)
        if p.exists(): state[name]=p.read_text()
    return state
with (directory/'commands.jsonl').open('x') as commands:
    for order_index,order in enumerate(plan['orders']):
        for position,case in enumerate(sequence):
            for variant in order:
                stem=f"order{order_index}-{order}-position{position:03d}-case{case['id']:03d}-{variant}"
                args=['taskset','-c',plan['affinity'],'/workspace/toolchains/jdk27/bin/java','-Xmx256m',
                      '-XX:ActiveProcessorCount=2','-cp',cp,'org.openjdk.jmh.Main','^'+case['benchmark']+'$',
                      '-jvm',str(images[variant]/'bin/java'),'-jvmArgs',plan['vm_args']+' '+case.get('vm_extra','')]
                appended=[]
                if variant=='D': appended+=['-XX:-UseSIMDUTFIntrinsics']
                if variant in plan.get('patch_modules',{}): appended+=['--patch-module=java.base='+plan['patch_modules'][variant]]
                elif variant=='P' and 'patch_module' in plan: appended+=['--patch-module=java.base='+plan['patch_module']]
                if plan.get('diagnostic_compilation'):
                    appended+=['-XX:+UnlockDiagnosticVMOptions','-XX:+LogCompilation','-XX:LogFile='+str(directory/(stem+'-compilation.xml'))]
                if appended: args+=['-jvmArgsAppend',' '.join(appended)]
                for name,value in case['params'].items(): args+=['-p',name+'='+value]
                args+=plan['jmh']+['-rff',str(directory/(stem+'.json'))]
                record=dict(case=case['id'],order=order,order_index=order_index,position=position,variant=variant,args=args,
                            started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
                record['host_before']=host_state()
                usage_before=resource.getrusage(resource.RUSAGE_CHILDREN)
                start=time.monotonic()
                try:
                    with (directory/(stem+'.log')).open('x') as log:
                        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=90)
                    record.update(exit_code=result.returncode,elapsed_seconds=round(time.monotonic()-start,3))
                    rows=json.loads((directory/(stem+'.json')).read_text()) if result.returncode==0 else []
                    if len(rows)!=1 or rows[0]['benchmark']!=case['benchmark'] or rows[0].get('params',{})!=case['params']:
                        record['error']='Missing or unexpected benchmark/parameters'
                    elif not math.isfinite(rows[0]['primaryMetric']['score']): record['error']='Non-finite timing'
                    else:
                        record['score']=rows[0]['primaryMetric']['score']
                        record['score_unit']=rows[0]['primaryMetric']['scoreUnit']
                        record['allocation_bytes_per_op']=rows[0].get('secondaryMetrics',{}).get('gc.alloc.rate.norm',{}).get('score')
                except subprocess.TimeoutExpired: record['timeout']=True
                usage_after=resource.getrusage(resource.RUSAGE_CHILDREN)
                record['child_cpu_seconds']=usage_after.ru_utime+usage_after.ru_stime-usage_before.ru_utime-usage_before.ru_stime
                record['host_after']=host_state()
                commands.write(json.dumps(record)+'\n'); commands.flush()
                if record.get('exit_code')!=0 or record.get('error'): raise SystemExit('Failed invocation preserved: '+stem)
            print(f"{directory.name} {order} case {case['id']} complete",flush=True)
print('Complete; all invocations retained',flush=True)
