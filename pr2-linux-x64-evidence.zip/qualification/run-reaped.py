import ctypes
import os
import subprocess
import sys
import time

libc=ctypes.CDLL(None,use_errno=True)
if libc.prctl(36,1,0,0,0)!=0:
    raise OSError(ctypes.get_errno(),'Cannot set process-local child subreaper')
child=subprocess.Popen(sys.argv[1:])
status=None
reaped=0
deadline=None
while True:
    any_children=True
    while True:
        try:
            pid,value=os.waitpid(-1,os.WNOHANG)
        except ChildProcessError:
            any_children=False
            break
        if pid==0:break
        if pid==child.pid:
            status=os.waitstatus_to_exitcode(value)
            child.returncode=status
            deadline=time.monotonic()+30
        else:reaped+=1
    if status is not None and not any_children:break
    if deadline is not None and time.monotonic()>deadline:
        print('[local reaper] Main command ended; live descendants remain',flush=True)
        break
    time.sleep(0.05)
print('[local reaper] Reaped',reaped,'orphaned descendants; exit',status,flush=True)
raise SystemExit(status if status is not None else 1)
