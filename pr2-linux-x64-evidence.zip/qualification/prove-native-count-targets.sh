#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
for target in generic v3; do
  arch=x86-64
  if [[ $target == v3 ]]; then arch=x86-64-v3; fi
  /usr/bin/g++ -std=c++17 -O3 -Wall -Wextra -Werror "-march=$arch" -mtune=generic -fno-strict-aliasing "-fopt-info-vec-optimized=drafts/count-target-$target-vector.log" drafts/count-target-proof.cpp -o "drafts/count-target-$target"
  "drafts/count-target-$target" > "drafts/count-target-$target-test.log" 2>&1
  objdump -d --disassemble=count_avx2 "drafts/count-target-$target" > "drafts/count-target-$target-avx2.asm"
  rg -q 'ymm' "drafts/count-target-$target-avx2.asm"
  cat "drafts/count-target-$target-test.log" "drafts/count-target-$target-vector.log"
done
