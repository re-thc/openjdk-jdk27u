import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.util.HexFormat;
import org.openjdk.bench.java.lang.SimdUTF;

public class Corpus {
    public static void main(String[] args) throws Exception {
        SimdUTF state = new SimdUTF();
        state.size = 1048576;
        state.setup();
        System.out.println("field,utf16Units,sha256_utf16be");
        for (String name : new String[]{"supplementaryChars", "prefixedPairChars", "sparsePairChars", "chars", "malformedCountChars"}) {
            Field field = SimdUTF.class.getDeclaredField(name);
            field.setAccessible(true);
            char[] chars = (char[])field.get(state);
            MessageDigest hash = MessageDigest.getInstance("SHA-256");
            for (char c : chars) {
                hash.update((byte)(c >>> 8));
                hash.update((byte)c);
            }
            System.out.println(name + "," + chars.length + "," + HexFormat.of().formatHex(hash.digest()));
        }
    }
}
