import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path(__file__).parent
out=sys.argv[1]
mapping=dict(x.split('=',1) for x in sys.argv[2:])
images={}
for role,build in mapping.items():
    source,tree=(root/(build+'-source.txt')).read_text().splitlines()
    image=root/'images'/build
    release=(image/'release').read_text()
    assert source[:12] in release,(role,'release source mismatch')
    lines=(root/(build+'-spec.gmk')).read_text().splitlines()
    configure=next(x for x in lines if x.startswith('CONFIGURE_COMMAND_LINE :='))
    compiler=[x for x in lines if x.startswith(('CC_VERSION_NUMBER :=','CXX_VERSION_NUMBER :='))]
    hashes={};sizes={}
    for name in ['bin/java','lib/libjava.so','lib/server/libjvm.so','lib/modules']:
        p=image/name; hashes[name]=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();sizes[name]=p.stat().st_size
    images[role]=dict(path=str(image),source=source,tree=tree,release=release,configure=configure,compiler=compiler,files=hashes,sizes=sizes,
        build_start=(root/(build+'-build-start.txt')).read_text().strip(),build_end=(root/(build+'-build-end.txt')).read_text().strip(),effective_make='make CONF=pr2-release JOBS=4 images')
assert len({x['configure'] for x in images.values()})==1,'configuration mismatch'
assert len({tuple(x['compiler']) for x in images.values()})==1,'compiler mismatch'
if 'P' not in images: images['D']=dict(images['E'],additional_vm_args='-XX:-UseSIMDUTFIntrinsics')
spec=dict(images=images,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host='Native Linux x64 KVM; Xeon Platinum 8370C; AVX512;4CPU quota;16GiB',
    compiler=subprocess.check_output(['/usr/bin/g++','--version'],text=True),build_supervision='Inspected process-local reaper; benchmark JVMs without it')
(root/out).write_text(json.dumps(spec,indent=2)+'\n')
print({r:(x['source'],x['path']) for r,x in images.items()})
