
drafts/count-target-v3:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000002cf0 <count_avx2>:
    2cf0:	89 f0                	mov    %esi,%eax
    2cf2:	83 fe 01             	cmp    $0x1,%esi
    2cf5:	0f 8e 15 03 00 00    	jle    3010 <count_avx2+0x320>
    2cfb:	8d 56 fe             	lea    -0x2(%rsi),%edx
    2cfe:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
    2d02:	83 fa 0e             	cmp    $0xe,%edx
    2d05:	0f 86 06 03 00 00    	jbe    3011 <count_avx2+0x321>
    2d0b:	b9 00 fc 00 fc       	mov    $0xfc00fc00,%ecx
    2d10:	44 89 c6             	mov    %r8d,%esi
    2d13:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    2d17:	48 89 fa             	mov    %rdi,%rdx
    2d1a:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
    2d1e:	b9 00 d8 00 d8       	mov    $0xd800d800,%ecx
    2d23:	c1 ee 04             	shr    $0x4,%esi
    2d26:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    2d2a:	b9 00 dc 00 dc       	mov    $0xdc00dc00,%ecx
    2d2f:	48 c1 e6 05          	shl    $0x5,%rsi
    2d33:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2d38:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    2d3c:	b9 01 00 01 00       	mov    $0x10001,%ecx
    2d41:	48 01 fe             	add    %rdi,%rsi
    2d44:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    2d48:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    2d4d:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    2d52:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2d57:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d5e:	00 00 00 00 
    2d62:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d69:	00 00 00 00 
    2d6d:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d74:	00 00 00 00 
    2d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2d7f:	00 
    2d80:	c5 e5 db 02          	vpand  (%rdx),%ymm3,%ymm0
    2d84:	c5 e5 db 52 02       	vpand  0x2(%rdx),%ymm3,%ymm2
    2d89:	48 83 c2 20          	add    $0x20,%rdx
    2d8d:	c5 ed 75 d5          	vpcmpeqw %ymm5,%ymm2,%ymm2
    2d91:	c5 fd 75 c6          	vpcmpeqw %ymm6,%ymm0,%ymm0
    2d95:	c5 fd db c2          	vpand  %ymm2,%ymm0,%ymm0
    2d99:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
    2d9d:	c4 e2 7d 33 d0       	vpmovzxwd %xmm0,%ymm2
    2da2:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2da8:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    2dac:	c4 e2 7d 33 c0       	vpmovzxwd %xmm0,%ymm0
    2db1:	c5 fd fe c9          	vpaddd %ymm1,%ymm0,%ymm1
    2db5:	48 39 d6             	cmp    %rdx,%rsi
    2db8:	75 c6                	jne    2d80 <count_avx2+0x90>
    2dba:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
    2dc0:	44 89 c6             	mov    %r8d,%esi
    2dc3:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2dc7:	83 e6 f0             	and    $0xfffffff0,%esi
    2dca:	41 83 e0 0f          	and    $0xf,%r8d
    2dce:	c5 f1 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm1
    2dd3:	8d 4e 01             	lea    0x1(%rsi),%ecx
    2dd6:	c5 f9 fe c9          	vpaddd %xmm1,%xmm0,%xmm1
    2dda:	c5 e9 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm2
    2ddf:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
    2de3:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2de7:	c5 f9 7e ca          	vmovd  %xmm1,%edx
    2deb:	0f 84 32 02 00 00    	je     3023 <count_avx2+0x333>
    2df1:	c5 f8 77             	vzeroupper
    2df4:	41 89 c0             	mov    %eax,%r8d
    2df7:	41 29 f0             	sub    %esi,%r8d
    2dfa:	45 8d 48 ff          	lea    -0x1(%r8),%r9d
    2dfe:	41 83 e8 02          	sub    $0x2,%r8d
    2e02:	41 83 f8 06          	cmp    $0x6,%r8d
    2e06:	0f 86 92 00 00 00    	jbe    2e9e <count_avx2+0x1ae>
    2e0c:	ba 00 fc 00 fc       	mov    $0xfc00fc00,%edx
    2e11:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2e15:	ba 00 dc 00 dc       	mov    $0xdc00dc00,%edx
    2e1a:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    2e1f:	c5 f9 6e da          	vmovd  %edx,%xmm3
    2e23:	c5 f1 db 44 77 02    	vpand  0x2(%rdi,%rsi,2),%xmm1,%xmm0
    2e29:	c4 e2 79 58 db       	vpbroadcastd %xmm3,%xmm3
    2e2e:	c5 f1 db 0c 77       	vpand  (%rdi,%rsi,2),%xmm1,%xmm1
    2e33:	be 00 d8 00 d8       	mov    $0xd800d800,%esi
    2e38:	c5 f9 75 c3          	vpcmpeqw %xmm3,%xmm0,%xmm0
    2e3c:	c5 f9 6e de          	vmovd  %esi,%xmm3
    2e40:	be 01 00 01 00       	mov    $0x10001,%esi
    2e45:	c4 e2 79 58 db       	vpbroadcastd %xmm3,%xmm3
    2e4a:	c5 f1 75 cb          	vpcmpeqw %xmm3,%xmm1,%xmm1
    2e4e:	c5 f9 db c1          	vpand  %xmm1,%xmm0,%xmm0
    2e52:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    2e56:	44 89 ce             	mov    %r9d,%esi
    2e59:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    2e5e:	83 e6 f8             	and    $0xfffffff8,%esi
    2e61:	c5 f9 db c1          	vpand  %xmm1,%xmm0,%xmm0
    2e65:	01 f1                	add    %esi,%ecx
    2e67:	41 83 e1 07          	and    $0x7,%r9d
    2e6b:	c4 e2 79 33 c8       	vpmovzxwd %xmm0,%xmm1
    2e70:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    2e75:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
    2e79:	c4 e2 79 33 c0       	vpmovzxwd %xmm0,%xmm0
    2e7e:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2e82:	c5 f1 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm1
    2e87:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2e8b:	c5 f1 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm1
    2e90:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2e94:	c5 f9 7e c2          	vmovd  %xmm0,%edx
    2e98:	0f 84 70 01 00 00    	je     300e <count_avx2+0x31e>
    2e9e:	48 63 f1             	movslq %ecx,%rsi
    2ea1:	48 01 f6             	add    %rsi,%rsi
    2ea4:	4c 8d 0c 37          	lea    (%rdi,%rsi,1),%r9
    2ea8:	45 0f b7 01          	movzwl (%r9),%r8d
    2eac:	45 0f b7 49 fe       	movzwl -0x2(%r9),%r9d
    2eb1:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2eb7:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2ebd:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2ec3:	41 0f 94 c2          	sete   %r10b
    2ec7:	45 31 c9             	xor    %r9d,%r9d
    2eca:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2ed0:	41 0f 94 c1          	sete   %r9b
    2ed4:	45 21 d1             	and    %r10d,%r9d
    2ed7:	44 01 ca             	add    %r9d,%edx
    2eda:	44 8d 49 01          	lea    0x1(%rcx),%r9d
    2ede:	44 39 c8             	cmp    %r9d,%eax
    2ee1:	0f 8e 27 01 00 00    	jle    300e <count_avx2+0x31e>
    2ee7:	44 0f b7 4c 37 02    	movzwl 0x2(%rdi,%rsi,1),%r9d
    2eed:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2ef3:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2ef9:	41 0f 94 c2          	sete   %r10b
    2efd:	45 31 c0             	xor    %r8d,%r8d
    2f00:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2f06:	41 0f 94 c0          	sete   %r8b
    2f0a:	45 21 d0             	and    %r10d,%r8d
    2f0d:	44 01 c2             	add    %r8d,%edx
    2f10:	44 8d 41 02          	lea    0x2(%rcx),%r8d
    2f14:	44 39 c0             	cmp    %r8d,%eax
    2f17:	0f 8e f1 00 00 00    	jle    300e <count_avx2+0x31e>
    2f1d:	44 0f b7 44 37 04    	movzwl 0x4(%rdi,%rsi,1),%r8d
    2f23:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2f29:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2f2f:	41 0f 94 c2          	sete   %r10b
    2f33:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2f39:	41 0f 94 c1          	sete   %r9b
    2f3d:	45 0f b6 c9          	movzbl %r9b,%r9d
    2f41:	45 21 d1             	and    %r10d,%r9d
    2f44:	44 01 ca             	add    %r9d,%edx
    2f47:	44 8d 49 03          	lea    0x3(%rcx),%r9d
    2f4b:	44 39 c8             	cmp    %r9d,%eax
    2f4e:	0f 8e ba 00 00 00    	jle    300e <count_avx2+0x31e>
    2f54:	44 0f b7 4c 37 06    	movzwl 0x6(%rdi,%rsi,1),%r9d
    2f5a:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2f60:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2f66:	41 0f 94 c2          	sete   %r10b
    2f6a:	45 31 c0             	xor    %r8d,%r8d
    2f6d:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2f73:	41 0f 94 c0          	sete   %r8b
    2f77:	45 21 d0             	and    %r10d,%r8d
    2f7a:	44 01 c2             	add    %r8d,%edx
    2f7d:	44 8d 41 04          	lea    0x4(%rcx),%r8d
    2f81:	44 39 c0             	cmp    %r8d,%eax
    2f84:	0f 8e 84 00 00 00    	jle    300e <count_avx2+0x31e>
    2f8a:	44 0f b7 44 37 08    	movzwl 0x8(%rdi,%rsi,1),%r8d
    2f90:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2f96:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2f9c:	41 0f 94 c2          	sete   %r10b
    2fa0:	45 31 c9             	xor    %r9d,%r9d
    2fa3:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2fa9:	41 0f 94 c1          	sete   %r9b
    2fad:	45 21 d1             	and    %r10d,%r9d
    2fb0:	44 01 ca             	add    %r9d,%edx
    2fb3:	44 8d 49 05          	lea    0x5(%rcx),%r9d
    2fb7:	44 39 c8             	cmp    %r9d,%eax
    2fba:	7e 52                	jle    300e <count_avx2+0x31e>
    2fbc:	44 0f b7 4c 37 0a    	movzwl 0xa(%rdi,%rsi,1),%r9d
    2fc2:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2fc8:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2fce:	41 0f 94 c2          	sete   %r10b
    2fd2:	45 31 c0             	xor    %r8d,%r8d
    2fd5:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2fdb:	41 0f 94 c0          	sete   %r8b
    2fdf:	83 c1 06             	add    $0x6,%ecx
    2fe2:	45 21 d0             	and    %r10d,%r8d
    2fe5:	44 01 c2             	add    %r8d,%edx
    2fe8:	39 c8                	cmp    %ecx,%eax
    2fea:	7e 22                	jle    300e <count_avx2+0x31e>
    2fec:	0f b7 4c 37 0c       	movzwl 0xc(%rdi,%rsi,1),%ecx
    2ff1:	66 81 e1 00 fc       	and    $0xfc00,%cx
    2ff6:	66 81 f9 00 dc       	cmp    $0xdc00,%cx
    2ffb:	40 0f 94 c6          	sete   %sil
    2fff:	31 c9                	xor    %ecx,%ecx
    3001:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    3007:	0f 94 c1             	sete   %cl
    300a:	21 f1                	and    %esi,%ecx
    300c:	01 ca                	add    %ecx,%edx
    300e:	29 d0                	sub    %edx,%eax
    3010:	c3                   	ret
    3011:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
    3015:	31 f6                	xor    %esi,%esi
    3017:	31 d2                	xor    %edx,%edx
    3019:	b9 01 00 00 00       	mov    $0x1,%ecx
    301e:	e9 d1 fd ff ff       	jmp    2df4 <count_avx2+0x104>
    3023:	c5 f8 77             	vzeroupper
    3026:	29 d0                	sub    %edx,%eax
    3028:	c3                   	ret

Disassembly of section .fini:
