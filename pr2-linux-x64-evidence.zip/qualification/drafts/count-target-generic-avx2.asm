
drafts/count-target-generic:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000002b80 <count_avx2>:
    2b80:	89 f0                	mov    %esi,%eax
    2b82:	83 fe 01             	cmp    $0x1,%esi
    2b85:	0f 8e 05 03 00 00    	jle    2e90 <count_avx2+0x310>
    2b8b:	8d 56 fe             	lea    -0x2(%rsi),%edx
    2b8e:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
    2b92:	83 fa 0e             	cmp    $0xe,%edx
    2b95:	0f 86 f6 02 00 00    	jbe    2e91 <count_avx2+0x311>
    2b9b:	b9 00 fc 00 fc       	mov    $0xfc00fc00,%ecx
    2ba0:	44 89 c6             	mov    %r8d,%esi
    2ba3:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    2ba7:	48 89 fa             	mov    %rdi,%rdx
    2baa:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
    2bae:	b9 00 d8 00 d8       	mov    $0xd800d800,%ecx
    2bb3:	c1 ee 04             	shr    $0x4,%esi
    2bb6:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    2bba:	b9 00 dc 00 dc       	mov    $0xdc00dc00,%ecx
    2bbf:	48 c1 e6 05          	shl    $0x5,%rsi
    2bc3:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2bc8:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    2bcc:	b9 01 00 01 00       	mov    $0x10001,%ecx
    2bd1:	48 01 fe             	add    %rdi,%rsi
    2bd4:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    2bd8:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    2bdd:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    2be2:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2be7:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bee:	00 00 00 00 
    2bf2:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bf9:	00 00 00 00 
    2bfd:	0f 1f 00             	nopl   (%rax)
    2c00:	c5 e5 db 02          	vpand  (%rdx),%ymm3,%ymm0
    2c04:	c5 e5 db 52 02       	vpand  0x2(%rdx),%ymm3,%ymm2
    2c09:	48 83 c2 20          	add    $0x20,%rdx
    2c0d:	c5 ed 75 d5          	vpcmpeqw %ymm5,%ymm2,%ymm2
    2c11:	c5 fd 75 c6          	vpcmpeqw %ymm6,%ymm0,%ymm0
    2c15:	c5 fd db c2          	vpand  %ymm2,%ymm0,%ymm0
    2c19:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
    2c1d:	c4 e2 7d 33 d0       	vpmovzxwd %xmm0,%ymm2
    2c22:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2c28:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    2c2c:	c4 e2 7d 33 c0       	vpmovzxwd %xmm0,%ymm0
    2c31:	c5 fd fe c9          	vpaddd %ymm1,%ymm0,%ymm1
    2c35:	48 39 d6             	cmp    %rdx,%rsi
    2c38:	75 c6                	jne    2c00 <count_avx2+0x80>
    2c3a:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
    2c40:	44 89 c6             	mov    %r8d,%esi
    2c43:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2c47:	83 e6 f0             	and    $0xfffffff0,%esi
    2c4a:	41 83 e0 0f          	and    $0xf,%r8d
    2c4e:	c5 f1 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm1
    2c53:	8d 4e 01             	lea    0x1(%rsi),%ecx
    2c56:	c5 f9 fe c9          	vpaddd %xmm1,%xmm0,%xmm1
    2c5a:	c5 e9 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm2
    2c5f:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
    2c63:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2c67:	c5 f9 7e ca          	vmovd  %xmm1,%edx
    2c6b:	0f 84 32 02 00 00    	je     2ea3 <count_avx2+0x323>
    2c71:	c5 f8 77             	vzeroupper
    2c74:	41 89 c0             	mov    %eax,%r8d
    2c77:	41 29 f0             	sub    %esi,%r8d
    2c7a:	45 8d 48 ff          	lea    -0x1(%r8),%r9d
    2c7e:	41 83 e8 02          	sub    $0x2,%r8d
    2c82:	41 83 f8 06          	cmp    $0x6,%r8d
    2c86:	0f 86 92 00 00 00    	jbe    2d1e <count_avx2+0x19e>
    2c8c:	ba 00 fc 00 fc       	mov    $0xfc00fc00,%edx
    2c91:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2c95:	ba 00 dc 00 dc       	mov    $0xdc00dc00,%edx
    2c9a:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    2c9f:	c5 f9 6e da          	vmovd  %edx,%xmm3
    2ca3:	c5 f1 db 44 77 02    	vpand  0x2(%rdi,%rsi,2),%xmm1,%xmm0
    2ca9:	c4 e2 79 58 db       	vpbroadcastd %xmm3,%xmm3
    2cae:	c5 f1 db 0c 77       	vpand  (%rdi,%rsi,2),%xmm1,%xmm1
    2cb3:	be 00 d8 00 d8       	mov    $0xd800d800,%esi
    2cb8:	c5 f9 75 c3          	vpcmpeqw %xmm3,%xmm0,%xmm0
    2cbc:	c5 f9 6e de          	vmovd  %esi,%xmm3
    2cc0:	be 01 00 01 00       	mov    $0x10001,%esi
    2cc5:	c4 e2 79 58 db       	vpbroadcastd %xmm3,%xmm3
    2cca:	c5 f1 75 cb          	vpcmpeqw %xmm3,%xmm1,%xmm1
    2cce:	c5 f9 db c1          	vpand  %xmm1,%xmm0,%xmm0
    2cd2:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    2cd6:	44 89 ce             	mov    %r9d,%esi
    2cd9:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    2cde:	83 e6 f8             	and    $0xfffffff8,%esi
    2ce1:	c5 f9 db c1          	vpand  %xmm1,%xmm0,%xmm0
    2ce5:	01 f1                	add    %esi,%ecx
    2ce7:	41 83 e1 07          	and    $0x7,%r9d
    2ceb:	c4 e2 79 33 c8       	vpmovzxwd %xmm0,%xmm1
    2cf0:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    2cf5:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
    2cf9:	c4 e2 79 33 c0       	vpmovzxwd %xmm0,%xmm0
    2cfe:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2d02:	c5 f1 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm1
    2d07:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2d0b:	c5 f1 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm1
    2d10:	c5 f9 fe c1          	vpaddd %xmm1,%xmm0,%xmm0
    2d14:	c5 f9 7e c2          	vmovd  %xmm0,%edx
    2d18:	0f 84 70 01 00 00    	je     2e8e <count_avx2+0x30e>
    2d1e:	48 63 f1             	movslq %ecx,%rsi
    2d21:	48 01 f6             	add    %rsi,%rsi
    2d24:	4c 8d 0c 37          	lea    (%rdi,%rsi,1),%r9
    2d28:	45 0f b7 01          	movzwl (%r9),%r8d
    2d2c:	45 0f b7 49 fe       	movzwl -0x2(%r9),%r9d
    2d31:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2d37:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2d3d:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2d43:	41 0f 94 c2          	sete   %r10b
    2d47:	45 31 c9             	xor    %r9d,%r9d
    2d4a:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2d50:	41 0f 94 c1          	sete   %r9b
    2d54:	45 21 d1             	and    %r10d,%r9d
    2d57:	44 01 ca             	add    %r9d,%edx
    2d5a:	44 8d 49 01          	lea    0x1(%rcx),%r9d
    2d5e:	44 39 c8             	cmp    %r9d,%eax
    2d61:	0f 8e 27 01 00 00    	jle    2e8e <count_avx2+0x30e>
    2d67:	44 0f b7 4c 37 02    	movzwl 0x2(%rdi,%rsi,1),%r9d
    2d6d:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2d73:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2d79:	41 0f 94 c2          	sete   %r10b
    2d7d:	45 31 c0             	xor    %r8d,%r8d
    2d80:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2d86:	41 0f 94 c0          	sete   %r8b
    2d8a:	45 21 d0             	and    %r10d,%r8d
    2d8d:	44 01 c2             	add    %r8d,%edx
    2d90:	44 8d 41 02          	lea    0x2(%rcx),%r8d
    2d94:	44 39 c0             	cmp    %r8d,%eax
    2d97:	0f 8e f1 00 00 00    	jle    2e8e <count_avx2+0x30e>
    2d9d:	44 0f b7 44 37 04    	movzwl 0x4(%rdi,%rsi,1),%r8d
    2da3:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2da9:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2daf:	41 0f 94 c2          	sete   %r10b
    2db3:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2db9:	41 0f 94 c1          	sete   %r9b
    2dbd:	45 0f b6 c9          	movzbl %r9b,%r9d
    2dc1:	45 21 d1             	and    %r10d,%r9d
    2dc4:	44 01 ca             	add    %r9d,%edx
    2dc7:	44 8d 49 03          	lea    0x3(%rcx),%r9d
    2dcb:	44 39 c8             	cmp    %r9d,%eax
    2dce:	0f 8e ba 00 00 00    	jle    2e8e <count_avx2+0x30e>
    2dd4:	44 0f b7 4c 37 06    	movzwl 0x6(%rdi,%rsi,1),%r9d
    2dda:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2de0:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2de6:	41 0f 94 c2          	sete   %r10b
    2dea:	45 31 c0             	xor    %r8d,%r8d
    2ded:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2df3:	41 0f 94 c0          	sete   %r8b
    2df7:	45 21 d0             	and    %r10d,%r8d
    2dfa:	44 01 c2             	add    %r8d,%edx
    2dfd:	44 8d 41 04          	lea    0x4(%rcx),%r8d
    2e01:	44 39 c0             	cmp    %r8d,%eax
    2e04:	0f 8e 84 00 00 00    	jle    2e8e <count_avx2+0x30e>
    2e0a:	44 0f b7 44 37 08    	movzwl 0x8(%rdi,%rsi,1),%r8d
    2e10:	66 41 81 e0 00 fc    	and    $0xfc00,%r8w
    2e16:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2e1c:	41 0f 94 c2          	sete   %r10b
    2e20:	45 31 c9             	xor    %r9d,%r9d
    2e23:	66 41 81 f8 00 dc    	cmp    $0xdc00,%r8w
    2e29:	41 0f 94 c1          	sete   %r9b
    2e2d:	45 21 d1             	and    %r10d,%r9d
    2e30:	44 01 ca             	add    %r9d,%edx
    2e33:	44 8d 49 05          	lea    0x5(%rcx),%r9d
    2e37:	44 39 c8             	cmp    %r9d,%eax
    2e3a:	7e 52                	jle    2e8e <count_avx2+0x30e>
    2e3c:	44 0f b7 4c 37 0a    	movzwl 0xa(%rdi,%rsi,1),%r9d
    2e42:	66 41 81 e1 00 fc    	and    $0xfc00,%r9w
    2e48:	66 41 81 f8 00 d8    	cmp    $0xd800,%r8w
    2e4e:	41 0f 94 c2          	sete   %r10b
    2e52:	45 31 c0             	xor    %r8d,%r8d
    2e55:	66 41 81 f9 00 dc    	cmp    $0xdc00,%r9w
    2e5b:	41 0f 94 c0          	sete   %r8b
    2e5f:	83 c1 06             	add    $0x6,%ecx
    2e62:	45 21 d0             	and    %r10d,%r8d
    2e65:	44 01 c2             	add    %r8d,%edx
    2e68:	39 c8                	cmp    %ecx,%eax
    2e6a:	7e 22                	jle    2e8e <count_avx2+0x30e>
    2e6c:	0f b7 4c 37 0c       	movzwl 0xc(%rdi,%rsi,1),%ecx
    2e71:	66 81 e1 00 fc       	and    $0xfc00,%cx
    2e76:	66 81 f9 00 dc       	cmp    $0xdc00,%cx
    2e7b:	40 0f 94 c6          	sete   %sil
    2e7f:	31 c9                	xor    %ecx,%ecx
    2e81:	66 41 81 f9 00 d8    	cmp    $0xd800,%r9w
    2e87:	0f 94 c1             	sete   %cl
    2e8a:	21 f1                	and    %esi,%ecx
    2e8c:	01 ca                	add    %ecx,%edx
    2e8e:	29 d0                	sub    %edx,%eax
    2e90:	c3                   	ret
    2e91:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
    2e95:	31 f6                	xor    %esi,%esi
    2e97:	31 d2                	xor    %edx,%edx
    2e99:	b9 01 00 00 00       	mov    $0x1,%ecx
    2e9e:	e9 d1 fd ff ff       	jmp    2c74 <count_avx2+0xf4>
    2ea3:	c5 f8 77             	vzeroupper
    2ea6:	29 d0                	sub    %edx,%eax
    2ea8:	c3                   	ret

Disassembly of section .fini:
