	.file	"count-loop.cpp"
	.text
	.p2align 4
	.globl	simdutf_count_java_code_points
	.type	simdutf_count_java_code_points, @function
simdutf_count_java_code_points:
.LFB3:
	.cfi_startproc
	movl	%esi, %eax
	cmpl	$1, %esi
	jle	.L1
	leal	-2(%rsi), %edx
	leal	-1(%rsi), %r8d
	cmpl	$14, %edx
	jbe	.L9
	movl	$-67044352, %ecx
	movl	%r8d, %esi
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%rdi, %rdx
	vmovd	%ecx, %xmm3
	movl	$-671033344, %ecx
	shrl	$4, %esi
	vmovd	%ecx, %xmm6
	movl	$-603923456, %ecx
	salq	$5, %rsi
	vpbroadcastd	%xmm3, %ymm3
	vmovd	%ecx, %xmm5
	movl	$65537, %ecx
	addq	%rdi, %rsi
	vmovd	%ecx, %xmm4
	vpbroadcastd	%xmm6, %ymm6
	vpbroadcastd	%xmm5, %ymm5
	vpbroadcastd	%xmm4, %ymm4
	.p2align 6
	.p2align 4
	.p2align 3
.L4:
	vpand	(%rdx), %ymm3, %ymm0
	vpand	2(%rdx), %ymm3, %ymm2
	addq	$32, %rdx
	vpcmpeqw	%ymm5, %ymm2, %ymm2
	vpcmpeqw	%ymm6, %ymm0, %ymm0
	vpand	%ymm2, %ymm0, %ymm0
	vpand	%ymm4, %ymm0, %ymm0
	vpmovzxwd	%xmm0, %ymm2
	vextracti128	$0x1, %ymm0, %xmm0
	vpaddd	%ymm1, %ymm2, %ymm1
	vpmovzxwd	%xmm0, %ymm0
	vpaddd	%ymm1, %ymm0, %ymm1
	cmpq	%rdx, %rsi
	jne	.L4
	vextracti128	$0x1, %ymm1, %xmm0
	movl	%r8d, %esi
	vpaddd	%xmm1, %xmm0, %xmm0
	andl	$-16, %esi
	andl	$15, %r8d
	vpsrldq	$8, %xmm0, %xmm1
	leal	1(%rsi), %ecx
	vpaddd	%xmm1, %xmm0, %xmm1
	vpsrldq	$4, %xmm1, %xmm2
	vpaddd	%xmm2, %xmm1, %xmm1
	vmovdqa	%xmm0, %xmm2
	vmovd	%xmm1, %edx
	je	.L19
	vzeroupper
.L3:
	movl	%eax, %r8d
	subl	%esi, %r8d
	leal	-1(%r8), %r9d
	subl	$2, %r8d
	cmpl	$6, %r8d
	jbe	.L6
	movl	$-67044352, %edx
	vmovd	%edx, %xmm1
	movl	$-603923456, %edx
	vpbroadcastd	%xmm1, %xmm1
	vmovd	%edx, %xmm3
	vpand	2(%rdi,%rsi,2), %xmm1, %xmm0
	vpbroadcastd	%xmm3, %xmm3
	vpand	(%rdi,%rsi,2), %xmm1, %xmm1
	movl	$-671033344, %esi
	vpcmpeqw	%xmm3, %xmm0, %xmm0
	vmovd	%esi, %xmm3
	movl	$65537, %esi
	vpbroadcastd	%xmm3, %xmm3
	vpcmpeqw	%xmm3, %xmm1, %xmm1
	vpand	%xmm1, %xmm0, %xmm0
	vmovd	%esi, %xmm1
	movl	%r9d, %esi
	vpbroadcastd	%xmm1, %xmm1
	andl	$-8, %esi
	vpand	%xmm1, %xmm0, %xmm0
	addl	%esi, %ecx
	andl	$7, %r9d
	vpmovzxwd	%xmm0, %xmm1
	vpsrldq	$8, %xmm0, %xmm0
	vpaddd	%xmm2, %xmm1, %xmm1
	vpmovzxwd	%xmm0, %xmm0
	vpaddd	%xmm1, %xmm0, %xmm0
	vpsrldq	$8, %xmm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vpsrldq	$4, %xmm0, %xmm1
	vpaddd	%xmm1, %xmm0, %xmm0
	vmovd	%xmm0, %edx
	je	.L5
.L6:
	movslq	%ecx, %rsi
	addq	%rsi, %rsi
	leaq	(%rdi,%rsi), %r9
	movzwl	(%r9), %r8d
	movzwl	-2(%r9), %r9d
	andw	$-1024, %r9w
	andw	$-1024, %r8w
	cmpw	$-10240, %r9w
	sete	%r10b
	xorl	%r9d, %r9d
	cmpw	$-9216, %r8w
	sete	%r9b
	andl	%r10d, %r9d
	addl	%r9d, %edx
	leal	1(%rcx), %r9d
	cmpl	%r9d, %eax
	jle	.L5
	movzwl	2(%rdi,%rsi), %r9d
	andw	$-1024, %r9w
	cmpw	$-10240, %r8w
	sete	%r10b
	xorl	%r8d, %r8d
	cmpw	$-9216, %r9w
	sete	%r8b
	andl	%r10d, %r8d
	addl	%r8d, %edx
	leal	2(%rcx), %r8d
	cmpl	%r8d, %eax
	jle	.L5
	movzwl	4(%rdi,%rsi), %r8d
	andw	$-1024, %r8w
	cmpw	$-9216, %r8w
	sete	%r10b
	cmpw	$-10240, %r9w
	sete	%r9b
	movzbl	%r9b, %r9d
	andl	%r10d, %r9d
	addl	%r9d, %edx
	leal	3(%rcx), %r9d
	cmpl	%r9d, %eax
	jle	.L5
	movzwl	6(%rdi,%rsi), %r9d
	andw	$-1024, %r9w
	cmpw	$-10240, %r8w
	sete	%r10b
	xorl	%r8d, %r8d
	cmpw	$-9216, %r9w
	sete	%r8b
	andl	%r10d, %r8d
	addl	%r8d, %edx
	leal	4(%rcx), %r8d
	cmpl	%r8d, %eax
	jle	.L5
	movzwl	8(%rdi,%rsi), %r8d
	andw	$-1024, %r8w
	cmpw	$-10240, %r9w
	sete	%r10b
	xorl	%r9d, %r9d
	cmpw	$-9216, %r8w
	sete	%r9b
	andl	%r10d, %r9d
	addl	%r9d, %edx
	leal	5(%rcx), %r9d
	cmpl	%r9d, %eax
	jle	.L5
	movzwl	10(%rdi,%rsi), %r9d
	andw	$-1024, %r9w
	cmpw	$-10240, %r8w
	sete	%r10b
	xorl	%r8d, %r8d
	cmpw	$-9216, %r9w
	sete	%r8b
	addl	$6, %ecx
	andl	%r10d, %r8d
	addl	%r8d, %edx
	cmpl	%ecx, %eax
	jle	.L5
	movzwl	12(%rdi,%rsi), %ecx
	andw	$-1024, %cx
	cmpw	$-9216, %cx
	sete	%sil
	xorl	%ecx, %ecx
	cmpw	$-10240, %r9w
	sete	%cl
	andl	%esi, %ecx
	addl	%ecx, %edx
.L5:
	subl	%edx, %eax
.L1:
	ret
.L9:
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%esi, %esi
	movl	$1, %ecx
	xorl	%edx, %edx
	jmp	.L3
.L19:
	vzeroupper
	subl	%edx, %eax
	ret
	.cfi_endproc
.LFE3:
	.size	simdutf_count_java_code_points, .-simdutf_count_java_code_points
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
