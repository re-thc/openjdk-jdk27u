#include <cstdint>
using jint=int32_t;
// Java counts every isolated surrogate, and each adjacent high/low pair, as
// one code point. Such pairs cannot overlap, so this reduction handles both
// well-formed and malformed UTF-16 without validation and a second pass.
extern "C" jint simdutf_count_java_code_points(const char16_t* input, jint len) {
  jint pairs = 0;
  for (jint i = 1; i < len; i++) {
    jint high = (input[i - 1] & 0xfc00) == 0xd800;
    jint low = (input[i] & 0xfc00) == 0xdc00;
    pairs += high & low;
  }
  return len - pairs;
}

