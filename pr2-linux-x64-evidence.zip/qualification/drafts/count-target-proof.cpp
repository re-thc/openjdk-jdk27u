#include <cstdint>
#include <cstdio>
#include <vector>
using jint=int32_t;
#if defined(__GNUC__) || defined(__clang__)
__attribute__((always_inline))
#endif
static inline jint simdutf_count_java_code_points_loop(const char16_t* input, jint len) {
  jint pairs = 0;
  for (jint i = 1; i < len; i++) {
    jint high = (input[i - 1] & 0xfc00) == 0xd800;
    jint low = (input[i] & 0xfc00) == 0xdc00;
    pairs += high & low;
  }
  return len - pairs;
}

extern "C" jint count_generic(const char16_t* p, jint n) { return simdutf_count_java_code_points_loop(p,n); }
extern "C" __attribute__((target("avx2"),noinline)) jint count_avx2(const char16_t* p, jint n) { return simdutf_count_java_code_points_loop(p,n); }
int main() {
  const char16_t values[]={0,u'a',0xd7ff,0xffff,0xd800,0xdbff,0xdc00,0xdfff};
  for(int pattern=0;pattern<4096;pattern++) {
    std::vector<char16_t> p(2049);
    for(int i=0;i<2049;i++)p[i]=values[(pattern>>((i&3)*3))&7];
    for(int n:{0,1,2,3,4,7,8,15,16,17,31,32,33,63,64,65,127,128,129,1023,1024,1025,2049}) {
      int expected=0;
      for(int i=0;i<n;expected++) {
        char16_t c=p[i++];
        if(c>=0xd800&&c<=0xdbff&&i<n&&p[i]>=0xdc00&&p[i]<=0xdfff)i++;
      }
      if(count_generic(p.data(),n)!=expected || (__builtin_cpu_supports("avx2")&&count_avx2(p.data(),n)!=expected))return 1;
    }
  }
  std::puts("PASS generic/AVX2 reduction against independent code-point walk");
}
