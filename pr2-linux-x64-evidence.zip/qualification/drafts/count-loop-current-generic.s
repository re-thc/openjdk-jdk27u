	.file	"count-loop.cpp"
	.text
	.p2align 4
	.globl	simdutf_count_java_code_points
	.type	simdutf_count_java_code_points, @function
simdutf_count_java_code_points:
.LFB3:
	.cfi_startproc
	movl	%esi, %eax
	cmpl	$1, %esi
	jle	.L1
	leal	-2(%rsi), %edx
	leal	-1(%rsi), %r8d
	cmpl	$6, %edx
	jbe	.L9
	movl	$-67044352, %esi
	movl	%r8d, %ecx
	pxor	%xmm7, %xmm7
	movq	%rdi, %rdx
	movd	%esi, %xmm2
	movl	$-671033344, %esi
	shrl	$3, %ecx
	pxor	%xmm3, %xmm3
	movd	%esi, %xmm6
	movl	$-603923456, %esi
	salq	$4, %rcx
	pshufd	$0, %xmm2, %xmm2
	movd	%esi, %xmm5
	movl	$65537, %esi
	addq	%rdi, %rcx
	pshufd	$0, %xmm6, %xmm6
	movd	%esi, %xmm4
	pshufd	$0, %xmm5, %xmm5
	pshufd	$0, %xmm4, %xmm4
	.p2align 4
	.p2align 3
.L4:
	movdqu	(%rdx), %xmm0
	movdqu	2(%rdx), %xmm1
	addq	$16, %rdx
	pand	%xmm2, %xmm0
	pand	%xmm2, %xmm1
	pcmpeqw	%xmm5, %xmm1
	pcmpeqw	%xmm6, %xmm0
	pand	%xmm1, %xmm0
	pand	%xmm4, %xmm0
	movdqa	%xmm0, %xmm1
	punpckhwd	%xmm3, %xmm0
	punpcklwd	%xmm3, %xmm1
	paddd	%xmm7, %xmm1
	movdqa	%xmm1, %xmm7
	paddd	%xmm0, %xmm7
	cmpq	%rdx, %rcx
	jne	.L4
	movdqa	%xmm7, %xmm0
	movl	%r8d, %ecx
	psrldq	$8, %xmm0
	andl	$-8, %ecx
	andl	$7, %r8d
	paddd	%xmm7, %xmm0
	leal	1(%rcx), %esi
	movdqa	%xmm0, %xmm1
	psrldq	$4, %xmm1
	paddd	%xmm1, %xmm0
	movd	%xmm0, %edx
	movdqa	%xmm7, %xmm0
	psrldq	$8, %xmm7
	paddd	%xmm7, %xmm0
	je	.L5
.L3:
	movl	%eax, %r9d
	subl	%ecx, %r9d
	leal	-1(%r9), %r8d
	subl	$2, %r9d
	cmpl	$2, %r9d
	jbe	.L6
	movq	.LC4(%rip), %xmm3
	movq	2(%rdi,%rcx,2), %xmm1
	movq	.LC5(%rip), %xmm2
	pand	%xmm3, %xmm1
	pcmpeqw	%xmm2, %xmm1
	movq	(%rdi,%rcx,2), %xmm2
	movl	%r8d, %ecx
	andl	$-4, %ecx
	pand	%xmm3, %xmm2
	addl	%ecx, %esi
	andl	$3, %r8d
	movq	.LC6(%rip), %xmm3
	pcmpeqw	%xmm3, %xmm2
	pxor	%xmm3, %xmm3
	pand	%xmm2, %xmm1
	movq	.LC7(%rip), %xmm2
	pand	%xmm2, %xmm1
	movdqa	%xmm1, %xmm2
	punpcklwd	%xmm3, %xmm1
	punpcklwd	%xmm3, %xmm2
	pshufd	$78, %xmm1, %xmm1
	paddd	%xmm2, %xmm0
	paddd	%xmm1, %xmm0
	movdqa	%xmm0, %xmm1
	psrlq	$32, %xmm1
	paddd	%xmm1, %xmm0
	movd	%xmm0, %edx
	je	.L5
.L6:
	movslq	%esi, %rcx
	addq	%rcx, %rcx
	leaq	(%rdi,%rcx), %r9
	movzwl	(%r9), %r8d
	movzwl	-2(%r9), %r9d
	andw	$-1024, %r9w
	andw	$-1024, %r8w
	cmpw	$-10240, %r9w
	sete	%r10b
	xorl	%r9d, %r9d
	cmpw	$-9216, %r8w
	sete	%r9b
	andl	%r10d, %r9d
	addl	%r9d, %edx
	leal	1(%rsi), %r9d
	cmpl	%r9d, %eax
	jle	.L5
	movzwl	2(%rdi,%rcx), %r9d
	andw	$-1024, %r9w
	cmpw	$-10240, %r8w
	sete	%r10b
	xorl	%r8d, %r8d
	cmpw	$-9216, %r9w
	sete	%r8b
	addl	$2, %esi
	andl	%r10d, %r8d
	addl	%r8d, %edx
	cmpl	%esi, %eax
	jle	.L5
	movzwl	4(%rdi,%rcx), %ecx
	andw	$-1024, %cx
	cmpw	$-9216, %cx
	sete	%sil
	xorl	%ecx, %ecx
	cmpw	$-10240, %r9w
	sete	%cl
	andl	%esi, %ecx
	addl	%ecx, %edx
.L5:
	subl	%edx, %eax
.L1:
	ret
.L9:
	pxor	%xmm0, %xmm0
	xorl	%ecx, %ecx
	movl	$1, %esi
	xorl	%edx, %edx
	jmp	.L3
	.cfi_endproc
.LFE3:
	.size	simdutf_count_java_code_points, .-simdutf_count_java_code_points
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC4:
	.value	-1024
	.value	-1024
	.value	-1024
	.value	-1024
	.align 8
.LC5:
	.value	-9216
	.value	-9216
	.value	-9216
	.value	-9216
	.align 8
.LC6:
	.value	-10240
	.value	-10240
	.value	-10240
	.value	-10240
	.align 8
.LC7:
	.value	1
	.value	1
	.value	1
	.value	1
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
