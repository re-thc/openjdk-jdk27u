import json
import statistics
import sys
from pathlib import Path

root=Path(__file__).parent/sys.argv[1]
plan=json.loads((root/'plan.json').read_text())
rows=[json.loads(x) for x in (root/'commands.jsonl').read_text().splitlines()]
cases={c['id']:c for c in plan['cases']}
report=[]
for ident,case in cases.items():
    observations=[r for r in rows if r['case']==ident and 'score' in r]
    if not observations: continue
    variants=sorted({r['variant'] for r in observations})
    result=dict(case=case,variants={},ratios={})
    for v in variants:
        group=[r for r in observations if r['variant']==v]
        scores=[r['score'] for r in group]
        alloc=[r['allocation_bytes_per_op'] for r in group if r.get('allocation_bytes_per_op') is not None]
        result['variants'][v]=dict(median=statistics.median(scores),minimum=min(scores),maximum=max(scores),
            samples=len(scores),allocation=statistics.median(alloc) if alloc else None,unit=group[0]['score_unit'])
    for numerator,denominator in [('E','O'),('E','B'),('E','D'),('D','B'),('P','E')]:
        paired=[]
        for n in observations:
            if n['variant']!=numerator: continue
            ds=[d for d in observations if d['variant']==denominator and d.get('order_index',d['order'])==n.get('order_index',n['order']) and d['position']==n['position']]
            if ds: paired.append(n['score']/ds[0]['score'])
        if paired: result['ratios'][numerator+'/'+denominator]=dict(median=statistics.median(paired),minimum=min(paired),maximum=max(paired),samples=len(paired))
    report.append(result)
    ratios=' '.join(f"{k} {v['median']:.3f}[{v['minimum']:.3f},{v['maximum']:.3f}]" for k,v in result['ratios'].items())
    vals=' '.join(f"{k}={v['median']:.3f}/{v['allocation']:.1f}B" for k,v in result['variants'].items())
    print(ident,case['benchmark'].split('.')[-1],case['params'],case.get('vm_extra',''),ratios,vals)
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
