import java.lang.management.ManagementFactory;
import com.sun.management.HotSpotDiagnosticMXBean;
import jdk.internal.util.SimdUTF;

public class AOTPolicyProbe {
    static volatile int sink;
    static boolean enabled() { return SimdUTF.isEnabled(); }
    static boolean eligible() { return SimdUTF.isEligible(4096); }
    public static void main(String[] args) {
        check();
        for (int i = 0; i < 100000; i++) {
            if (enabled()) sink++;
            if (eligible()) sink++;
        }
        check();
    }
    static void check() {
        boolean flag = Boolean.parseBoolean(ManagementFactory.getPlatformMXBean(HotSpotDiagnosticMXBean.class)
                .getVMOption("UseSIMDUTFIntrinsics").getValue());
        boolean active = enabled();
        boolean admitted = eligible();
        System.out.println("flag=" + flag + " enabled=" + active + " eligible=" + admitted);
        if (active != flag || admitted != flag) throw new AssertionError("Stale runtime policy in AOT code");
    }
}
