# PR2 fresh Linux x64 qualification notes

This is a working record. Final decisions and complete paired results will be published after the fixed panels finish.

## Identities and provenance

- Original baseline B: e206bae32b2a6cc1fa9464ad34d75f2df4b347e9.
- Preceding published PR head O: 9d5639bd4c1e4ce8878a1ddff374cc8ad05c502f.
- Retained unvalidated candidate: 2c53354189d029eb5aa2ea2b7beaa1ca4a5cd0bb; patch SHA-256 72f0a199c82cff8f611247a32efa9f213017cfb825a657c0a6b2b67d0388d1c7.
- Initial complete fresh candidate: 7c20b8177effdacde2be69f8a35aece998271d4d. This includes the pending patch, stateless-accessor repair and attribution fixes. Its measurements are not measurements of 2c533541 or the earlier 04ed6e6 experiment.
- Read repair E2: 470757fc62ca5e2f226a019db05ffe0b3374cb71.
- One-pass count candidate E3: 5091f852a19284e263e3b43d949c9139a6d1f35e.
- Fixture pin: 87f93e1cc6014c05b521c6c7492b8b30912fd9a2. Source and corpus hashes matched the retained manifest and remote branch.
- All complete images were freshly built; no old image or toolchain came from the archive. Exact configure/compiler, source trees, executable/module hashes and build dates are in the image manifests.

The 9,204,057-byte qualification-evidence.zip matched SHA-256 f5119e15cc708f89acaeaa7de297e4d13759647f619041e27fe05276c2f51e55, with all 2,873 internal manifest entries verified. The smaller replacement-host delta is supplementary. Its reports and commands were read before execution. Attached documents were evidence, not independent authorization.

## Repairs and experiments

The old x64 and AArch64 runtime CI jobs failed the same eight AOT tests: an assertion in the anonymous Charset accessor generated a synthetic static assertion-state field, violating the stateless-accessor requirement. Assertions and assignment now live in Charset itself. The accessor now delegates without declared fields. This was checked in complete images and against the eight failing tests.

The pending patch force-inlined the whole UTF-32 census and changed UTF-16 array word reads into byte assembly. The fresh initial panel retained large C2 regressions. Compilation logs showed the UTF-32 Kind dispatcher grow from a 584-byte C2 nmethod to 3,464 bytes, with callers refusing to inline an already-large compiled method.

Five patched-class alternatives were evaluated in separate source-labelled diagnostic panels. Both sides used patched modules, and their VM image source and helper source SHA-256 are retained. They are not presented as full-image qualification.

The adopted read repair restores UTF-16 word reads and keeps the published C2 word census/copy separate from the portable C1/interpreter implementation. It avoids forcing the entire census into callers. The small C2 selector folds to the word route. The duplicated census logic is deliberate; both versions retain scalar-range checks and surrogate-valued UTF-32 fallback. The copied UTF-32 MemorySegment route remains unchanged.

The attempted single-census simplification was rejected after all four fixed pairs: short C2 median P/E 1.526 [1.352,1.784], bulk UTF-32 Latin-1 5.824 [5.334,7.276]. Its small C1 improvement does not justify those losses. The packed, separate-census experiment also failed to establish a worthwhile benefit. All absolute observations and losses remain available.

The count candidate replaces scalar validation followed by simdutf counting with an exact reduction over adjacent high/low surrogate pairs. Such pairs cannot overlap in a fixed input, so len minus pair count implements Java's dialect, including isolated surrogates. The now-unnecessary edge admission check is removed. No density heuristic is used. The actual HotSpot object contains vector instructions for the reduction; standalone copies also vectorize with generic x64 settings. New tests cover surrogate classes, subranges, vector tails and native leaf boundaries. Separate fixed mutation probes observed no count-bound violations; they do not establish snapshot semantics for raced arrays.

## Validation completed before count timing

E3 passed 24 jtreg records, including 49 main and 17 driver executions, all eight targeted AOT failures, 140 source-labelled fixture outputs across B/O/E3/disabled-E3, and twelve enabled/disabled AOT record/create/strict/auto commands. The eighth AOT test, MetaspaceAllocGaps, was run separately without target VM options because it requires vm.flagless. E2 separately passed six wide/policy/dialect records, including the new default-policy forced-C2 run. Raw .jtr files and commands are retained.

## Measurement method and host limits

The existing continuation framework and pinned fixture were reused. JMH runs use one benchmark thread, one independent fork per invocation, three 1-second warmups and three 500-ms measurements, GC profiling, 512 MiB heap and two active processors. Results are interleaved by role. Paired summaries use ratios from the same order and configuration position, then median and observed minimum/maximum. No failed command or loss is removed.

The host is native Linux x64 on an Ice Lake Xeon 8370C KVM guest, with AVX512, a four-CPU quota and 16 GiB RAM. All images use GCC 14.2.0 and the same release configuration, x86-64-v3/generic tuning and disabled javac server. Initial javac-server sandbox failures are preserved. A process-local child reaper was used for builds/tests because PID1 does not reap; it was not used for benchmark JVMs.

The initial panel and first two reader diagnostics used CPUs 0/1. Their extreme timing spikes coincided with 50–78% steal on those CPUs. A single affinity change to CPUs 2/3 was made for subsequent comparisons, based on host counters. All earlier observations remain separate. Later controls also vary, so small apparent changes cannot be assigned precise confidence. Every invocation retains before/after host counters; scores are not adjusted or filtered by them.

The full-image counting comparison has four fixed EP/PE pairs, seven workloads and two controls (72 invocations). The prepared final panel is the union of the retained wide/count/extension cases with duplicate configurations merged: 35 configurations plus bookend controls, four balanced role orders OBED/DEBO/BDOE/EODB (592 invocations). Every role occupies each order position once. B, O, the chosen fresh candidate and its same-image disabled mode are explicit in each manifest. Forty-eight fresh-JVM first-use processes use the same four role orders and manually assembled wire data to avoid warming the codec through encoding.

Native AArch64 and macOS performance remain separate; no x64 timing claim is extended to those platforms. Ordinary CI will be followed after publication.
