#!/usr/bin/env bash
set -euo pipefail
role=$1
repo=$2
out=/workspace/work/pr2-evidence/fresh
mkdir -p "$out/images"
source /workspace/toolchains/activate.sh
cd "$repo"
test -z "$(git status --porcelain=v1)"
git rev-parse HEAD 'HEAD^{tree}' > "$out/$role-source.txt"
date -u +%FT%TZ > "$out/$role-build-start.txt"
  bash configure --disable-desktop --enable-headless-only \
    --enable-jvm-feature-serialgc --enable-jvm-feature-g1gc --enable-jvm-feature-zgc \
    --disable-jvm-feature-epsilongc --disable-jvm-feature-parallelgc --disable-jvm-feature-shenandoahgc \
    --with-extra-cflags='-march=x86-64-v3 -mtune=generic' \
    --with-extra-cxxflags='-march=x86-64-v3 -mtune=generic' \
    --with-extra-ldflags='-fuse-ld=mold -B/workspace/toolchains/mold/bin' \
    --with-conf-name=pr2-release --with-debug-level=release --with-jvm-variants=server \
    --with-boot-jdk=/workspace/toolchains/jdk27 --with-boot-jdk-jvmargs='-Xms256m -Xmx1g' \
    --with-toolchain-path=/usr/bin --with-native-debug-symbols=none --disable-ccache --with-jobs=4 \
    --with-jtreg=/workspace/toolchains/jtreg83 --with-version-opt=pr2-qualification --disable-javac-server \
    > "$out/$role-configure.log" 2>&1
make CONF=pr2-release JOBS=4 images > "$out/$role-build.log" 2>&1
date -u +%FT%TZ > "$out/$role-build-end.txt"
test ! -e "$out/images/$role"
cp -a build/pr2-release/images/jdk "$out/images/$role"
cp build/pr2-release/spec.gmk "$out/$role-spec.gmk"
"$out/images/$role/bin/java" -version > "$out/$role-version.txt" 2>&1
printf '%s image complete\n' "$role"
