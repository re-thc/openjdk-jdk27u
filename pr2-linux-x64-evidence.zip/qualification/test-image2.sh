#!/usr/bin/env bash
set -euo pipefail
repo=/workspace/work/pr2
out=/workspace/work/pr2-evidence/fresh
image="$out/images/E2"
date -u +%FT%TZ > "$out/tests2-start.txt"
/workspace/toolchains/jdk27/bin/java -Xmx256m -XX:ActiveProcessorCount=2 \
  -jar /workspace/toolchains/jtreg83/lib/jtreg.jar \
  -jdk:"$image" -conc:1 -timeoutFactor:3 \
  -javaoption:-Xmx512m -javaoption:-XX:ActiveProcessorCount=2 \
  -w:"$out/semantics2-work" -r:"$out/semantics2-report" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/TestSimdUTFUTF32Admission.java" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/TestSimdUTFUTF32WordReads.java" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/TestSimdUTFDisabled.java" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/SimdUTFTest.java#portable" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/SimdUTFTest.java#compiled" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/SimdUTFTest.java#sse" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/SimdUTFLargeTest.java#portable" \
  "$repo/test/hotspot/jtreg/compiler/intrinsics/simdutf/SimdUTFLargeTest.java#compiled" \
  "$repo/test/jdk/java/lang/String/SimdUTFWideTest.java#portable" \
  "$repo/test/jdk/java/lang/String/SimdUTFWideTest.java#compiled" \
  "$repo/test/jdk/java/lang/String/SimdUTFWideTest.java#tiny-segment" \
  "$repo/test/hotspot/jtreg/compiler/escapeAnalysis/TestSimdUTFLeaf.java" \
  "$repo/test/jdk/java/nio/charset/CharsetDecoder/ReplacementCopy.java" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCache/HelloAOTCache.java" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCode/AOTCodeCompressedOopsTest.java" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCode/AOTCodeCPUFeatureIncompatibilityTest.java" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCode/AOTCodeTest.java#g1" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCode/AOTCodeTest.java#serial" \
  "$repo/test/hotspot/jtreg/runtime/cds/appcds/aotCode/AOTCodeTest.java#Z" \
  "$repo/test/hotspot/jtreg/runtime/cds/ArchiveRelocationBitMap.java#aot" \
  "$repo/test/hotspot/jtreg/runtime/cds/MetaspaceAllocGaps.java" \
  > "$out/semantics2.log" 2>&1
date -u +%FT%TZ > "$out/tests2-end.txt"
