#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
for variant in final-control candidate6; do
  images/E3/bin/javac --patch-module "java.base=patches/$variant-src" -d "patches/$variant-classes" "patches/$variant-src/java/lang/StringCodingWide.java" > "patches/$variant-compile.log" 2>&1
  for panel in qualified-final extension; do
    images/E3/bin/java --patch-module "java.base=patches/$variant-classes" -Xms512m -Xmx512m -XX:ActiveProcessorCount=2 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' PanelSmoke "$panel-cases.tsv" > "patches/$variant-$panel-smoke.log" 2>&1
  done
  for charset in UTF-32 UTF-32BE UTF-32LE; do
    images/E3/bin/java --patch-module "java.base=patches/$variant-classes" -Xms128m -Xmx256m -XX:ActiveProcessorCount=2 -Xbatch -XX:-TieredCompilation -XX:CompileThreshold=100 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' HotWideWitness "$charset" > "patches/$variant-$charset-hot.log" 2>&1
  done
done
python3 run.py reader6-diagnostic-plan.json reader6-diagnostic > reader6-diagnostic-progress.log 2>&1
python3 analyse.py reader6-diagnostic > reader6-analysis.log
