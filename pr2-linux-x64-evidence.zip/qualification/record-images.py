import datetime
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).parent
images = {}
for role in ['B', 'O', 'E']:
    source, tree = (root / (role + '-source.txt')).read_text().splitlines()
    image = root / 'images' / role
    release = (image / 'release').read_text()
    assert source[:12] in release, (role, 'release source mismatch')
    lines = (root / (role + '-spec.gmk')).read_text().splitlines()
    configure = next(line for line in lines if line.startswith('CONFIGURE_COMMAND_LINE :='))
    compiler = [line for line in lines if line.startswith(('CC_VERSION_NUMBER :=', 'CXX_VERSION_NUMBER :='))]
    hashes = {}
    sizes = {}
    for name in ['bin/java', 'lib/libjava.so', 'lib/server/libjvm.so', 'lib/modules']:
        path = image / name
        hashes[name] = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
        sizes[name] = path.stat().st_size
    images[role] = dict(path=str(image), source=source, actual_head=source, tree=tree,
                        release=release, configure=configure, compiler=compiler,
                        files=hashes, sizes=sizes,
                        build_start=(root / (role + '-build-start.txt')).read_text().strip(),
                        build_end=(root / (role + '-build-end.txt')).read_text().strip(),
                        effective_make='make CONF=pr2-release JOBS=4 images')
assert len({entry['configure'] for entry in images.values()}) == 1, 'configuration mismatch'
assert len({tuple(entry['compiler']) for entry in images.values()}) == 1, 'compiler mismatch'
images['D'] = dict(images['E'], additional_vm_args='-XX:-UseSIMDUTFIntrinsics')
result = dict(images=images, recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              host='Intel Xeon Platinum 8370C, native Linux x64, AVX512 available, 4 CPU cgroup quota, 16 GiB memory',
              compiler=subprocess.check_output(['/usr/bin/g++', '--version'], text=True),
              build_supervision='Retained inspected process-local child reaper; benchmark JVMs run without it',
              roles={'B': 'original baseline', 'O': 'preceding published PR head',
                     'E': 'fresh repaired candidate', 'D': 'E image with integration disabled'})
(root / 'images.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({role: {'source': entry['source'], 'tree': entry['tree'], 'path': entry['path']}
                  for role, entry in images.items()}, indent=2))
