import java.util.concurrent.atomic.AtomicBoolean;
import jdk.internal.util.SimdUTF;
public class CountRaceWitness {
  public static void main(String[] args) throws Exception {
    char[] chars = new char[1024];
    for(int i=0;i<chars.length;i++) chars[i]=(char)((i&1)==0?0xd800:0xdc00);
    AtomicBoolean stop=new AtomicBoolean();
    Thread writer=Thread.ofPlatform().start(()->{
      while(!stop.get()) {
        java.util.Arrays.fill(chars,0,32,(char)0xd800);
        java.lang.invoke.VarHandle.fullFence();
        java.util.Arrays.fill(chars,0,32,(char)0xdc00);
        java.lang.invoke.VarHandle.fullFence();
      }
    });
    int minimum=chars.length, maximum=0, declined=0, impossible=0;
    try {
      for(int i=0;i<200000;i++) {
        int actual=SimdUTF.countCodePoints(chars,0,chars.length);
        if(actual<0) declined++;
        else {minimum=Math.min(minimum,actual);maximum=Math.max(maximum,actual);if(actual<chars.length/2||actual>chars.length)impossible++;}
      }
    } finally {stop.set(true);writer.join();}
    System.out.println("min="+minimum+" max="+maximum+" declined="+declined+" impossible="+impossible);
  }
}
