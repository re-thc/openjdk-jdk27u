#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
python3 record-image-set.py images-followup.json B=B O=E3 E=E4 > followup-image-identities.txt
python3 ../handoff/run-reaped.py bash test-image4.sh > tests4-supervision.log 2>&1
python3 ../handoff/run-reaped.py /workspace/toolchains/jdk27/bin/java -Xmx256m -XX:ActiveProcessorCount=2 -jar /workspace/toolchains/jtreg83/lib/jtreg.jar -jdk:images/E4 -conc:1 -timeoutFactor:3 -w:flagless4-work -r:flagless4-report /workspace/work/pr2/test/hotspot/jtreg/runtime/cds/MetaspaceAllocGaps.java > flagless4.log 2>&1
for role in E D; do
  flags=()
  if [[ $role == D ]]; then flags=(-XX:-UseSIMDUTFIntrinsics); fi
  for panel in qualified-final count-final extension; do
    images/E4/bin/java -Xms512m -Xmx512m -XX:ActiveProcessorCount=2 "${flags[@]}" -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' PanelSmoke "$panel-cases.tsv" > "smoke-followup-$role-$panel.log" 2>&1
  done
done
python3 ../handoff/run-reaped.py python3 run-aot-policy-followup.py > aot-policy-followup-progress.log 2>&1
