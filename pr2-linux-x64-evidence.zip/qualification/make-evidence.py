import hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).parent
panels=['wide-initial','c2-diagnostic','reader-diagnostic','reader2-diagnostic','reader3-diagnostic','reader4-diagnostic','reader5-diagnostic','count-diagnostic','final-panel','reader6-diagnostic','reader7-diagnostic','fallback-diagnostic','unicode-diagnostic','followup-panel','first-use-final','first-use-followup']
files=set()
text_ext={'.py','.sh','.java','.json','.jsonl','.md','.txt','.log','.csv','.tsv','.xml','.cpp','.s','.asm','.gmk'}
for p in r.iterdir():
 if p.is_file() and p.name not in {'evidence-manifest.json','evidence-sha256.txt'} and (p.suffix in text_ext or p.name=='source.bundle'): files.add(p)
for directory in panels+['patches','drafts']:
 for p in (r/directory).rglob('*'):
  if p.is_file() and (p.suffix in text_ext or directory=='patches' and p.suffix=='.class'): files.add(p)
for directory in ['semantics-work','flagless-work','reader-full-work','semantics3-work','flagless3-work','semantics4-work','flagless4-work']:
 files.update(p for p in (r/directory).rglob('*.jtr') if p.is_file())
for directory in ['aot-policy','aot-policy-final','aot-policy-followup','build-attempt1']:
 for p in (r/directory).rglob('*'):
  if p.is_file() and p.suffix in text_ext: files.add(p)
files.update(p for p in (r/'fixture/src').rglob('*.java'))
files.add(r/'fixture/benchmarks.jar')
files.add(r/'aot-policy-probe.jar')
files.update(p for p in (r/'smoke-classes').rglob('*.class'))
files=sorted(p for p in files if p.is_file())
assert not any('images' in p.relative_to(r).parts or p.suffix in {'.aot','.jsa'} for p in files)
manifest=[]
for p in files:
 manifest.append(dict(path=str(p.relative_to(r)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()))
(r/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=r/'pr2-linux-x64-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'qualification/'+str(p.relative_to(r)))
 z.write(r/'evidence-manifest.json','qualification/evidence-manifest.json')
# Verify every payload, not just the ZIP checksum.
with zipfile.ZipFile(archive) as z:
 for item in manifest:
  b=z.read('qualification/'+item['path']);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],item['path']
sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
(r/'evidence-sha256.txt').write_text(sha+'  '+archive.name+'\n')
print(len(files),'payloads;',archive.stat().st_size,'bytes;sha256',sha)
