import json,re
from pathlib import Path
r=Path(__file__).parent
records=[]
for directory in ['semantics3-work','flagless3-work']:
 for p in (r/directory).rglob('*.jtr'):
  s=p.read_text();m=re.findall(r'^test result: (.*)',s,re.M)
  if not m: continue
  records.append(dict(file=str(p.relative_to(r)),status=m[-1],main_sections=s.count('#section:main\n'),driver_sections=s.count('#section:driver\n')))
assert len(records)==24, len(records)
assert all(x['status'].startswith('Passed.') for x in records),records
smokes=[]
manifest=json.loads((r/'images-final.json').read_text())['images']
for role in 'BOED':
 for panel in ['qualified-final','count-final','extension']:
  prefix='smoke-final-' if role in 'ED' else 'smoke-'
  p=r/(prefix+role+'-'+panel+'.log');s=p.read_text()
  m=re.search(r'PASS (\d+) fixed-panel output checks;',s);assert m,(p,s)
  smokes.append(dict(log=p.name,role=role,source=manifest[role]['source'],outputs=int(m[1])))
assert sum(x['outputs'] for x in smokes)==140
policy=[json.loads(x) for x in (r/'aot-policy-final/commands.jsonl').read_text().splitlines()]
assert len(policy)==12 and all(x['exit_code']==0 for x in policy)
summary=dict(source=manifest['E']['source'],tree=manifest['E']['tree'],image_manifest='images-final.json',test_records=records,main_sections=sum(x['main_sections'] for x in records),driver_sections=sum(x['driver_sections'] for x in records),smokes=smokes,all_passed=True,aot_policy_commands=12,flagless_reason='MetaspaceAllocGaps requires vm.flagless; run separately without target VM options')
(r/'validation-final.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS',len(records),'records;',summary['main_sections'],'main sections;',summary['driver_sections'],'driver sections;140 fixture outputs;12 AOT policy commands')
