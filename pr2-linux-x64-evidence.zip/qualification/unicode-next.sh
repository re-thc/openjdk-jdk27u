#!/usr/bin/env bash
set -euo pipefail
cd /workspace/work/pr2-evidence/fresh
for variant in control candidate; do
  images/E3/bin/javac --patch-module "java.base=patches/unicode-$variant-src" -d "patches/unicode-$variant-classes" "patches/unicode-$variant-src/sun/nio/cs/UnicodeDecoder.java" > "patches/unicode-$variant-compile.log" 2>&1
  for panel in qualified-final extension; do
    images/E3/bin/java --patch-module "java.base=patches/unicode-$variant-classes" -Xmx512m -XX:ActiveProcessorCount=2 -cp 'smoke-classes:fixture/benchmarks.jar:/workspace/work/pr2/build/jmh/jars/*' PanelSmoke "$panel-cases.tsv" > "patches/unicode-$variant-$panel-smoke.log" 2>&1
  done
done
python3 run.py unicode-diagnostic-plan.json unicode-diagnostic > unicode-diagnostic-progress.log 2>&1
python3 analyse.py unicode-diagnostic > unicode-diagnostic-analysis.log
